from __future__ import annotations

from typing import Literal, Optional
from pydantic import BaseModel, Field, field_validator


ResolutionPreset = Literal["4k", "4k_native", "1440p", "1080p"]
AspectRatio = Literal["16:9", "9:16", "1:1"]
VerticalLayout = Literal["crop", "blur"]
WorkflowMode = Literal["auto", "review"]
AIProvider = Literal["auto", "builtin", "openai", "gemini", "anthropic", "custom"]
JobStatus = Literal[
    "queued",
    "fetching_metadata",
    "analyzing",
    "awaiting_selection",
    "extracting",
    "completed",
    "failed",
    "cancelled",
]
ClipStatus = Literal["pending", "selected", "skipped", "extracting", "ready", "failed"]


class TranscriptSegment(BaseModel):
    start: float
    end: float
    text: str


class SubScores(BaseModel):
    hook: int = Field(ge=0, le=100, default=85)
    retention: int = Field(ge=0, le=100, default=85)
    emotion: int = Field(ge=0, le=100, default=80)
    pacing: int = Field(ge=0, le=100, default=85)


class ClipItem(BaseModel):
    id: str
    index: int
    title: str
    start_time: float = Field(ge=0)
    end_time: float = Field(gt=0)
    duration: float = Field(gt=0, le=60.5)
    virality_score: int = Field(ge=0, le=100)
    sub_scores: SubScores = Field(default_factory=SubScores)
    reason: str
    hook_quote: str = ""
    transcript: str = ""
    hashtags: list[str] = Field(default_factory=list)
    signals: list[str] = Field(default_factory=list)
    status: ClipStatus = "pending"
    progress: float = 0.0
    error: Optional[str] = None
    # Exported file specs (populated via ffprobe after rendering)
    filename: Optional[str] = None
    poster_filename: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None
    codec: Optional[str] = None
    fps: Optional[float] = None
    bitrate_kbps: Optional[int] = None
    file_size_bytes: Optional[int] = None
    is_4k: bool = False
    upscaled: bool = False
    aspect_ratio: AspectRatio = "16:9"
    burn_captions: bool = False


class VideoMetadata(BaseModel):
    id: str
    url: str
    title: str
    channel: str = "Unknown Creator"
    duration: float
    thumbnail: Optional[str] = None
    view_count: Optional[int] = None
    upload_date: Optional[str] = None
    extractor: str = "youtube"
    max_source_height: int = 1080
    max_source_width: int = 1920
    has_native_4k: bool = False
    available_heights: list[int] = Field(default_factory=list)
    has_transcript: bool = False
    transcript_language: Optional[str] = None
    transcript_word_count: int = 0
    has_heatmap: bool = False
    chapters: list[dict] = Field(default_factory=list)
    is_local_upload: bool = False


class CreateJobRequest(BaseModel):
    url: str = Field(..., min_length=4, max_length=2048)
    clip_count: int = Field(default=3, ge=1, le=12)
    clip_duration: int = Field(default=30, ge=5, le=60)
    resolution: ResolutionPreset = "4k"
    aspect_ratio: AspectRatio = "16:9"
    vertical_layout: VerticalLayout = "crop"
    burn_captions: bool = False
    smart_sentence_snap: bool = True
    focus_prompt: str = Field(default="", max_length=400)
    workflow_mode: WorkflowMode = "auto"

    @field_validator("url")
    @classmethod
    def clean_url(cls, v: str) -> str:
        v = v.strip()
        if not (v.startswith("http://") or v.startswith("https://") or v.startswith("local://")):
            raise ValueError("Please enter a valid video URL starting with https:// or http://")
        return v


class ExtractSelectedRequest(BaseModel):
    clip_ids: Optional[list[str]] = None
    resolution: Optional[ResolutionPreset] = None
    aspect_ratio: Optional[AspectRatio] = None
    vertical_layout: Optional[VerticalLayout] = None
    burn_captions: Optional[bool] = None


class UpdateClipRequest(BaseModel):
    title: Optional[str] = Field(default=None, max_length=140)
    start_time: float = Field(..., ge=0)
    end_time: float = Field(..., gt=0)
    aspect_ratio: Optional[AspectRatio] = None
    vertical_layout: Optional[VerticalLayout] = None
    resolution: Optional[ResolutionPreset] = None
    burn_captions: Optional[bool] = None
    re_extract: bool = True

    @field_validator("end_time")
    @classmethod
    def validate_end(cls, v: float) -> float:
        return round(v, 2)


class AddCustomClipRequest(BaseModel):
    title: str = Field(default="Custom Highlight Clip", max_length=140)
    start_time: float = Field(..., ge=0)
    end_time: float = Field(..., gt=0)
    extract_now: bool = True


class JobRecord(BaseModel):
    id: str
    created_at: str
    updated_at: str
    status: JobStatus
    stage_message: str = ""
    error: Optional[str] = None
    error_code: Optional[str] = None
    overall_progress: float = 0.0
    # Requested parameters
    url: str
    clip_count: int
    clip_duration: int
    resolution: ResolutionPreset
    aspect_ratio: AspectRatio
    vertical_layout: VerticalLayout = "crop"
    burn_captions: bool = False
    smart_sentence_snap: bool = True
    focus_prompt: str = ""
    workflow_mode: WorkflowMode = "auto"
    # Analysis results
    ai_engine_used: str = ""
    video: Optional[VideoMetadata] = None
    engagement_curve: list[float] = Field(default_factory=list)
    clips: list[ClipItem] = Field(default_factory=list)


class SettingsUpdateRequest(BaseModel):
    ai_provider: Optional[AIProvider] = None
    openai_api_key: Optional[str] = None
    openai_model: Optional[str] = None
    gemini_api_key: Optional[str] = None
    gemini_model: Optional[str] = None
    anthropic_api_key: Optional[str] = None
    anthropic_model: Optional[str] = None
    custom_base_url: Optional[str] = None
    custom_api_key: Optional[str] = None
    custom_model: Optional[str] = None
    cookies_txt: Optional[str] = None
    cookies_from_browser: Optional[str] = None
    proxy_url: Optional[str] = None
