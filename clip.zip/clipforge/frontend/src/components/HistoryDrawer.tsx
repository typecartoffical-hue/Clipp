import { Film, Loader2, Trash2, X } from 'lucide-react';
import type { JobRecord } from '../types';
import { formatTimecode } from '../utils/format';

interface HistoryDrawerProps {
  open: boolean;
  jobs: JobRecord[];
  activeJobId?: string | null;
  onClose: () => void;
  onSelectJob: (job: JobRecord) => void;
  onDeleteJob: (jobId: string) => void;
}

export function HistoryDrawer({
  open,
  jobs,
  activeJobId,
  onClose,
  onSelectJob,
  onDeleteJob,
}: HistoryDrawerProps) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-xs"
      onClick={onClose}
    >
      <aside
        className="flex h-full w-full max-w-md flex-col border-l border-white/[0.08] bg-[#0F1118] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-white/[0.07] px-5 py-4">
          <div>
            <h2 className="text-sm font-bold text-white">Clip Projects</h2>
            <p className="text-xs text-zinc-500">Recent videos processed with yt-dlp & AI</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-zinc-400 hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 space-y-2.5 overflow-y-auto p-4">
          {jobs.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Film className="h-7 w-7 text-zinc-600" />
              <p className="mt-3 text-xs font-medium text-zinc-400">No clip projects yet</p>
              <p className="mt-1 text-xs text-zinc-600">
                Paste a YouTube link to generate your first batch of viral 4K shorts.
              </p>
            </div>
          ) : (
            jobs.map((job) => {
              const readyCount = job.clips.filter((c) => c.status === 'ready').length;
              const isBusy = ['queued', 'fetching_metadata', 'analyzing', 'extracting'].includes(
                job.status
              );
              const isCurrent = job.id === activeJobId;
              return (
                <div
                  key={job.id}
                  onClick={() => {
                    onSelectJob(job);
                    onClose();
                  }}
                  className={`group flex cursor-pointer items-start gap-3 rounded-xl border p-3 transition ${
                    isCurrent
                      ? 'border-[#FF5A36]/50 bg-[#FF5A36]/10'
                      : 'border-white/[0.07] bg-[#141720] hover:border-white/15'
                  }`}
                >
                  {job.video?.thumbnail ? (
                    <img
                      src={job.video.thumbnail}
                      alt=""
                      className="h-14 w-24 shrink-0 rounded-lg bg-black object-cover"
                    />
                  ) : (
                    <div className="flex h-14 w-24 shrink-0 items-center justify-center rounded-lg bg-[#0B0D13] font-mono text-[10px] font-bold text-[#FF7A59]">
                      4K CLIP
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <p className="line-clamp-1 text-xs font-semibold text-white">
                      {job.video?.title || job.url}
                    </p>
                    <p className="mt-0.5 font-mono text-[11px] text-zinc-400">
                      {readyCount}/{job.clips.length || job.clip_count} clips · ≤{job.clip_duration}s ·{' '}
                      {job.resolution.toUpperCase()}
                      {job.video?.duration ? ` · ${formatTimecode(job.video.duration)}` : ''}
                    </p>
                    <div className="mt-1.5 flex items-center gap-1.5 text-[11px]">
                      {isBusy ? (
                        <span className="inline-flex items-center gap-1 text-[#FF8566]">
                          <Loader2 className="h-3 w-3 animate-spin" />
                          Processing ({Math.round(job.overall_progress)}%)
                        </span>
                      ) : job.status === 'completed' ? (
                        <span className="text-emerald-400">Ready to download</span>
                      ) : job.status === 'awaiting_selection' ? (
                        <span className="text-amber-300">Awaiting review</span>
                      ) : job.status === 'failed' ? (
                        <span className="text-red-400">Failed</span>
                      ) : (
                        <span className="text-zinc-400">{job.status}</span>
                      )}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteJob(job.id);
                    }}
                    className="rounded-lg p-1.5 text-zinc-500 opacity-0 transition group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-300"
                    title="Delete project"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>
      </aside>
    </div>
  );
}
