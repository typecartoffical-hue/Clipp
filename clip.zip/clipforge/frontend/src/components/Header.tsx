import { FolderClock, Plus, Scissors, Settings2 } from 'lucide-react';
import type { HealthInfo } from '../types';

interface HeaderProps {
  health: HealthInfo | null;
  healthChecked: boolean;
  jobCount: number;
  hasActiveJob: boolean;
  onNewVideo: () => void;
  onOpenHistory: () => void;
  onOpenSettings: () => void;
  onOpenVpsSettings: () => void;
}

export function Header({
  health,
  healthChecked,
  jobCount,
  hasActiveJob,
  onNewVideo,
  onOpenHistory,
  onOpenSettings,
  onOpenVpsSettings,
}: HeaderProps) {
  const hasConnectedExtras = Boolean(
    health?.has_cookies_file ||
      (health?.active_ai_label && !health.active_ai_label.startsWith('ClipForge'))
  );

  return (
    <header className="sticky top-0 z-30 border-b border-white/[0.07] bg-[#090A0F]/85 backdrop-blur-xl">
      <div className="mx-auto flex h-15 max-w-6xl items-center justify-between px-4 sm:px-6">
        <button
          type="button"
          onClick={onNewVideo}
          className="group flex items-center gap-2.5 text-left focus:outline-none"
        >
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#FF5A36] to-[#FF8142] shadow-lg shadow-[#FF5A36]/20 transition-transform group-hover:scale-105">
            <Scissors className="h-4 w-4 text-white" strokeWidth={2.4} />
          </span>
          <span className="text-[16px] font-bold tracking-tight text-white">
            ClipForge
          </span>
          <span className="rounded bg-[#FF5A36]/15 px-1.5 py-0.5 font-mono text-[11px] font-semibold text-[#FF7A59] ring-1 ring-[#FF5A36]/30">
            4K
          </span>
        </button>

        {health ? (
          <button
            type="button"
            onClick={onOpenVpsSettings}
            className="hidden items-center gap-2 rounded-full border border-white/[0.07] bg-[#11131A] px-3 py-1 text-xs text-zinc-400 transition hover:border-white/15 md:flex"
            title="Backend connection & engine status"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            <span className="font-mono text-[11px] text-zinc-300">
              yt-dlp {health.yt_dlp_version}
            </span>
            <span className="text-white/15">·</span>
            <span className="max-w-[230px] truncate text-[11px] text-zinc-400">
              {health.active_ai_label}
            </span>
          </button>
        ) : healthChecked ? (
          <button
            type="button"
            onClick={onOpenVpsSettings}
            className="hidden items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3 py-1 text-xs font-medium text-amber-200 transition hover:bg-amber-500/18 md:flex"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
            <span>Connect Render Backend</span>
          </button>
        ) : null}

        <div className="flex items-center gap-2">
          {hasActiveJob && (
            <button
              type="button"
              onClick={onNewVideo}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.09] bg-[#141720] px-3 py-1.5 text-xs font-medium text-zinc-200 transition hover:border-white/20 hover:bg-[#1A1E2B]"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>New Video</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenHistory}
            className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.08] bg-[#11131A] px-3 py-1.5 text-xs font-medium text-zinc-300 transition hover:border-white/15 hover:text-white"
          >
            <FolderClock className="h-3.5 w-3.5 text-zinc-400" />
            <span className="hidden sm:inline">Projects</span>
            {jobCount > 0 && (
              <span className="rounded bg-white/[0.08] px-1.5 py-0.2 font-mono text-[10px] text-zinc-200">
                {jobCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={onOpenSettings}
            className="relative inline-flex items-center gap-1.5 rounded-lg border border-white/[0.08] bg-[#11131A] px-3 py-1.5 text-xs font-medium text-zinc-300 transition hover:border-white/15 hover:text-white"
            title="AI Engine & YouTube Cookie Settings"
          >
            <Settings2 className="h-3.5 w-3.5 text-zinc-400" />
            <span className="hidden sm:inline">Settings</span>
            {hasConnectedExtras && (
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
