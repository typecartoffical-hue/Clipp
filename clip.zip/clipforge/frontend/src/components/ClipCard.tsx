import { useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  Copy,
  Download,
  Loader2,
  Maximize2,
  Play,
  RotateCcw,
  Scissors,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { api } from '../api';
import type { ClipItem } from '../types';
import { formatBytes, formatTimecode, scoreBadgeClasses } from '../utils/format';

interface ClipCardProps {
  jobId: string;
  clip: ClipItem;
  isReviewMode: boolean;
  isSelected: boolean;
  isHighlighted: boolean;
  onToggleSelect: (clipId: string) => void;
  onOpenTheater: (clip: ClipItem) => void;
  onOpenTrim: (clip: ClipItem) => void;
  onExtractSingle: (clipId: string) => void;
  onDeleteClip: (clipId: string) => void;
}

export function ClipCard({
  jobId,
  clip,
  isReviewMode,
  isSelected,
  isHighlighted,
  onToggleSelect,
  onOpenTheater,
  onOpenTrim,
  onExtractSingle,
  onDeleteClip,
}: ClipCardProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [hasStartedPlay, setHasStartedPlay] = useState(false);
  const [copiedTags, setCopiedTags] = useState(false);

  const streamUrl = api.clipStreamUrl(jobId, clip.id, clip.filename);
  const posterUrl = clip.poster_filename
    ? api.clipPosterUrl(jobId, clip.id, clip.filename)
    : undefined;
  const downloadUrl = api.clipDownloadUrl(jobId, clip.id);

  const handleInlinePlay = () => {
    setHasStartedPlay(true);
    setTimeout(() => {
      void videoRef.current?.play();
    }, 30);
  };

  const handleCopyCaption = async () => {
    const caption = `${clip.title}\n\n${clip.hashtags.join(' ')}`.trim();
    try {
      await navigator.clipboard.writeText(caption);
      setCopiedTags(true);
      setTimeout(() => setCopiedTags(false), 1800);
    } catch {
      // clipboard blocked
    }
  };

  const resolutionLabel =
    clip.width && clip.height
      ? `${clip.width}×${clip.height}`
      : clip.is_4k
      ? '3840×2160'
      : null;

  return (
    <article
      id={`clip-card-${clip.id}`}
      className={`group flex flex-col overflow-hidden rounded-2xl border bg-[#11131A] transition ${
        isHighlighted
          ? 'border-[#FF5A36]/70 ring-2 ring-[#FF5A36]/25'
          : 'border-white/[0.08] hover:border-white/[0.15]'
      }`}
    >
      {/* Video Preview Stage */}
      <div className="relative aspect-video w-full overflow-hidden bg-[#07080C]">
        {clip.status === 'ready' && clip.filename ? (
          <>
            <video
              ref={videoRef}
              src={streamUrl}
              poster={posterUrl}
              controls={hasStartedPlay}
              playsInline
              preload="metadata"
              onPlay={() => setHasStartedPlay(true)}
              className="h-full w-full bg-black object-contain"
            />
            {!hasStartedPlay && (
              <button
                type="button"
                onClick={handleInlinePlay}
                className="absolute inset-0 flex items-center justify-center bg-black/28 transition hover:bg-black/15"
                aria-label={`Preview ${clip.title}`}
              >
                <span className="flex h-13 w-13 items-center justify-center rounded-full bg-[#FF5A36] text-white shadow-xl shadow-black/60 transition-transform group-hover:scale-108">
                  <Play className="ml-0.5 h-5 w-5 fill-current" />
                </span>
              </button>
            )}

            {/* Theater Expand Button */}
            <button
              type="button"
              onClick={() => onOpenTheater(clip)}
              className="absolute top-2.5 right-2.5 rounded-lg border border-white/15 bg-black/65 p-1.5 text-zinc-200 backdrop-blur-md transition hover:bg-black/85 hover:text-white"
              title="Open Theater Preview"
            >
              <Maximize2 className="h-3.5 w-3.5" />
            </button>

            {/* 4K / Resolution Badge */}
            <div className="pointer-events-none absolute top-2.5 left-2.5 flex items-center gap-1.5">
              {clip.is_4k ? (
                <span className="rounded-md bg-[#FF5A36] px-2 py-0.5 font-mono text-[10px] font-bold tracking-wider text-white shadow">
                  4K UHD
                </span>
              ) : (
                clip.height && (
                  <span className="rounded-md bg-black/75 px-2 py-0.5 font-mono text-[10px] font-semibold text-zinc-200 ring-1 ring-white/15 backdrop-blur">
                    {clip.height}p HD
                  </span>
                )
              )}
              <span className="rounded-md bg-black/70 px-1.5 py-0.5 font-mono text-[10px] text-zinc-200 ring-1 ring-white/10 backdrop-blur">
                {clip.aspect_ratio}
              </span>
            </div>
          </>
        ) : clip.status === 'extracting' ? (
          <div className="flex h-full flex-col items-center justify-center px-6 text-center">
            <Loader2 className="h-7 w-7 animate-spin text-[#FF5A36]" />
            <p className="mt-3 text-xs font-semibold text-white">
              Extracting & Mastering Clip #{clip.index}
            </p>
            <div className="mt-3 h-1.5 w-44 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#FF5A36] to-[#FF8F4C] transition-all duration-300"
                style={{ width: `${Math.max(6, Math.round(clip.progress))}%` }}
              />
            </div>
            <span className="mt-1.5 font-mono text-[11px] text-zinc-400">
              {Math.round(clip.progress)}%
            </span>
          </div>
        ) : clip.status === 'failed' ? (
          <div className="flex h-full flex-col items-center justify-center px-5 text-center">
            <AlertCircle className="h-6 w-6 text-red-400" />
            <p className="mt-2 text-xs font-semibold text-red-300">Extraction Failed</p>
            <p className="mt-1 line-clamp-2 text-[11px] text-zinc-400">
              {clip.error || 'Could not export this segment.'}
            </p>
            <button
              type="button"
              onClick={() => onExtractSingle(clip.id)}
              className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1.5 text-xs font-medium text-white hover:bg-white/20"
            >
              <RotateCcw className="h-3 w-3" />
              Retry Clip
            </button>
          </div>
        ) : (
          /* Pending / Review Selection State */
          <div className="flex h-full flex-col items-center justify-center bg-gradient-to-b from-[#121521] to-[#0B0D14] px-6 text-center">
            {isReviewMode && (
              <button
                type="button"
                onClick={() => onToggleSelect(clip.id)}
                className={`absolute top-3 left-3 inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-medium transition ${
                  isSelected
                    ? 'border-[#FF5A36] bg-[#FF5A36] text-white'
                    : 'border-white/15 bg-black/50 text-zinc-300 hover:border-white/30'
                }`}
              >
                <Check className="h-3.5 w-3.5" />
                {isSelected ? 'Selected' : 'Select'}
              </button>
            )}
            <span className="font-mono text-lg font-semibold text-white">
              {formatTimecode(clip.start_time)} → {formatTimecode(clip.end_time)}
            </span>
            <p className="mt-1 text-xs text-zinc-400">
              {clip.status === 'pending'
                ? 'Queued for 4K extraction…'
                : `${clip.duration.toFixed(1)}s AI-detected highlight ready to render`}
            </p>
            {isReviewMode && (
              <button
                type="button"
                onClick={() => onExtractSingle(clip.id)}
                className="mt-3 inline-flex items-center gap-1.5 rounded-lg border border-[#FF5A36]/40 bg-[#FF5A36]/15 px-3 py-1.5 text-xs font-semibold text-[#FF886B] transition hover:bg-[#FF5A36]/25 hover:text-white"
              >
                <Sparkles className="h-3.5 w-3.5" />
                Extract Only This Clip
              </button>
            )}
          </div>
        )}
      </div>

      {/* Card Body */}
      <div className="flex flex-1 flex-col p-4 sm:p-5">
        {/* Meta Row: Rank + Timecode + Virality Score */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="rounded-md bg-white/[0.07] px-2 py-0.5 font-mono text-[11px] font-semibold text-zinc-200">
              #{clip.index}
            </span>
            <span className="font-mono text-xs text-zinc-400">
              {formatTimecode(clip.start_time)} – {formatTimecode(clip.end_time)}
            </span>
            <span className="rounded bg-white/[0.05] px-1.5 py-0.5 font-mono text-[11px] text-zinc-300">
              {clip.duration.toFixed(1)}s
            </span>
          </div>

          <span
            className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 font-mono text-[11px] font-semibold ${scoreBadgeClasses(
              clip.virality_score
            )}`}
            title={`Hook ${clip.sub_scores.hook} · Retention ${clip.sub_scores.retention} · Emotion ${clip.sub_scores.emotion} · Pacing ${clip.sub_scores.pacing}`}
          >
            {clip.virality_score} Viral
          </span>
        </div>

        {/* Title */}
        <h3 className="mt-2.5 line-clamp-2 text-[15px] font-bold leading-snug text-white">
          {clip.title}
        </h3>

        {/* AI Rationale */}
        <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-zinc-400">{clip.reason}</p>

        {/* Hook Quote (if transcript present) */}
        {clip.hook_quote && (
          <blockquote className="mt-2.5 line-clamp-2 border-l-2 border-[#FF5A36]/55 pl-2.5 text-xs italic text-zinc-300">
            {clip.hook_quote}
          </blockquote>
        )}

        {/* Signal Pills + Copy Hashtags */}
        <div className="mt-3 flex flex-wrap items-center gap-1.5">
          {clip.signals.slice(0, 3).map((sig) => (
            <span
              key={sig}
              className="rounded-md border border-white/[0.06] bg-white/[0.03] px-2 py-0.5 text-[10px] font-medium text-zinc-300"
            >
              {sig}
            </span>
          ))}
          {clip.hashtags.length > 0 && (
            <button
              type="button"
              onClick={handleCopyCaption}
              className="ml-auto inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] text-zinc-400 transition hover:bg-white/[0.06] hover:text-zinc-200"
              title="Copy clip title & viral hashtags"
            >
              {copiedTags ? (
                <>
                  <Check className="h-3 w-3 text-emerald-400" />
                  <span className="text-emerald-300">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="h-3 w-3" />
                  <span>Caption</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* Spacer */}
        <div className="flex-1" />

        {/* Technical Specs Strip (when exported) */}
        {clip.status === 'ready' && resolutionLabel && (
          <div className="mt-3.5 flex flex-wrap items-center gap-x-2 gap-y-1 border-t border-white/[0.06] pt-2.5 font-mono text-[11px] text-zinc-400">
            <span className="text-zinc-200">{resolutionLabel}</span>
            {clip.codec && (
              <>
                <span className="text-white/15">·</span>
                <span>{clip.codec}</span>
              </>
            )}
            {clip.fps && (
              <>
                <span className="text-white/15">·</span>
                <span>{Math.round(clip.fps)}fps</span>
              </>
            )}
            {clip.file_size_bytes ? (
              <>
                <span className="text-white/15">·</span>
                <span>{formatBytes(clip.file_size_bytes)}</span>
              </>
            ) : null}
          </div>
        )}

        {/* Action Bar: Trim / Delete / Individual Download */}
        <div className="mt-3 flex items-center gap-2">
          <button
            type="button"
            onClick={() => onOpenTrim(clip)}
            disabled={clip.status === 'extracting'}
            className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/[0.09] bg-[#171A24] px-3 py-2 text-xs font-medium text-zinc-200 transition hover:border-white/20 hover:bg-[#1E2230] disabled:opacity-40"
            title="Adjust start/end timestamps, aspect ratio, or captions"
          >
            <Scissors className="h-3.5 w-3.5 text-zinc-400" />
            <span>Trim</span>
          </button>

          {clip.status === 'ready' && clip.filename ? (
            <a
              href={downloadUrl}
              download
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#FF5A36] to-[#FF7B3A] px-4 py-2 text-xs font-bold text-white shadow-md shadow-[#FF5A36]/20 transition hover:brightness-110"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download {clip.is_4k ? '4K MP4' : 'MP4'}</span>
            </a>
          ) : (
            <button
              type="button"
              disabled={clip.status === 'extracting'}
              onClick={() => onExtractSingle(clip.id)}
              className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-white/[0.1] bg-white/[0.05] px-4 py-2 text-xs font-semibold text-zinc-200 transition hover:bg-white/[0.1] disabled:cursor-not-allowed disabled:opacity-50"
            >
              {clip.status === 'extracting' ? 'Rendering…' : 'Render Clip'}
            </button>
          )}

          <button
            type="button"
            onClick={() => onDeleteClip(clip.id)}
            disabled={clip.status === 'extracting'}
            className="inline-flex items-center justify-center rounded-xl border border-white/[0.07] bg-transparent p-2 text-zinc-500 transition hover:border-red-500/30 hover:bg-red-500/10 hover:text-red-300 disabled:opacity-30"
            title="Remove clip"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </article>
  );
}
