import { useCallback, useEffect, useState } from 'react';
import { ArrowRight, CheckCircle2, Loader2, Server } from 'lucide-react';
import { api, ingestUrlConnectionParams, saveVpsConfig } from './api';
import { Header } from './components/Header';
import { HistoryDrawer } from './components/HistoryDrawer';
import { JobWorkspace } from './components/JobWorkspace';
import { SettingsModal, type SettingsTab } from './components/SettingsModal';
import { VideoComposer } from './components/VideoComposer';
import type { CreateJobPayload, HealthInfo, JobRecord } from './types';
import { formatTimecode } from './utils/format';

const ACTIVE_STATUSES = new Set([
  'queued',
  'fetching_metadata',
  'analyzing',
  'extracting',
]);

// Capture ?api=https://*.onrender.com 1-click Render link immediately on boot
ingestUrlConnectionParams();

export default function App() {
  const [health, setHealth] = useState<HealthInfo | null>(null);
  const [healthChecked, setHealthChecked] = useState(false);
  const [jobs, setJobs] = useState<JobRecord[]>([]);
  const [activeJob, setActiveJob] = useState<JobRecord | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [quickVpsUrl, setQuickVpsUrl] = useState('');
  const [connectingVps, setConnectingVps] = useState(false);
  const [quickVpsErr, setQuickVpsErr] = useState<string | null>(null);

  const [historyOpen, setHistoryOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState<SettingsTab>('ai');

  const refreshAll = useCallback(() => {
    api
      .getHealth()
      .then((h) => {
        setHealth(h);
        setHealthChecked(true);
        return api.listJobs().then((r) => setJobs(r.jobs));
      })
      .catch(() => {
        setHealth(null);
        setHealthChecked(true);
        setJobs([]);
      });
  }, []);

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  // Poll active job smoothly while running
  useEffect(() => {
    if (!activeJob || !ACTIVE_STATUSES.has(activeJob.status)) return;
    const timer = window.setInterval(async () => {
      try {
        const latest = await api.getJob(activeJob.id);
        setActiveJob(latest);
        setJobs((prev) => {
          const idx = prev.findIndex((j) => j.id === latest.id);
          if (idx === -1) return [latest, ...prev];
          const copy = [...prev];
          copy[idx] = latest;
          return copy;
        });
      } catch {
        // transient network issue
      }
    }, 1200);
    return () => window.clearInterval(timer);
  }, [activeJob]);

  const handleQuickConnectVps = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickVpsUrl.trim()) return;
    setConnectingVps(true);
    setQuickVpsErr(null);
    try {
      const { normalizedUrl } = await api.testVpsConnection(quickVpsUrl, '');
      saveVpsConfig(normalizedUrl, '');
      setQuickVpsUrl('');
      refreshAll();
    } catch (err) {
      setQuickVpsErr(err instanceof Error ? err.message : 'Could not connect to Render backend');
    } finally {
      setConnectingVps(false);
    }
  };

  const handleCreateJob = async (payload: CreateJobPayload) => {
    setSubmitting(true);
    try {
      const created = await api.createJob(payload);
      setActiveJob(created);
      setJobs((prev) => [created, ...prev]);
    } finally {
      setSubmitting(false);
    }
  };

  const handleRetryUrl = async (url: string) => {
    if (!activeJob) return;
    await handleCreateJob({
      url,
      clip_count: activeJob.clip_count,
      clip_duration: activeJob.clip_duration,
      resolution: activeJob.resolution,
      aspect_ratio: activeJob.aspect_ratio,
      vertical_layout: activeJob.vertical_layout,
      burn_captions: activeJob.burn_captions,
      smart_sentence_snap: activeJob.smart_sentence_snap,
      focus_prompt: activeJob.focus_prompt,
      workflow_mode: activeJob.workflow_mode,
    });
  };

  const handleJobChange = (updated: JobRecord) => {
    setActiveJob(updated);
    setJobs((prev) => prev.map((j) => (j.id === updated.id ? updated : j)));
  };

  const handleDeleteJob = async (jobId: string) => {
    try {
      await api.deleteJob(jobId);
      setJobs((prev) => prev.filter((j) => j.id !== jobId));
      if (activeJob?.id === jobId) {
        setActiveJob(null);
      }
    } catch {
      // ignore
    }
  };

  return (
    <div className="relative min-h-screen bg-[#090A0F] text-[#F3F4F6]">
      {/* Subtle ambient top studio glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 top-0 h-[360px] bg-[radial-gradient(ellipse_65%_50%_at_50%_-10%,rgba(255,90,54,0.12),transparent)]"
      />

      <Header
        health={health}
        healthChecked={healthChecked}
        jobCount={jobs.length}
        hasActiveJob={Boolean(activeJob)}
        onNewVideo={() => setActiveJob(null)}
        onOpenHistory={() => {
          refreshAll();
          setHistoryOpen(true);
        }}
        onOpenSettings={() => {
          setSettingsTab(health ? 'ai' : 'vps');
          setSettingsOpen(true);
        }}
        onOpenVpsSettings={() => {
          setSettingsTab('vps');
          setSettingsOpen(true);
        }}
      />

      <main className="relative mx-auto max-w-6xl px-4 sm:px-6">
        {/* Inline Render Backend Quick-Connect Banner (shown on Vercel before Render service is linked) */}
        {healthChecked && !health && !activeJob && (
          <div className="mx-auto mt-6 max-w-4xl rounded-2xl border border-amber-500/25 bg-[#12141E] p-4 sm:px-5">
            <form
              onSubmit={handleQuickConnectVps}
              className="flex flex-col gap-3 sm:flex-row sm:items-center"
            >
              <div className="flex items-center gap-2.5 sm:shrink-0">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/15 text-amber-300">
                  <Server className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-xs font-bold text-white">Connect Your Render Backend</p>
                  <p className="text-[11px] text-zinc-400">
                    Paste your Render HTTPS URL for 4K yt-dlp + FFmpeg extraction
                  </p>
                </div>
              </div>

              <div className="flex flex-1 items-center gap-2">
                <input
                  type="text"
                  value={quickVpsUrl}
                  onChange={(e) => {
                    setQuickVpsUrl(e.target.value);
                    if (quickVpsErr) setQuickVpsErr(null);
                  }}
                  placeholder="https://clipforge-4k-api.onrender.com"
                  className="w-full rounded-xl border border-white/10 bg-[#0A0C12] px-3 py-2 font-mono text-xs text-white placeholder-zinc-600 focus:border-[#FF5A36] focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={connectingVps || !quickVpsUrl.trim()}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-[#FF5A36] px-4 py-2 text-xs font-bold text-white transition hover:brightness-110 disabled:opacity-50"
                >
                  {connectingVps && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                  {connectingVps ? 'Waking…' : 'Connect'}
                </button>
              </div>
            </form>
            {connectingVps && (
              <p className="mt-2 text-[11px] text-amber-200/90">
                Connecting to Render… (Free tier services take ~30–50s to wake from sleep.)
              </p>
            )}
            {quickVpsErr && (
              <p className="mt-2 text-xs text-red-300">{quickVpsErr}</p>
            )}
          </div>
        )}

        {activeJob ? (
          <JobWorkspace
            job={activeJob}
            onJobChange={handleJobChange}
            onBackToComposer={() => setActiveJob(null)}
            onRetrySameUrl={(u) => void handleRetryUrl(u)}
            onOpenCookieSettings={() => {
              setSettingsTab('youtube');
              setSettingsOpen(true);
            }}
          />
        ) : (
          <>
            <VideoComposer submitting={submitting} onSubmit={handleCreateJob} />

            {jobs.length > 0 && (
              <section className="mx-auto max-w-4xl pb-16">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-xs font-semibold tracking-wider text-zinc-400 uppercase">
                    Recent Clip Projects
                  </h2>
                  {jobs.length > 4 && (
                    <button
                      type="button"
                      onClick={() => setHistoryOpen(true)}
                      className="text-xs font-medium text-[#FF8566] hover:underline"
                    >
                      View all ({jobs.length})
                    </button>
                  )}
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  {jobs.slice(0, 4).map((job) => {
                    const readyCount = job.clips.filter((c) => c.status === 'ready').length;
                    const busy = ACTIVE_STATUSES.has(job.status);
                    return (
                      <button
                        key={job.id}
                        type="button"
                        onClick={() => setActiveJob(job)}
                        className="group flex items-center gap-3.5 rounded-2xl border border-white/[0.08] bg-[#11131A] p-3 text-left transition hover:border-[#FF5A36]/45 hover:bg-[#141720]"
                      >
                        {job.video?.thumbnail ? (
                          <img
                            src={job.video.thumbnail}
                            alt=""
                            className="h-15 w-26 shrink-0 rounded-xl bg-black object-cover"
                          />
                        ) : (
                          <div className="flex h-15 w-26 shrink-0 items-center justify-center rounded-xl bg-[#0B0D13] font-mono text-xs font-bold text-[#FF7A59]">
                            4K UHD
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <p className="line-clamp-1 text-xs font-bold text-white sm:text-sm">
                            {job.video?.title || job.url}
                          </p>
                          <p className="mt-0.5 font-mono text-[11px] text-zinc-400">
                            {readyCount} {readyCount === 1 ? 'clip' : 'clips'} · ≤{job.clip_duration}s ·{' '}
                            {job.resolution === '4k' ? '4K 2160p' : job.resolution.toUpperCase()}
                            {job.video?.duration ? ` · ${formatTimecode(job.video.duration)}` : ''}
                          </p>
                          <div className="mt-1 flex items-center gap-1.5 text-[11px]">
                            {busy ? (
                              <span className="inline-flex items-center gap-1 text-[#FF8566]">
                                <Loader2 className="h-3 w-3 animate-spin" />
                                Rendering ({Math.round(job.overall_progress)}%)
                              </span>
                            ) : job.status === 'completed' ? (
                              <span className="inline-flex items-center gap-1 text-emerald-400">
                                <CheckCircle2 className="h-3 w-3" />
                                Ready to preview & download
                              </span>
                            ) : (
                              <span className="text-zinc-400">{job.status}</span>
                            )}
                          </div>
                        </div>
                        <ArrowRight className="h-4 w-4 shrink-0 text-zinc-500 transition group-hover:translate-x-0.5 group-hover:text-[#FF8566]" />
                      </button>
                    );
                  })}
                </div>
              </section>
            )}
          </>
        )}
      </main>

      <HistoryDrawer
        open={historyOpen}
        jobs={jobs}
        activeJobId={activeJob?.id}
        onClose={() => setHistoryOpen(false)}
        onSelectJob={(j) => setActiveJob(j)}
        onDeleteJob={(id) => void handleDeleteJob(id)}
      />

      <SettingsModal
        open={settingsOpen}
        initialTab={settingsTab}
        backendOnline={Boolean(health)}
        onClose={() => setSettingsOpen(false)}
        onUpdated={refreshAll}
      />
    </div>
  );
}
