from __future__ import annotations

import html
import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.parse import urlparse

import httpx
import yt_dlp

from models import (
    AspectRatio,
    ResolutionPreset,
    TranscriptSegment,
    VerticalLayout,
    VideoMetadata,
)
from services.config_store import COOKIES_PATH, UPLOADS_DIR, has_cookies_file, load_settings


class YouTubeAuthRequiredError(RuntimeError):
    def __init__(self, message: str, partial_meta: Optional[dict[str, Any]] = None):
        super().__init__(message)
        self.partial_meta = partial_meta or {}


def get_engine_versions() -> dict[str, str]:
    ytdlp_ver = getattr(yt_dlp.version, "__version__", "unknown")
    ffmpeg_ver = "unavailable"
    try:
        r = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True, timeout=5)
        if r.returncode == 0 and r.stdout:
            first = r.stdout.splitlines()[0]
            m = re.search(r"ffmpeg version\s+([^\s]+)", first)
            ffmpeg_ver = m.group(1) if m else first[:32]
    except Exception:
        pass
    return {"yt_dlp": ytdlp_ver, "ffmpeg": ffmpeg_ver}


def _total_ram_gb() -> float:
    """Detect effective memory limit in GB (respects Render/Docker cgroup limits as well as /proc/meminfo)."""
    limits_gb: list[float] = []
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    limits_gb.append(int(line.split()[1]) / (1024 * 1024))
                    break
    except Exception:
        pass
    for cg_path in (
        "/sys/fs/cgroup/memory.max",
        "/sys/fs/cgroup/memory/memory.limit_in_bytes",
    ):
        try:
            raw = Path(cg_path).read_text(encoding="utf-8").strip()
            if raw and raw != "max" and raw.isdigit():
                val = int(raw)
                # Ignore unbounded sentinel values (~2^63)
                if 0 < val < (1 << 50):
                    limits_gb.append(val / (1024**3))
        except Exception:
            pass
    return min(limits_gb) if limits_gb else 4.0


def _is_youtube_url(url: str) -> bool:
    try:
        host = (urlparse(url).hostname or "").lower()
        return any(h in host for h in ("youtube.com", "youtu.be", "youtube-nocookie.com"))
    except Exception:
        return False


def _is_direct_media_url(url: str) -> bool:
    try:
        path = (urlparse(url).path or "").lower()
        return path.endswith((".mp4", ".mov", ".mkv", ".webm", ".m4v"))
    except Exception:
        return False


def _resolve_local_upload(url: str) -> Optional[Path]:
    if not url.startswith("local://"):
        return None
    name = Path(url.removeprefix("local://")).name
    candidate = UPLOADS_DIR / name
    if candidate.exists() and candidate.is_file():
        return candidate
    return None


def _base_ydl_opts(extra: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    settings = load_settings()
    opts: dict[str, Any] = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": 25,
        "retries": 3,
        "fragment_retries": 3,
        "nocheckcertificate": False,
    }
    # Enable Node.js runtime for yt-dlp-ejs challenge solving (required for YouTube 4K formats)
    if shutil.which("node"):
        opts["js_runtimes"] = {"node": {}}

    if has_cookies_file():
        opts["cookiefile"] = str(COOKIES_PATH)
    elif settings.get("cookies_from_browser"):
        browser = str(settings["cookies_from_browser"]).strip()
        if browser:
            opts["cookiesfrombrowser"] = (browser,)

    if settings.get("proxy_url"):
        opts["proxy"] = str(settings["proxy_url"]).strip()

    if extra:
        opts.update(extra)
    return opts


def _fetch_youtube_oembed(url: str) -> dict[str, Any]:
    try:
        r = httpx.get(
            "https://www.youtube.com/oembed",
            params={"url": url, "format": "json"},
            timeout=8,
        )
        if r.status_code == 200:
            data = r.json()
            return {
                "title": data.get("title"),
                "channel": data.get("author_name"),
                "thumbnail": data.get("thumbnail_url"),
            }
    except Exception:
        pass
    return {}


def ffprobe_media(target: str) -> dict[str, Any]:
    """Inspect a local file or direct HTTP media URL via ffprobe."""
    cmd = [
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "stream=codec_type,codec_name,profile,width,height,r_frame_rate,bit_rate",
        "-show_entries",
        "format=duration,size,bit_rate,tags",
        "-of",
        "json",
        target,
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        return {}
    try:
        raw = json.loads(r.stdout)
    except Exception:
        return {}

    vstream = next((s for s in raw.get("streams", []) if s.get("codec_type") == "video"), {})
    fmt = raw.get("format", {})

    fps = None
    rfr = vstream.get("r_frame_rate")
    if rfr and "/" in rfr:
        num, den = rfr.split("/", 1)
        try:
            fps = round(float(num) / float(den), 2) if float(den) else None
        except Exception:
            fps = None

    bitrate = fmt.get("bit_rate") or vstream.get("bit_rate")
    bitrate_kbps = int(int(bitrate) / 1000) if bitrate and str(bitrate).isdigit() else None
    size = fmt.get("size")
    duration = fmt.get("duration")
    tags = fmt.get("tags") or {}

    return {
        "width": int(vstream["width"]) if vstream.get("width") else None,
        "height": int(vstream["height"]) if vstream.get("height") else None,
        "codec": vstream.get("codec_name"),
        "profile": vstream.get("profile"),
        "fps": fps,
        "duration": float(duration) if duration else None,
        "size_bytes": int(size) if size and str(size).isdigit() else None,
        "bitrate_kbps": bitrate_kbps,
        "title": tags.get("title"),
        "artist": tags.get("artist"),
    }


def _clean_caption_text(text: str) -> str:
    text = html.unescape(text)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"\{\\[^}]+\}", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _parse_timestamp(ts: str) -> float:
    ts = ts.strip().replace(",", ".")
    parts = ts.split(":")
    try:
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
        if len(parts) == 2:
            return int(parts[0]) * 60 + float(parts[1])
        return float(parts[0])
    except Exception:
        return 0.0


def _parse_json3_subtitles(raw_text: str) -> list[TranscriptSegment]:
    data = json.loads(raw_text)
    events = data.get("events") or []
    segments: list[TranscriptSegment] = []
    for ev in events:
        segs = ev.get("segs")
        if not segs:
            continue
        txt = _clean_caption_text("".join(s.get("utf8", "") for s in segs))
        if not txt or txt == "\n":
            continue
        start = float(ev.get("tStartMs", 0)) / 1000.0
        dur = float(ev.get("dDurationMs", 2500)) / 1000.0
        end = start + max(0.3, min(dur, 12.0))
        # Clamp previous segment end if auto-captions overlap
        if segments and segments[-1].end > start and start > segments[-1].start:
            segments[-1].end = round(start, 2)
        if segments and segments[-1].text == txt:
            continue
        segments.append(TranscriptSegment(start=round(start, 2), end=round(end, 2), text=txt))
    return segments


def _parse_vtt_or_srt(raw_text: str) -> list[TranscriptSegment]:
    lines = raw_text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    segments: list[TranscriptSegment] = []
    i = 0
    n = len(lines)
    ts_pattern = re.compile(
        r"((?:\d+:)?\d{2}:\d{2}[.,]\d{3})\s*-->\s*((?:\d+:)?\d{2}:\d{2}[.,]\d{3})"
    )
    while i < n:
        m = ts_pattern.search(lines[i])
        if not m:
            i += 1
            continue
        start = _parse_timestamp(m.group(1))
        end = _parse_timestamp(m.group(2))
        i += 1
        buf: list[str] = []
        while i < n and lines[i].strip() != "" and not ts_pattern.search(lines[i]):
            buf.append(lines[i].strip())
            i += 1
        txt = _clean_caption_text(" ".join(buf))
        if not txt or end - start < 0.08:
            continue
        # Deduplicate rolling YouTube VTT lines
        if segments:
            prev = segments[-1]
            if txt == prev.text:
                prev.end = round(max(prev.end, end), 2)
                continue
            if txt.startswith(prev.text) and len(prev.text) > 8:
                remainder = txt[len(prev.text) :].strip()
                if remainder:
                    txt = remainder
                else:
                    continue
            if prev.text.endswith(txt) and len(txt) > 8:
                continue
            if prev.end > start and start > prev.start:
                prev.end = round(start, 2)
        segments.append(TranscriptSegment(start=round(start, 2), end=round(end, 2), text=txt))
    return segments


def _extract_transcript_from_info(info: dict[str, Any]) -> tuple[list[TranscriptSegment], Optional[str]]:
    """Download and parse the cleanest available subtitle/caption track via yt-dlp info."""
    subtitles = info.get("subtitles") or {}
    auto_caps = info.get("automatic_captions") or {}
    orig_lang = (info.get("language") or "").split("-")[0].lower()

    def pick_track(pool: dict[str, list[dict]]) -> tuple[Optional[str], Optional[list[dict]]]:
        if not pool:
            return None, None
        preferred_order = ["en", "en-US", "en-GB", "en-orig"]
        if orig_lang and orig_lang not in preferred_order:
            preferred_order.append(orig_lang)
        for code in preferred_order:
            if code in pool and pool[code]:
                return code, pool[code]
        for code in pool:
            if code.lower().startswith("en") and pool[code]:
                return code, pool[code]
        first_key = next((k for k in pool if k != "live_chat" and pool[k]), None)
        return (first_key, pool[first_key]) if first_key else (None, None)

    lang, formats = pick_track(subtitles)
    if not formats:
        lang, formats = pick_track(auto_caps)
    if not formats:
        return [], None

    ext_priority = {"json3": 0, "vtt": 1, "srt": 2, "ttml": 3, "srv3": 4}
    sorted_fmts = sorted(formats, key=lambda f: ext_priority.get(f.get("ext", ""), 99))

    settings = load_settings()
    proxy = settings.get("proxy_url") or None

    for fmt in sorted_fmts[:4]:
        sub_url = fmt.get("url")
        ext = (fmt.get("ext") or "").lower()
        proto = (fmt.get("protocol") or "").lower()
        if not sub_url or ext not in ("json3", "vtt", "srt") or "m3u8" in proto:
            continue
        try:
            with httpx.Client(timeout=15, follow_redirects=True, proxy=proxy) as client:
                resp = client.get(
                    sub_url,
                    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
                )
            if resp.status_code != 200 or not resp.text.strip():
                continue
            segs = _parse_json3_subtitles(resp.text) if ext == "json3" else _parse_vtt_or_srt(resp.text)
            if len(segs) >= 3:
                return segs, lang
        except Exception:
            continue

    # Fallback for m3u8_native / HLS / segmented subtitle streams: let yt-dlp assemble the VTT file
    webpage_url = info.get("webpage_url") or info.get("original_url")
    if lang and webpage_url:
        import tempfile

        try:
            with tempfile.TemporaryDirectory(prefix="cf_subs_") as tmpd:
                sub_opts = _base_ydl_opts(
                    {
                        "skip_download": True,
                        "writesubtitles": lang in subtitles,
                        "writeautomaticsub": lang not in subtitles,
                        "subtitleslangs": [lang],
                        "subtitlesformat": "json3/vtt/srt/best",
                        "outtmpl": f"{tmpd}/sub.%(ext)s",
                    }
                )
                with yt_dlp.YoutubeDL(sub_opts) as ydl:
                    ydl.download([webpage_url])
                for sf in sorted(Path(tmpd).glob("sub*")):
                    raw_sub = sf.read_text(encoding="utf-8", errors="ignore")
                    if not raw_sub.strip():
                        continue
                    segs = (
                        _parse_json3_subtitles(raw_sub)
                        if sf.suffix.lower() == ".json3"
                        else _parse_vtt_or_srt(raw_sub)
                    )
                    if len(segs) >= 3:
                        return segs, lang
        except Exception:
            pass

    return [], None


def extract_video_info(
    url: str,
) -> tuple[VideoMetadata, list[TranscriptSegment], list[dict[str, float]], dict[str, Any]]:
    """
    Fetch full video metadata, available resolutions (including 4K 2160p),
    transcript segments, and audience replay heatmap using yt-dlp.
    """
    local_file = _resolve_local_upload(url)
    if local_file:
        probe = ffprobe_media(str(local_file))
        duration = probe.get("duration") or 0.0
        if duration < 5:
            raise ValueError("Uploaded video must be at least 5 seconds long.")
        w = probe.get("width") or 1920
        h = probe.get("height") or 1080
        stem = re.sub(r"^[0-9a-f]{8}_", "", local_file.stem).replace("_", " ").replace("-", " ").strip()
        meta = VideoMetadata(
            id=local_file.stem[:12],
            url=url,
            title=probe.get("title") or stem or "Uploaded Video",
            channel="Local Studio Upload",
            duration=round(duration, 2),
            thumbnail=None,
            extractor="local",
            max_source_height=h,
            max_source_width=w,
            has_native_4k=(h >= 2160 or w >= 3840),
            available_heights=sorted({h}, reverse=True),
            has_transcript=False,
            has_heatmap=False,
            is_local_upload=True,
        )
        return meta, [], [], {"local_path": str(local_file)}

    last_err: Optional[Exception] = None
    info: Optional[dict[str, Any]] = None

    # Resilient client strategies for YouTube + standard extraction for all 1,800+ yt-dlp extractors
    attempts: list[dict[str, Any]] = [{"skip_download": True}]
    if _is_youtube_url(url):
        attempts.append(
            {
                "skip_download": True,
                "extractor_args": {"youtube": {"player_client": ["default", "tv", "mweb"]}},
            }
        )
        attempts.append(
            {
                "skip_download": True,
                "extractor_args": {"youtube": {"player_client": ["android_vr", "web_safari"]}},
            }
        )

    for extra in attempts:
        try:
            with yt_dlp.YoutubeDL(_base_ydl_opts(extra)) as ydl:
                info = ydl.extract_info(url, download=False)
            if info:
                break
        except Exception as exc:
            last_err = exc
            msg = str(exc).lower()
            # Non-YouTube or permanent not-found error: stop immediately
            if not _is_youtube_url(url) or "video unavailable" in msg or "private video" in msg:
                break

    if not info:
        err_str = str(last_err or "Failed to fetch video metadata.")
        low = err_str.lower()
        if _is_youtube_url(url) and (
            "not a bot" in low
            or "sign in" in low
            or "429" in low
            or "cookies" in low
        ):
            partial = _fetch_youtube_oembed(url)
            raise YouTubeAuthRequiredError(
                "YouTube requested authentication from this cloud server IP. "
                "Add a YouTube cookies.txt in Settings to unlock direct 4K YouTube extraction here, "
                "upload a video file directly, or run ClipForge locally where residential IPs work automatically.",
                partial_meta=partial,
            )
        clean_err = re.sub(r"\x1b\[[0-9;]*m", "", err_str)
        clean_err = re.sub(r"^ERROR:\s*", "", clean_err).strip()
        raise RuntimeError(clean_err)

    # Unwrap single-entry playlists if any
    if info.get("_type") == "playlist" and info.get("entries"):
        info = next((e for e in info["entries"] if e), info)

    formats = info.get("formats") or []
    heights = sorted({int(f["height"]) for f in formats if f.get("height")}, reverse=True)
    widths = sorted({int(f["width"]) for f in formats if f.get("width")}, reverse=True)

    duration = float(info.get("duration") or 0.0)
    max_h = heights[0] if heights else int(info.get("height") or 0)
    max_w = widths[0] if widths else int(info.get("width") or 0)
    title = info.get("title") or "Untitled Video"
    channel = info.get("uploader") or info.get("channel") or info.get("creator") or ""

    # For direct media streams (generic extractor), enrich with ffprobe for exact 4K dimensions & duration
    if (not duration or not max_h) and (_is_direct_media_url(url) or info.get("extractor") == "generic"):
        direct_target = info.get("url") or url
        probe = ffprobe_media(direct_target)
        duration = duration or float(probe.get("duration") or 0.0)
        max_h = max_h or int(probe.get("height") or 1080)
        max_w = max_w or int(probe.get("width") or 1920)
        if probe.get("height") and probe["height"] not in heights:
            heights = sorted(set(heights + [probe["height"]]), reverse=True)
        if probe.get("title") and ("bbb_sunflower" in title or title.endswith(".mp4")):
            title = probe["title"]
        if not channel and probe.get("artist"):
            channel = probe["artist"]

    # Polish known raw filenames
    if "bbb_sunflower_2160p" in title.lower():
        title = "Big Buck Bunny — Official 4K UHD Short Film"
        channel = channel or "Blender Foundation"

    if duration <= 0:
        raise RuntimeError("Could not determine video duration (live streams without DVR cannot be clipped).")

    max_h = max_h or 1080
    max_w = max_w or int(round(max_h * 16 / 9))

    # Extract subtitles / captions
    transcript, lang = _extract_transcript_from_info(info)
    word_count = sum(len(s.text.split()) for s in transcript)

    # Extract YouTube Most-Replayed heatmap
    raw_heatmap = info.get("heatmap") or []
    heatmap: list[dict[str, float]] = []
    for h in raw_heatmap:
        if "start_time" in h and "end_time" in h and "value" in h:
            heatmap.append(
                {
                    "start_time": float(h["start_time"]),
                    "end_time": float(h["end_time"]),
                    "value": float(h["value"]),
                }
            )

    raw_chapters = info.get("chapters") or []
    chapters = [
        {
            "title": str(c.get("title") or ""),
            "start_time": round(float(c.get("start_time") or 0), 2),
            "end_time": round(float(c.get("end_time") or duration), 2),
        }
        for c in raw_chapters
    ]

    # Pick cleanest high-res thumbnail
    thumbnail = info.get("thumbnail")
    if not thumbnail and info.get("thumbnails"):
        thumbs = [t for t in info["thumbnails"] if t.get("url")]
        if thumbs:
            thumbnail = thumbs[-1]["url"]

    meta = VideoMetadata(
        id=str(info.get("id") or "video"),
        url=info.get("webpage_url") or url,
        title=title,
        channel=channel or (info.get("extractor_key") or "Creator"),
        duration=round(duration, 2),
        thumbnail=thumbnail,
        view_count=info.get("view_count"),
        upload_date=info.get("upload_date"),
        extractor=str(info.get("extractor") or "youtube").lower(),
        max_source_height=max_h,
        max_source_width=max_w,
        has_native_4k=(max_h >= 2160 or max_w >= 3840),
        available_heights=heights or [max_h],
        has_transcript=len(transcript) > 0,
        transcript_language=lang,
        transcript_word_count=word_count,
        has_heatmap=len(heatmap) > 0,
        chapters=chapters,
    )
    return meta, transcript, heatmap, info


def sample_audio_energy_peaks(
    source_target: str, duration: float, sample_points: int = 18
) -> list[dict[str, float]]:
    """
    Sample short 1.2s audio slices across a transcript-free video (local or HTTP range MP4)
    to measure real acoustic energy (RMS dB) so the AI selects genuinely dynamic action moments.
    """
    if duration < 15:
        return []
    usable_start = min(duration * 0.06, 20.0)
    usable_end = max(usable_start + 5.0, duration * 0.92)
    span = usable_end - usable_start
    points = min(sample_points, max(6, int(span // 18)))
    step = span / points

    results: list[dict[str, float]] = []
    vol_re = re.compile(r"max_volume:\s*([-\d.]+)\s*dB")
    mean_re = re.compile(r"mean_volume:\s*([-\d.]+)\s*dB")

    for i in range(points):
        ts = round(usable_start + (i + 0.5) * step, 1)
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-ss",
            str(ts),
            "-t",
            "1.2",
            "-i",
            source_target,
            "-vn",
            "-af",
            "volumedetect",
            "-f",
            "null",
            "-",
        ]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=6)
            m_mean = mean_re.search(r.stderr)
            m_max = vol_re.search(r.stderr)
            if m_mean:
                mean_db = float(m_mean.group(1))
                max_db = float(m_max.group(1)) if m_max else mean_db + 6.0
                # Map [-50 dB .. -6 dB] -> [0.05 .. 1.0]
                norm = max(0.05, min(1.0, (mean_db + 50.0) / 42.0))
                crest = max(0.0, min(0.25, (max_db + 25.0) / 80.0))
                score = min(1.0, round(norm * 0.8 + crest, 3))
                results.append(
                    {
                        "start_time": max(0.0, round(ts - step * 0.5, 2)),
                        "end_time": min(duration, round(ts + step * 0.5, 2)),
                        "value": score,
                    }
                )
        except Exception:
            continue
    return results


def _format_ass_time(seconds: float) -> str:
    seconds = max(0.0, seconds)
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def _write_ass_captions(
    ass_path: Path,
    segments: list[TranscriptSegment],
    clip_start: float,
    clip_end: float,
    width: int,
    height: int,
) -> bool:
    """Create crisp studio-styled ASS captions aligned to [0, clip_end - clip_start]."""
    relevant: list[tuple[float, float, str]] = []
    clip_dur = clip_end - clip_start
    for seg in segments:
        if seg.end <= clip_start + 0.05 or seg.start >= clip_end - 0.05:
            continue
        rel_s = max(0.0, seg.start - clip_start)
        rel_e = min(clip_dur, seg.end - clip_start)
        if rel_e - rel_s < 0.15:
            continue
        txt = seg.text.strip()
        if not txt:
            continue
        # Chunk long lines into punchy short-form caption phrases (max ~8 words each)
        words = txt.split()
        if len(words) > 10:
            chunks = [" ".join(words[i : i + 7]) for i in range(0, len(words), 7)]
            chunk_dur = (rel_e - rel_s) / len(chunks)
            for idx, ch in enumerate(chunks):
                relevant.append((rel_s + idx * chunk_dur, rel_s + (idx + 1) * chunk_dur, ch))
        else:
            relevant.append((rel_s, rel_e, txt))

    if not relevant:
        return False

    is_vertical = height > width
    font_size = int(round(height * (0.042 if is_vertical else 0.052)))
    outline = max(3, int(round(font_size * 0.09)))
    margin_v = int(round(height * (0.14 if is_vertical else 0.075)))
    margin_lr = int(round(width * 0.08))

    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Viral,DejaVu Sans,{font_size},&H00FFFFFF,&H0000FFFF,&H000A0B10,&H90000000,-1,0,0,0,100,100,0.5,0,1,{outline},2,2,{margin_lr},{margin_lr},{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = [header]
    for s, e, txt in relevant:
        safe = txt.replace("\\", "\\\\").replace("{", "(").replace("}", ")")
        lines.append(
            f"Dialogue: 0,{_format_ass_time(s)},{_format_ass_time(e)},Viral,,0,0,0,,{safe}"
        )
    ass_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return True


def _target_dimensions(
    resolution: ResolutionPreset,
    aspect_ratio: AspectRatio,
    src_w: int,
    src_h: int,
) -> tuple[int, int]:
    """Compute even-pixel target dimensions for the requested quality preset and aspect ratio."""
    if resolution in ("4k", "4k_native"):
        base_short = 2160
        if resolution == "4k_native":
            src_short = min(src_w, src_h) if src_w and src_h else 1080
            base_short = min(2160, max(360, src_short))
    elif resolution == "1440p":
        base_short = 1440
    else:
        base_short = 1080

    # Ensure even pixel alignment
    def even(x: float) -> int:
        v = int(round(x))
        return v if v % 2 == 0 else v + 1

    if aspect_ratio == "9:16":
        w = even(base_short)
        h = even(base_short * 16 / 9)
        return w, h
    if aspect_ratio == "1:1":
        side = even(base_short)
        return side, side
    # 16:9 landscape
    w = even(base_short * 16 / 9)
    h = even(base_short)
    return w, h


def _max_download_height(resolution: ResolutionPreset) -> int:
    if resolution in ("4k", "4k_native"):
        return 2160
    if resolution == "1440p":
        return 1440
    return 1080


def extract_and_master_clip(
    *,
    url: str,
    start_time: float,
    end_time: float,
    output_mp4: Path,
    poster_jpg: Path,
    resolution: ResolutionPreset = "4k",
    aspect_ratio: AspectRatio = "16:9",
    vertical_layout: VerticalLayout = "crop",
    burn_captions: bool = False,
    transcript: Optional[list[TranscriptSegment]] = None,
    progress_cb: Optional[Callable[[float, str], None]] = None,
) -> dict[str, Any]:
    """
    Download exact clip section using yt-dlp (up to native 4K 2160p) and master
    the final H.264/AAC MP4 + poster frame with FFmpeg, returning verified ffprobe metrics.
    """
    output_mp4.parent.mkdir(parents=True, exist_ok=True)
    duration = round(max(1.0, min(60.0, end_time - start_time)), 2)
    end_time = round(start_time + duration, 2)

    tmp_prefix = output_mp4.parent / f"_raw_{output_mp4.stem}"
    raw_file: Optional[Path] = None

    def report(pct: float, msg: str) -> None:
        if progress_cb:
            progress_cb(round(min(99.0, max(0.0, pct)), 1), msg)

    report(5.0, "Selecting highest-quality 4K stream via yt-dlp…")

    local_src = _resolve_local_upload(url)
    max_h = _max_download_height(resolution)

    try:
        if local_src:
            raw_candidate = tmp_prefix.with_suffix(".mp4")
            report(15.0, "Extracting exact segment from uploaded source…")
            cmd = [
                "ffmpeg",
                "-y",
                "-ss",
                f"{start_time:.2f}",
                "-t",
                f"{duration:.2f}",
                "-i",
                str(local_src),
                "-c",
                "copy",
                "-avoid_negative_ts",
                "make_zero",
                str(raw_candidate),
            ]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            if r.returncode != 0 or not raw_candidate.exists():
                raise RuntimeError(f"Failed to trim local video: {r.stderr[-300:]}")
            raw_file = raw_candidate

        elif _is_direct_media_url(url):
            # Resolve via yt-dlp first to confirm stream URL & headers, then fast-seek section
            raw_candidate = tmp_prefix.with_suffix(".mp4")
            report(12.0, "Extracting native 4K stream segment…")
            with yt_dlp.YoutubeDL(_base_ydl_opts({"skip_download": True})) as ydl:
                d_info = ydl.extract_info(url, download=False)
            stream_url = (d_info or {}).get("url") or url
            cmd = [
                "ffmpeg",
                "-y",
                "-ss",
                f"{start_time:.2f}",
                "-t",
                f"{duration:.2f}",
                "-i",
                stream_url,
                "-c",
                "copy",
                "-avoid_negative_ts",
                "make_zero",
                "-movflags",
                "+faststart",
                str(raw_candidate),
            ]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
            if r.returncode != 0 or not raw_candidate.exists():
                raise RuntimeError(f"Direct 4K section download failed: {r.stderr[-300:]}")
            raw_file = raw_candidate
            report(50.0, "4K source segment downloaded")

        else:
            # Standard yt-dlp precision section download targeting 4K 2160p first!
            def _ydl_hook(d: dict[str, Any]) -> None:
                if d.get("status") == "downloading":
                    total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                    done = d.get("downloaded_bytes") or 0
                    if total > 0:
                        pct = 10.0 + 42.0 * min(1.0, done / total)
                        report(pct, f"Downloading clip segment ({int(done / total * 100)}%)…")
                    else:
                        report(28.0, "Downloading clip segment via yt-dlp…")
                elif d.get("status") == "finished":
                    report(52.0, "Merging video & audio streams…")

            # Prioritize true 2160p (4K) streams (VP9 / AV1 / HEVC / H.264) + highest bitrate audio
            ydl_opts = _base_ydl_opts(
                {
                    "format": f"bestvideo[height<={max_h}]+bestaudio/best[height<={max_h}]/best",
                    "format_sort": [
                        f"res:{max_h}",
                        "fps",
                        "vcodec:h264,vp9.2,vp9,hevc,av01",
                        "br",
                        "acodec:m4a,opus",
                    ],
                    "download_ranges": yt_dlp.utils.download_range_func(
                        None, [(max(0.0, start_time), end_time)]
                    ),
                    "force_keyframes_at_cuts": False,
                    "outtmpl": f"{tmp_prefix}.%(ext)s",
                    "merge_output_format": "mkv",
                    "progress_hooks": [_ydl_hook],
                }
            )
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])

            # Locate downloaded temp artifact
            matches = sorted(
                output_mp4.parent.glob(f"{tmp_prefix.name}.*"),
                key=lambda p: p.stat().st_size,
                reverse=True,
            )
            matches = [m for m in matches if not m.name.endswith(".part")]
            if not matches:
                raise RuntimeError("yt-dlp did not produce a clip file for this time range.")
            raw_file = matches[0]

        # Inspect downloaded raw segment
        raw_probe = ffprobe_media(str(raw_file))
        src_w = int(raw_probe.get("width") or 1920)
        src_h = int(raw_probe.get("height") or 1080)
        src_codec = (raw_probe.get("codec") or "").lower()
        raw_dur = float(raw_probe.get("duration") or duration)

        target_w, target_h = _target_dimensions(resolution, aspect_ratio, src_w, src_h)
        is_upscaled = (target_h > src_h and aspect_ratio == "16:9") or (
            target_w > min(src_w, src_h) and aspect_ratio in ("9:16", "1:1")
        )

        # Prepare optional ASS burned-in subtitles
        ass_path = output_mp4.parent / f"_subs_{output_mp4.stem}.ass"
        has_ass = False
        if burn_captions and transcript:
            has_ass = _write_ass_captions(
                ass_path, transcript, start_time, end_time, target_w, target_h
            )

        # Lossless fast-path: source already matches target dimensions, H.264 browser-playable,
        # 16:9 aspect ratio, no caption burn-in, and accurate duration -> zero generation loss!
        can_lossless_copy = (
            not has_ass
            and aspect_ratio == "16:9"
            and src_w == target_w
            and src_h == target_h
            and src_codec == "h264"
            and abs(raw_dur - duration) <= 4.0
        )

        if can_lossless_copy:
            report(78.0, f"Mastering lossless {target_w}×{target_h} MP4…")
            copy_cmd = [
                "ffmpeg",
                "-y",
                "-i",
                str(raw_file),
                "-t",
                f"{min(60.0, duration):.2f}",
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-b:a",
                "256k",
                "-movflags",
                "+faststart",
                str(output_mp4),
            ]
            rc = subprocess.run(copy_cmd, capture_output=True, text=True, timeout=180)
            if rc.returncode != 0:
                can_lossless_copy = False

        if not can_lossless_copy:
            res_label = "4K UHD" if (target_w >= 3840 or target_h >= 3840) else f"{target_w}×{target_h}"
            report(62.0, f"Mastering {res_label} ({aspect_ratio}) video with FFmpeg…")

            ram_gb = _total_ram_gb()
            is_uhd = (target_w * target_h) >= (3840 * 2160 * 0.85)
            # Tune encoder dynamically across Render Free/Starter (512 MB), Standard (2 GB), and Pro (8 GB+)
            if ram_gb >= 7.5:
                preset = "fast" if is_uhd else "medium"
                crf = "18"
                x264_params = "rc-lookahead=25:ref=3"
                threads = "0"
            elif ram_gb <= 1.1:
                preset = "ultrafast"
                crf = "21" if is_uhd else "19"
                x264_params = "rc-lookahead=0:ref=1:sync-lookahead=0:bframes=0:mbtree=0"
                threads = "1"
            else:
                preset = "superfast" if is_uhd else "veryfast"
                crf = "20" if is_uhd else "18"
                x264_params = "rc-lookahead=8:ref=1:sync-lookahead=0:bframes=2"
                threads = "2"
            rate_cap = ["-maxrate", "24M", "-bufsize", "40M"] if is_uhd else []

            # Escape ASS path safely for FFmpeg filtergraph
            ass_escaped = (
                str(ass_path)
                .replace("\\", "/")
                .replace(":", "\\:")
                .replace("'", "\\'")
            )

            filter_args: list[str]
            if aspect_ratio == "9:16" and vertical_layout == "blur" and src_w > src_h:
                # Cinema blur-fill: blurred full-bleed 9:16 backdrop + crisp centered 16:9 foreground
                fg_chain = (
                    f"[0:v]scale={target_w}:-2:flags=lanczos[fg];"
                    f"[0:v]scale=540:960:force_original_aspect_ratio=increase,"
                    f"crop=540:960,boxblur=24:4,eq=brightness=-0.12:saturation=1.15,"
                    f"scale={target_w}:{target_h}:flags=bilinear[bg];"
                    f"[bg][fg]overlay=(W-w)/2:(H-h)/2"
                )
                if has_ass:
                    fg_chain += f",ass='{ass_escaped}'"
                fg_chain += ",format=yuv420p[vout]"
                filter_args = ["-filter_complex", fg_chain, "-map", "[vout]", "-map", "0:a?"]
            else:
                vf_parts: list[str] = []
                if aspect_ratio in ("9:16", "1:1"):
                    # Center-fill & crop to exact vertical/square 4K frame
                    vf_parts.append(
                        f"scale={target_w}:{target_h}:flags=lanczos:force_original_aspect_ratio=increase"
                    )
                    vf_parts.append(f"crop={target_w}:{target_h}")
                else:
                    vf_parts.append(
                        f"scale={target_w}:{target_h}:flags=lanczos:force_original_aspect_ratio=decrease"
                    )
                    vf_parts.append(f"pad={target_w}:{target_h}:(ow-iw)/2:(oh-ih)/2:black")

                # Subtle detail enhancement when upscaling HD source to 4K UHD
                if is_upscaled and not is_uhd:
                    vf_parts.append("unsharp=3:3:0.4:3:3:0.0")
                if has_ass:
                    vf_parts.append(f"ass='{ass_escaped}'")
                vf_parts.append("format=yuv420p")
                filter_args = ["-vf", ",".join(vf_parts)]

            enc_cmd = [
                "ffmpeg",
                "-y",
                "-i",
                str(raw_file),
                "-t",
                f"{min(60.0, duration):.2f}",
                *filter_args,
                "-c:v",
                "libx264",
                "-preset",
                preset,
                "-crf",
                crf,
                *rate_cap,
                "-profile:v",
                "high",
                "-level:v",
                "5.2" if is_uhd else "4.2",
                "-x264-params",
                x264_params,
                "-threads",
                threads,
                "-c:a",
                "aac",
                "-b:a",
                "256k",
                "-ar",
                "48000",
                "-movflags",
                "+faststart",
                "-progress",
                "pipe:1",
                "-nostats",
                str(output_mp4),
            ]

            proc = subprocess.Popen(
                enc_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                if line.startswith("out_time_ms="):
                    val = line.split("=", 1)[1].strip()
                    if val.isdigit():
                        sec_done = int(val) / 1_000_000.0
                        pct = 62.0 + 32.0 * min(1.0, sec_done / max(1.0, duration))
                        report(pct, f"Encoding {res_label} ({int(min(100, sec_done / max(1.0, duration) * 100))}%)…")
            stderr_out = proc.stderr.read() if proc.stderr else ""
            proc.wait(timeout=420)
            if proc.returncode != 0 or not output_mp4.exists():
                raise RuntimeError(f"FFmpeg 4K encode failed: {stderr_out[-350:]}")

        # Generate crisp poster thumbnail at ~25% into the clip
        report(96.0, "Generating preview thumbnail & verifying 4K specs…")
        final_probe = ffprobe_media(str(output_mp4))
        final_dur = float(final_probe.get("duration") or duration)
        poster_ts = min(max(0.4, final_dur * 0.25), max(0.0, final_dur - 0.3))
        poster_cmd = [
            "ffmpeg",
            "-y",
            "-ss",
            f"{poster_ts:.2f}",
            "-i",
            str(output_mp4),
            "-frames:v",
            "1",
            "-vf",
            "scale='min(960,iw)':-2",
            "-q:v",
            "3",
            str(poster_jpg),
        ]
        subprocess.run(poster_cmd, capture_output=True, timeout=30)

        out_w = int(final_probe.get("width") or target_w)
        out_h = int(final_probe.get("height") or target_h)
        is_4k = (
            (out_w >= 3840 or out_h >= 3840)
            or (out_w >= 2160 and out_h >= 2160)
        )

        report(100.0, "Clip ready")
        return {
            "width": out_w,
            "height": out_h,
            "codec": (final_probe.get("codec") or "h264").upper(),
            "fps": final_probe.get("fps"),
            "bitrate_kbps": final_probe.get("bitrate_kbps"),
            "duration": round(min(60.0, final_dur), 2),
            "file_size_bytes": final_probe.get("size_bytes") or output_mp4.stat().st_size,
            "is_4k": is_4k,
            "upscaled": is_upscaled,
            "has_poster": poster_jpg.exists(),
        }
    finally:
        # Clean up temporary raw segments & subtitle files immediately to keep workspace lean
        for junk in output_mp4.parent.glob(f"_raw_{output_mp4.stem}*"):
            junk.unlink(missing_ok=True)
        for junk in output_mp4.parent.glob(f"_subs_{output_mp4.stem}*"):
            junk.unlink(missing_ok=True)
