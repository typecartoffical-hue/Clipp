# ClipForge 4K — Render (Backend) + Vercel (Frontend) Deployment Guide (Hinglish)

AWS ko completely hata kar poora project ab **Render + Vercel** ke liye set aur deploy kar diya gaya hai! Render pe na koi SSH chahiye, na firewall/SSL setup — Render khud `Dockerfile` build karke free **`https://*.onrender.com`** HTTPS URL de deta hai.

- **Vercel Frontend:** `https://cliper-mu.vercel.app` *(Project: `cliper`; Render-ready source is included in this bundle. Production Vercel deployment still needs to be updated from this source.)*
- **Render Backend Blueprint:** `render.yaml` + `Dockerfile` *(Singapore region — India se sabse fast, CORS `https://cliper-mu.vercel.app` ke liye pre-configured!)*
- **Ready ZIP File:** `clipforge-render.zip` *(seedha download & GitHub pe push karne ke liye)*

---

## Step 1: Code Ko GitHub Repo Me Daalo (1 Minute)

1. Workspace se **`clipforge-render.zip`** download karke apne laptop/PC me unzip karo.
2. [github.com/new](https://github.com/new) pe ek naya repo banao (naam jaise `clipforge-4k`, Private ya Public dono chalega).
3. Unzipped folder ke andar terminal kholkar ye run karo:
   ```bash
   git init
   git add .
   git commit -m "ClipForge 4K Render backend + Vercel frontend"
   git branch -M main
   git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/clipforge-4k.git
   git push -u origin main
   ```
   *(Ya bina terminal ke seedha GitHub repo me **"uploading an existing file"** pe click karke unzipped files drag-and-drop karke Commit kar do — make sure `Dockerfile`, `render.yaml`, aur `backend/` root me hon!)*

---

## Step 2: Render Pe 1-Click Deploy Karo (2–3 Minutes)

### Tarika A — Render Blueprint (Sabse Easy, Recommended)
1. [dashboard.render.com](https://dashboard.render.com) pe login karo.
2. Upar **New +** → **Blueprint** pe click karo.
3. Apna **`clipforge-4k`** GitHub repo connect/select karo.
4. Render automatically `render.yaml` padh lega (`clipforge-4k-api`, Docker runtime, `FFmpeg` + `yt-dlp` + Node 20, Singapore region, `ALLOWED_ORIGINS` = `https://cliper-mu.vercel.app`, `/api/health` check).
5. **Deploy Blueprint** pe click karo!

### Tarika B — Manual Web Service (Agar Blueprint skip karna ho)
1. Render Dashboard → **New +** → **Web Service** → apna `clipforge-4k` repo select karo.
2. **Language / Runtime:** `Docker` choose karo.
3. **Region:** `Singapore (Southeast Asia)` choose karo.
4. **Instance Type:**
   - **Free ($0):** Testing aur short clips ke liye turant kaam karega (ClipForge automatically 512 MB RAM detect karke low-memory `ultrafast` encoder use karta hai; 15 min idle hone pe sleep hota hai aur next request pe ~30–50s me wake ho jata hai).
   - **Standard (2 GB RAM) / Pro (4 GB RAM):** Heavy/fast 4K UHD (2160p) encoding aur 24×7 always-on production ke liye best.
5. **Environment Variables** me add karo:
   - `ALLOWED_ORIGINS` = `https://cliper-mu.vercel.app,https://cliper-aich3.vercel.app`
6. **Deploy Web Service** click karo.

Build complete hote hi green **`Live`** badge aa jayega aur upar aapka Render HTTPS URL dikhega, jaise:
```text
https://clipforge-4k-api.onrender.com
```

---

## Step 3: Render URL Ko Vercel App (`cliper-mu.vercel.app`) Se Connect Karo

### Instant Connect (10 Seconds)
1. [https://cliper-mu.vercel.app](https://cliper-mu.vercel.app) open karo.
2. Top pe **"Connect Your Render Backend"** box me apna `https://clipforge-4k-api.onrender.com` URL paste karke **Connect** click karo *(ya seedha `https://cliper-mu.vercel.app/?api=https://clipforge-4k-api.onrender.com` open karo)*.
3. Header me green dot ke saath `yt-dlp` version aa jayega — ab seedha video link paste karke 4K clips banao!

### Permanent Connect (Sabhi Devices & Users Ke Liye)
- Bas apna **`https://....onrender.com`** URL mujhe yahan chat me bhej do — main aapke Vercel `cliper` project me `VITE_API_BASE_URL` set karke production redeploy kar dunga!
- *(Ya khud Vercel Dashboard → Project `cliper` → Settings → Environment Variables me `VITE_API_BASE_URL = https://clipforge-4k-api.onrender.com` add karke Redeploy click kar do.)*

---

## Step 4: Render Pe YouTube 4K Cookies Set Karo (`cookies.txt`)

Cloud IP hone ki wajah se YouTube kabhi-kabhi sign-in verify maangta hai. Render pe iske **2 easy tarike** hain:

1. **Direct Web App Se:** `https://cliper-mu.vercel.app` → **Settings → YouTube Auth (yt-dlp)** → **Upload cookies.txt** *(Incognito tab me YouTube login karke "Get cookies.txt LOCALLY" extension se export ki hui file)*.
2. **Permanent (Render Secret File — Free Plan Pe Bhi Kaam Karta Hai!):**
   - Render Dashboard → `clipforge-4k-api` → **Environment** → **Secret Files** → **Add Secret File**
   - **Filename:** `cookies.txt`
   - **Contents:** Apni Netscape `cookies.txt` ka text paste karke **Save** kar do.
   - ClipForge har restart/redeploy pe `/etc/secrets/cookies.txt` automatically load kar leta hai!

---

## Bonus: Persistent Disk (Optional — Paid Render Plan Ke Liye)
Agar aap Render Starter/Standard plan lete ho aur chahte ho ki purane 4K clips redeploy ke baad bhi saved rahein:
1. Render Service → **Disks** → **Add Disk** → Mount Path: `/var/data` (e.g. 20 GB).
2. **Environment** me `CLIPFORGE_STORAGE_DIR = /var/data` add kar do.
