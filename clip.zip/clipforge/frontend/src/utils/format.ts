export function formatTimecode(seconds: number, showTenths = false): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
  const total = showTenths ? Math.round(seconds * 10) / 10 : Math.round(seconds);
  const hrs = Math.floor(total / 3600);
  const mins = Math.floor((total % 3600) / 60);
  const secs = Math.floor(total % 60);
  const tenths = Math.round((total - Math.floor(total)) * 10);

  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  const base = hrs > 0 ? `${hrs}:${mm}:${ss}` : `${mm}:${ss}`;
  return showTenths ? `${base}.${tenths}` : base;
}

export function parseTimecode(input: string): number | null {
  const cleaned = input.trim();
  if (!cleaned) return null;
  if (/^\d+(\.\d+)?$/.test(cleaned)) {
    return parseFloat(cleaned);
  }
  const parts = cleaned.split(':').map((p) => p.trim());
  if (parts.some((p) => !/^\d+(\.\d+)?$/.test(p))) return null;
  if (parts.length === 2) {
    return parseInt(parts[0], 10) * 60 + parseFloat(parts[1]);
  }
  if (parts.length === 3) {
    return parseInt(parts[0], 10) * 3600 + parseInt(parts[1], 10) * 60 + parseFloat(parts[2]);
  }
  return null;
}

export function formatBytes(bytes?: number | null): string {
  if (!bytes || bytes <= 0) return '';
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

export function formatViews(count?: number | null): string {
  if (!count || count <= 0) return '';
  if (count >= 1_000_000_000) return `${(count / 1_000_000_000).toFixed(1)}B views`;
  if (count >= 1_000_000) return `${(count / 1_000_000).toFixed(1)}M views`;
  if (count >= 1_000) return `${(count / 1_000).toFixed(1)}K views`;
  return `${count} views`;
}

export function detectUrlSource(url: string): { label: string; isYouTube: boolean } | null {
  const trimmed = url.trim();
  if (!trimmed) return null;
  if (trimmed.startsWith('local://')) {
    return { label: 'Uploaded Video', isYouTube: false };
  }
  try {
    const parsed = new URL(trimmed);
    const h = parsed.hostname.toLowerCase();
    if (h.includes('youtube.com') || h.includes('youtu.be')) {
      return { label: 'YouTube', isYouTube: true };
    }
    if (h.includes('ted.com')) return { label: 'TED Talk', isYouTube: false };
    if (h.includes('twitch.tv')) return { label: 'Twitch', isYouTube: false };
    if (h.includes('vimeo.com')) return { label: 'Vimeo', isYouTube: false };
    if (parsed.pathname.toLowerCase().endsWith('.mp4')) {
      return { label: 'Direct MP4 Stream', isYouTube: false };
    }
    return { label: 'yt-dlp Stream', isYouTube: false };
  } catch {
    return null;
  }
}

export function scoreBadgeClasses(score: number): string {
  if (score >= 88) {
    return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
  }
  if (score >= 78) {
    return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
  }
  return 'bg-zinc-500/15 text-zinc-300 border-zinc-500/30';
}
