export type ResolutionPreset = '4k' | '4k_native' | '1440p' | '1080p';
export type AspectRatio = '16:9' | '9:16' | '1:1';
export type VerticalLayout = 'crop' | 'blur';
export type WorkflowMode = 'auto' | 'review';
export type AIProvider = 'auto' | 'builtin' | 'openai' | 'gemini' | 'anthropic' | 'custom';

export type JobStatus =
  | 'queued'
  | 'fetching_metadata'
  | 'analyzing'
  | 'awaiting_selection'
  | 'extracting'
  | 'completed'
  | 'failed'
  | 'cancelled';

export type ClipStatus = 'pending' | 'selected' | 'skipped' | 'extracting' | 'ready' | 'failed';

export interface SubScores {
  hook: number;
  retention: number;
  emotion: number;
  pacing: number;
}

export interface ClipItem {
  id: string;
  index: number;
  title: string;
  start_time: number;
  end_time: number;
  duration: number;
  virality_score: number;
  sub_scores: SubScores;
  reason: string;
  hook_quote: string;
  transcript: string;
  hashtags: string[];
  signals: string[];
  status: ClipStatus;
  progress: number;
  error?: string | null;
  filename?: string | null;
  poster_filename?: string | null;
  width?: number | null;
  height?: number | null;
  codec?: string | null;
  fps?: number | null;
  bitrate_kbps?: number | null;
  file_size_bytes?: number | null;
  is_4k: boolean;
  upscaled: boolean;
  aspect_ratio: AspectRatio;
  burn_captions: boolean;
}

export interface ChapterItem {
  title: string;
  start_time: number;
  end_time: number;
}

export interface VideoMetadata {
  id: string;
  url: string;
  title: string;
  channel: string;
  duration: number;
  thumbnail?: string | null;
  view_count?: number | null;
  upload_date?: string | null;
  extractor: string;
  max_source_height: number;
  max_source_width: number;
  has_native_4k: boolean;
  available_heights: number[];
  has_transcript: boolean;
  transcript_language?: string | null;
  transcript_word_count: number;
  has_heatmap: boolean;
  chapters: ChapterItem[];
  is_local_upload: boolean;
}

export interface JobRecord {
  id: string;
  created_at: string;
  updated_at: string;
  status: JobStatus;
  stage_message: string;
  error?: string | null;
  error_code?: string | null;
  overall_progress: number;
  url: string;
  clip_count: number;
  clip_duration: number;
  resolution: ResolutionPreset;
  aspect_ratio: AspectRatio;
  vertical_layout: VerticalLayout;
  burn_captions: boolean;
  smart_sentence_snap: boolean;
  focus_prompt: string;
  workflow_mode: WorkflowMode;
  ai_engine_used: string;
  video?: VideoMetadata | null;
  engagement_curve: number[];
  clips: ClipItem[];
}

export interface CreateJobPayload {
  url: string;
  clip_count: number;
  clip_duration: number;
  resolution: ResolutionPreset;
  aspect_ratio: AspectRatio;
  vertical_layout: VerticalLayout;
  burn_captions: boolean;
  smart_sentence_snap: boolean;
  focus_prompt: string;
  workflow_mode: WorkflowMode;
}

export interface HealthInfo {
  status: string;
  yt_dlp_version: string;
  ffmpeg_version: string;
  active_ai_label: string;
  has_cookies_file: boolean;
  cookie_count: number;
  auth_required?: boolean;
  max_clip_duration_seconds: number;
  max_export_resolution: string;
}

export interface PublicSettings {
  ai_provider: AIProvider;
  active_ai_label: string;
  has_openai_key: boolean;
  openai_key_masked: string;
  openai_model: string;
  has_gemini_key: boolean;
  gemini_key_masked: string;
  gemini_model: string;
  has_anthropic_key: boolean;
  anthropic_key_masked: string;
  anthropic_model: string;
  custom_base_url: string;
  has_custom_key: boolean;
  custom_model: string;
  has_cookies_file: boolean;
  cookie_count: number;
  cookies_from_browser: string;
  proxy_url: string;
}

export interface TranscriptSegment {
  start: number;
  end: number;
  text: string;
}
