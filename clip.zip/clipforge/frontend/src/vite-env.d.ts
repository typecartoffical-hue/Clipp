/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE_URL?: string;
  readonly VITE_API_SECRET?: string;
  readonly VITE_VPS_API_SECRET?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
