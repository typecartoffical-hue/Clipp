# ClipForge 4K — AI YouTube Viral Clip Studio

Turn long-form YouTube videos (or uploaded MP4/MOV/MKV/WebM files) into multiple standalone viral short clips (up to **60 seconds** each) mastered in **4K UHD (2160p)** using **`yt-dlp` + `FFmpeg` + AI viral moment detection**.

## Production Split Architecture (Vercel + Render)

- **Vercel Frontend:** [`https://cliper-mu.vercel.app`](https://cliper-mu.vercel.app) *(Vercel project: `cliper`; deploy the included frontend source to publish the Render connector.)*
- **Render Backend (1-Click Docker Blueprint):** [`render.yaml`](render.yaml) + [`Dockerfile`](Dockerfile) — runs `FastAPI` + `yt-dlp[default]` (with Node 20 JS runtime) + `FFmpeg` (cgroup-aware 4K UHD encoder + ASS caption burner) with automatic `https://*.onrender.com` HTTPS, `/api/health` checks, Render Secret File (`/etc/secrets/cookies.txt`) auto-loading, and optional Persistent Disk (`CLIPFORGE_STORAGE_DIR=/var/data`).
- **Step-by-Step Hinglish Guide:** [`RENDER_VERCEL_DEPLOY.md`](RENDER_VERCEL_DEPLOY.md)

### Quick Render Deploy

1. Push this directory (or unzip `clipforge-render.zip`) to a GitHub repository.
2. Open **Render Dashboard → New + → Blueprint** and select the repo — `render.yaml` configures everything automatically (including CORS for `https://cliper-mu.vercel.app`).
3. Copy your `https://<service>.onrender.com` URL and paste it into the **Connect Your Render Backend** bar on [`https://cliper-mu.vercel.app`](https://cliper-mu.vercel.app) (or set `VITE_API_BASE_URL` in Vercel Project Settings → Environment Variables).

---

## Features

- **Custom Clip Count & Duration** — Extract **1–12 clips** per video at any duration from **5s to 60s** (strictly capped at 60s on UI + API).
- **4K UHD Mastering** — Downloads native 4K 2160p via `yt-dlp` or masters lower-res sources to `3840×2160` (16:9), `2160×3840` (9:16 Shorts/Reels with Center Crop or Cinema Blur), or `2160×2160` (1:1), with automatic container-memory tuning (safe on Render 512 MB Free tier up to 8 GB+ Pro).
- **Hybrid AI Moment Detection** — Built-in zero-config viral analyzer (YouTube Most-Replayed heatmaps + transcript NLP + FFmpeg audio energy) plus optional **OpenAI**, **Google Gemini**, **Anthropic Claude**, or **Ollama / OpenAI-compatible** APIs.
- **Preview, Trim, Captions & Batch Download** — Inline + Theater 4K players, interactive virality timeline, searchable transcript clipper, per-clip re-trimming, burned-in captions, individual MP4 downloads, and one-click `.ZIP` download.

---

## Local Quick Start

```bash
./start.sh
# Serves FastAPI + compiled Studio UI at http://0.0.0.0:8000
```
