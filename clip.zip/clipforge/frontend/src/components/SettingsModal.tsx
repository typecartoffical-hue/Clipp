import { useEffect, useRef, useState } from 'react';
import {
  Check,
  Cpu,
  KeyRound,
  Loader2,
  Server,
  ShieldCheck,
  Trash2,
  Upload,
  Wifi,
  X,
} from 'lucide-react';
import { api, getSavedVpsConfig, saveVpsConfig } from '../api';
import type { AIProvider, PublicSettings } from '../types';

export type SettingsTab = 'vps' | 'ai' | 'youtube';

interface SettingsModalProps {
  open: boolean;
  initialTab?: SettingsTab;
  backendOnline: boolean;
  onClose: () => void;
  onUpdated: () => void;
}

export function SettingsModal({
  open,
  initialTab = 'ai',
  backendOnline,
  onClose,
  onUpdated,
}: SettingsModalProps) {
  const [tab, setTab] = useState<SettingsTab>(initialTab);
  const [settings, setSettings] = useState<PublicSettings | null>(null);

  // Render backend connection state
  const [vpsUrl, setVpsUrl] = useState('');
  const [vpsToken, setVpsToken] = useState('');
  const [envVpsUrl, setEnvVpsUrl] = useState('');
  const [testingVps, setTestingVps] = useState(false);

  // AI provider state
  const [aiProvider, setAiProvider] = useState<AIProvider>('auto');
  const [openaiKey, setOpenaiKey] = useState('');
  const [openaiModel, setOpenaiModel] = useState('gpt-4o-mini');
  const [geminiKey, setGeminiKey] = useState('');
  const [geminiModel, setGeminiModel] = useState('gemini-2.5-flash');
  const [anthropicKey, setAnthropicKey] = useState('');
  const [anthropicModel, setAnthropicModel] = useState('claude-sonnet-4-20250514');
  const [customBaseUrl, setCustomBaseUrl] = useState('http://localhost:11434/v1');
  const [customKey, setCustomKey] = useState('');
  const [customModel, setCustomModel] = useState('llama3.1');

  // YouTube yt-dlp auth state
  const [cookiesText, setCookiesText] = useState('');
  const [cookiesBrowser, setCookiesBrowser] = useState('');
  const [proxyUrl, setProxyUrl] = useState('');

  const [saving, setSaving] = useState(false);
  const [savedBanner, setSavedBanner] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const cookieFileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setTab(initialTab);
  }, [initialTab, open]);

  const loadBackendSettings = () => {
    api
      .getSettings()
      .then((s) => {
        setSettings(s);
        setAiProvider(s.ai_provider);
        setOpenaiModel(s.openai_model);
        setGeminiModel(s.gemini_model);
        setAnthropicModel(s.anthropic_model);
        setCustomBaseUrl(s.custom_base_url);
        setCustomModel(s.custom_model);
        setCookiesBrowser(s.cookies_from_browser);
        setProxyUrl(s.proxy_url);
      })
      .catch(() => {
        setSettings(null);
      });
  };

  useEffect(() => {
    if (!open) return;
    setSavedBanner(null);
    setError(null);
    const cfg = getSavedVpsConfig();
    setVpsUrl(cfg.url);
    setVpsToken(cfg.token);
    setEnvVpsUrl(cfg.envUrl);
    loadBackendSettings();
  }, [open]);

  if (!open) return null;

  const handleTestAndSaveVps = async () => {
    setTestingVps(true);
    setError(null);
    setSavedBanner(null);
    try {
      const { health, latencyMs, normalizedUrl } = await api.testVpsConnection(vpsUrl, vpsToken);
      saveVpsConfig(normalizedUrl, vpsToken);
      setVpsUrl(normalizedUrl);
      setSavedBanner(
        `Connected to Render (${latencyMs}ms) · yt-dlp ${health.yt_dlp_version} · FFmpeg ${health.ffmpeg_version}`
      );
      loadBackendSettings();
      onUpdated();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to reach Render backend');
    } finally {
      setTestingVps(false);
    }
  };

  const handleResetVps = () => {
    saveVpsConfig('', '');
    const cfg = getSavedVpsConfig();
    setVpsUrl(cfg.url);
    setVpsToken('');
    setSavedBanner('Reset to default backend URL.');
    setError(null);
    onUpdated();
  };

  const handleSave = async () => {
    if (tab === 'vps') {
      await handleTestAndSaveVps();
      return;
    }
    setSaving(true);
    setError(null);
    setSavedBanner(null);
    try {
      const patch: Record<string, unknown> = {
        ai_provider: aiProvider,
        openai_model: openaiModel,
        gemini_model: geminiModel,
        anthropic_model: anthropicModel,
        custom_base_url: customBaseUrl,
        custom_model: customModel,
        cookies_from_browser: cookiesBrowser,
        proxy_url: proxyUrl,
      };
      if (openaiKey.trim()) patch.openai_api_key = openaiKey.trim();
      if (geminiKey.trim()) patch.gemini_api_key = geminiKey.trim();
      if (anthropicKey.trim()) patch.anthropic_api_key = anthropicKey.trim();
      if (customKey.trim()) patch.custom_api_key = customKey.trim();
      if (cookiesText.trim()) patch.cookies_txt = cookiesText.trim();

      const updated = await api.updateSettings(patch);
      setSettings(updated);
      setOpenaiKey('');
      setGeminiKey('');
      setAnthropicKey('');
      setCustomKey('');
      setCookiesText('');
      setSavedBanner('Settings saved on Render backend.');
      onUpdated();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleCookieUpload = async (file: File) => {
    setSaving(true);
    setError(null);
    try {
      const updated = await api.uploadCookiesFile(file);
      setSettings(updated);
      setSavedBanner(`Loaded ${updated.cookie_count} YouTube cookies for yt-dlp.`);
      onUpdated();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to upload cookies.txt');
    } finally {
      setSaving(false);
    }
  };

  const handleClearCookies = async () => {
    setSaving(true);
    try {
      const updated = await api.clearCookiesFile();
      setSettings(updated);
      setSavedBanner('Cleared stored cookies.txt.');
      onUpdated();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[88vh] w-full max-w-xl flex-col overflow-hidden rounded-2xl border border-white/[0.1] bg-[#11131A] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/[0.07] px-6 py-4">
          <h2 className="text-base font-bold text-white">Studio Settings</h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-zinc-400 hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex overflow-x-auto border-b border-white/[0.07] px-6">
          <button
            type="button"
            onClick={() => {
              setTab('vps');
              setError(null);
              setSavedBanner(null);
            }}
            className={`inline-flex shrink-0 items-center gap-1.5 border-b-2 px-3 py-3 text-xs font-semibold transition ${
              tab === 'vps'
                ? 'border-[#FF5A36] text-white'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Server className="h-3.5 w-3.5" />
            Render API
            <span
              className={`h-1.5 w-1.5 rounded-full ${
                backendOnline ? 'bg-emerald-400' : 'bg-amber-400'
              }`}
            />
          </button>

          <button
            type="button"
            onClick={() => {
              setTab('ai');
              setError(null);
              setSavedBanner(null);
            }}
            className={`inline-flex shrink-0 items-center gap-1.5 border-b-2 px-3 py-3 text-xs font-semibold transition ${
              tab === 'ai'
                ? 'border-[#FF5A36] text-white'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Cpu className="h-3.5 w-3.5" />
            AI Analyzer
          </button>

          <button
            type="button"
            onClick={() => {
              setTab('youtube');
              setError(null);
              setSavedBanner(null);
            }}
            className={`inline-flex shrink-0 items-center gap-1.5 border-b-2 px-3 py-3 text-xs font-semibold transition ${
              tab === 'youtube'
                ? 'border-[#FF5A36] text-white'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <KeyRound className="h-3.5 w-3.5" />
            YouTube Auth (yt-dlp)
            {settings?.has_cookies_file && (
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            )}
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 space-y-4 overflow-y-auto px-6 py-5 text-xs">
          {tab === 'vps' ? (
            <>
              <div className="rounded-xl border border-white/[0.06] bg-[#0B0D13] p-3.5 leading-relaxed">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-zinc-200">
                    Vercel Frontend ↔ Render Docker Backend
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-mono text-[10px] font-semibold ${
                      backendOnline
                        ? 'bg-emerald-500/15 text-emerald-300'
                        : 'bg-amber-500/15 text-amber-300'
                    }`}
                  >
                    <Wifi className="h-3 w-3" />
                    {backendOnline ? 'Online' : 'Not Connected'}
                  </span>
                </div>
                <p className="mt-1.5 text-zinc-400">
                  Deploy this repo to Render using the included{' '}
                  <code className="text-zinc-200">render.yaml</code> Blueprint (or Docker Web
                  Service), then paste your <code className="text-zinc-200">https://*.onrender.com</code>{' '}
                  URL below — or set <code className="text-zinc-200">VITE_API_BASE_URL</code> in
                  Vercel for all visitors.
                </p>
              </div>

              <div>
                <label className="mb-1.5 block font-semibold text-zinc-300">
                  Render Backend URL (HTTPS)
                </label>
                <input
                  type="url"
                  value={vpsUrl}
                  onChange={(e) => setVpsUrl(e.target.value)}
                  placeholder="https://clipforge-4k-api.onrender.com"
                  className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-3 py-2.5 font-mono text-xs text-white placeholder-zinc-600 focus:border-[#FF5A36] focus:outline-none"
                />
                {envVpsUrl && (
                  <p className="mt-1 font-mono text-[11px] text-zinc-500">
                    Vercel default (VITE_API_BASE_URL): {envVpsUrl}
                  </p>
                )}
              </div>

              <div>
                <label className="mb-1.5 block font-medium text-zinc-400">
                  API Secret Token (optional — only if <code className="text-zinc-300">API_SECRET</code> is set on Render)
                </label>
                <input
                  type="password"
                  value={vpsToken}
                  onChange={(e) => setVpsToken(e.target.value)}
                  placeholder="Leave blank if not enabled"
                  className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-3 py-2 font-mono text-xs text-white placeholder-zinc-600 focus:border-[#FF5A36] focus:outline-none"
                />
              </div>

              {vpsUrl && (
                <button
                  type="button"
                  onClick={handleResetVps}
                  className="text-[11px] text-zinc-400 underline hover:text-zinc-200"
                >
                  Clear custom backend override
                </button>
              )}
            </>
          ) : tab === 'ai' ? (
            <>
              <div className="rounded-xl border border-white/[0.06] bg-[#0B0D13] p-3.5">
                <span className="text-zinc-400">Active Engine: </span>
                <strong className="text-emerald-300">
                  {settings?.active_ai_label || 'ClipForge Viral AI'}
                </strong>
                <p className="mt-1 leading-relaxed text-zinc-500">
                  Works out of the box using YouTube Most-Replayed heatmaps, transcript NLP hook/emotion scoring, and audio energy peaks. Connect an LLM API key below for deeper semantic moment selection.
                </p>
              </div>

              <div>
                <label className="mb-1.5 block font-semibold text-zinc-300">Preferred AI Provider</label>
                <select
                  value={aiProvider}
                  onChange={(e) => setAiProvider(e.target.value as AIProvider)}
                  className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-3 py-2 text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                >
                  <option value="auto">Auto (Use connected LLM key, else Built-in Viral AI)</option>
                  <option value="builtin">Built-in ClipForge Viral AI (No API key needed)</option>
                  <option value="openai">OpenAI (GPT-4o / GPT-4o-mini)</option>
                  <option value="gemini">Google Gemini (Gemini 2.5 Flash)</option>
                  <option value="anthropic">Anthropic (Claude Sonnet)</option>
                  <option value="custom">Custom OpenAI-Compatible / Ollama</option>
                </select>
              </div>

              {(aiProvider === 'openai' || aiProvider === 'auto') && (
                <div className="grid gap-2.5 rounded-xl border border-white/[0.06] bg-[#0D0F16] p-3.5 sm:grid-cols-[1.5fr_1fr]">
                  <div>
                    <label className="mb-1 block text-zinc-400">
                      OpenAI API Key{' '}
                      {settings?.has_openai_key && (
                        <span className="text-emerald-400">({settings.openai_key_masked})</span>
                      )}
                    </label>
                    <input
                      type="password"
                      value={openaiKey}
                      onChange={(e) => setOpenaiKey(e.target.value)}
                      placeholder="sk-..."
                      className="w-full rounded-lg border border-white/10 bg-[#141824] px-2.5 py-1.5 font-mono text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-zinc-400">Model</label>
                    <input
                      type="text"
                      value={openaiModel}
                      onChange={(e) => setOpenaiModel(e.target.value)}
                      className="w-full rounded-lg border border-white/10 bg-[#141824] px-2.5 py-1.5 font-mono text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {(aiProvider === 'gemini' || aiProvider === 'auto') && (
                <div className="grid gap-2.5 rounded-xl border border-white/[0.06] bg-[#0D0F16] p-3.5 sm:grid-cols-[1.5fr_1fr]">
                  <div>
                    <label className="mb-1 block text-zinc-400">
                      Google Gemini API Key{' '}
                      {settings?.has_gemini_key && (
                        <span className="text-emerald-400">({settings.gemini_key_masked})</span>
                      )}
                    </label>
                    <input
                      type="password"
                      value={geminiKey}
                      onChange={(e) => setGeminiKey(e.target.value)}
                      placeholder="AIza..."
                      className="w-full rounded-lg border border-white/10 bg-[#141824] px-2.5 py-1.5 font-mono text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-zinc-400">Model</label>
                    <input
                      type="text"
                      value={geminiModel}
                      onChange={(e) => setGeminiModel(e.target.value)}
                      className="w-full rounded-lg border border-white/10 bg-[#141824] px-2.5 py-1.5 font-mono text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {(aiProvider === 'anthropic' || aiProvider === 'auto') && (
                <div className="grid gap-2.5 rounded-xl border border-white/[0.06] bg-[#0D0F16] p-3.5 sm:grid-cols-[1.5fr_1fr]">
                  <div>
                    <label className="mb-1 block text-zinc-400">
                      Anthropic API Key{' '}
                      {settings?.has_anthropic_key && (
                        <span className="text-emerald-400">({settings.anthropic_key_masked})</span>
                      )}
                    </label>
                    <input
                      type="password"
                      value={anthropicKey}
                      onChange={(e) => setAnthropicKey(e.target.value)}
                      placeholder="sk-ant-..."
                      className="w-full rounded-lg border border-white/10 bg-[#141824] px-2.5 py-1.5 font-mono text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-zinc-400">Model</label>
                    <input
                      type="text"
                      value={anthropicModel}
                      onChange={(e) => setAnthropicModel(e.target.value)}
                      className="w-full rounded-lg border border-white/10 bg-[#141824] px-2.5 py-1.5 font-mono text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {aiProvider === 'custom' && (
                <div className="space-y-2.5 rounded-xl border border-white/[0.06] bg-[#0D0F16] p-3.5">
                  <div>
                    <label className="mb-1 block text-zinc-400">Base URL</label>
                    <input
                      type="text"
                      value={customBaseUrl}
                      onChange={(e) => setCustomBaseUrl(e.target.value)}
                      placeholder="http://localhost:11434/v1"
                      className="w-full rounded-lg border border-white/10 bg-[#141824] px-2.5 py-1.5 font-mono text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="mb-1 block text-zinc-400">Model Name</label>
                      <input
                        type="text"
                        value={customModel}
                        onChange={(e) => setCustomModel(e.target.value)}
                        className="w-full rounded-lg border border-white/10 bg-[#141824] px-2.5 py-1.5 font-mono text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-zinc-400">API Key (optional)</label>
                      <input
                        type="password"
                        value={customKey}
                        onChange={(e) => setCustomKey(e.target.value)}
                        className="w-full rounded-lg border border-white/10 bg-[#141824] px-2.5 py-1.5 font-mono text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              <div className="rounded-xl border border-white/[0.06] bg-[#0B0D13] p-3.5 leading-relaxed text-zinc-400">
                <p className="font-semibold text-zinc-200">
                  Render Cloud YouTube Authentication
                </p>
                <p className="mt-1">
                  Because Render uses cloud IPs, YouTube may ask{' '}
                  <code className="text-zinc-200">yt-dlp</code> to confirm sign-in. Upload a
                  Netscape-format <code className="text-zinc-200">cookies.txt</code> below (or save
                  it in Render → Environment → Secret Files as{' '}
                  <code className="text-zinc-200">cookies.txt</code> so it survives redeploys) to
                  unlock unrestricted native 4K 2160p YouTube downloads on Render.
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/[0.07] bg-[#0D0F16] p-3.5">
                <div className="flex items-center gap-2">
                  <ShieldCheck
                    className={`h-4 w-4 ${
                      settings?.has_cookies_file ? 'text-emerald-400' : 'text-zinc-500'
                    }`}
                  />
                  <span>
                    {settings?.has_cookies_file ? (
                      <strong className="text-emerald-300">
                        cookies.txt active ({settings.cookie_count} entries)
                      </strong>
                    ) : (
                      <span className="text-zinc-400">No cookies.txt uploaded</span>
                    )}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    ref={cookieFileRef}
                    type="file"
                    accept=".txt,text/plain"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) void handleCookieUpload(f);
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => cookieFileRef.current?.click()}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-[#FF5A36] px-3 py-1.5 text-xs font-semibold text-white hover:brightness-110"
                  >
                    <Upload className="h-3.5 w-3.5" />
                    Upload cookies.txt
                  </button>
                  {settings?.has_cookies_file && (
                    <button
                      type="button"
                      onClick={() => void handleClearCookies()}
                      className="rounded-lg border border-white/10 p-1.5 text-zinc-400 hover:text-red-300"
                      title="Remove cookies.txt"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label className="mb-1 block font-medium text-zinc-300">
                  Or Paste Netscape cookies.txt Content
                </label>
                <textarea
                  rows={4}
                  value={cookiesText}
                  onChange={(e) => setCookiesText(e.target.value)}
                  placeholder="# Netscape HTTP Cookie File&#10;.youtube.com	TRUE	/	TRUE	..."
                  className="w-full rounded-lg border border-white/10 bg-[#0B0D13] p-2.5 font-mono text-[11px] text-zinc-200 placeholder-zinc-600 focus:border-[#FF5A36] focus:outline-none"
                />
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block font-medium text-zinc-400">
                    Local Browser Cookies (desktop only)
                  </label>
                  <select
                    value={cookiesBrowser}
                    onChange={(e) => setCookiesBrowser(e.target.value)}
                    className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-2.5 py-2 text-xs text-white focus:border-[#FF5A36] focus:outline-none"
                  >
                    <option value="">Disabled</option>
                    <option value="chrome">Chrome</option>
                    <option value="firefox">Firefox</option>
                    <option value="brave">Brave</option>
                    <option value="edge">Edge</option>
                    <option value="safari">Safari</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1 block font-medium text-zinc-400">
                    Residential Proxy URL (optional)
                  </label>
                  <input
                    type="text"
                    value={proxyUrl}
                    onChange={(e) => setProxyUrl(e.target.value)}
                    placeholder="socks5://user:pass@host:1080"
                    className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-2.5 py-2 font-mono text-xs text-white placeholder-zinc-600 focus:border-[#FF5A36] focus:outline-none"
                  />
                </div>
              </div>
            </>
          )}

          {savedBanner && (
            <div className="flex items-center gap-2 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-emerald-200">
              <Check className="h-3.5 w-3.5 shrink-0" />
              <span>{savedBanner}</span>
            </div>
          )}
          {error && (
            <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-red-200">
              {error}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 border-t border-white/[0.07] px-6 py-3.5">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-white/10 px-4 py-2 text-xs font-medium text-zinc-300 hover:bg-white/[0.05]"
          >
            Close
          </button>
          <button
            type="button"
            disabled={saving || testingVps}
            onClick={() => void handleSave()}
            className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#FF5A36] to-[#FF7B3A] px-4 py-2 text-xs font-bold text-white shadow hover:brightness-110 disabled:opacity-50"
          >
            {(saving || testingVps) && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {tab === 'vps'
              ? testingVps
                ? 'Waking & Testing Render…'
                : 'Test & Connect Render'
              : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  );
}
