import { useRef, useState } from 'react';
import {
  ChevronDown,
  Clock,
  Film,
  Link2,
  Loader2,
  Minus,
  Monitor,
  Plus,
  RectangleVertical,
  SlidersHorizontal,
  Sparkles,
  Square,
  Subtitles,
  Upload,
} from 'lucide-react';
import { api } from '../api';
import type {
  AspectRatio,
  CreateJobPayload,
  ResolutionPreset,
  VerticalLayout,
  WorkflowMode,
} from '../types';
import { detectUrlSource, formatBytes } from '../utils/format';

interface VideoComposerProps {
  submitting: boolean;
  initialUrl?: string;
  onSubmit: (payload: CreateJobPayload) => Promise<void>;
}

const DURATION_PRESETS = [15, 30, 45, 60] as const;

const SAMPLE_VIDEOS = [
  {
    label: 'TED Talk · 13:54 (Transcript + AI Hooks)',
    url: 'https://www.ted.com/talks/tim_urban_inside_the_mind_of_a_master_procrastinator',
    defaultDuration: 20,
    defaultCount: 3,
  },
  {
    label: 'Blender Film · 10:34 (Native 4K 3840×2160)',
    url: 'http://distribution.bbb3d.renderfarming.net/video/mp4/bbb_sunflower_2160p_30fps_normal.mp4',
    defaultDuration: 15,
    defaultCount: 3,
  },
];

export function VideoComposer({
  submitting,
  initialUrl = '',
  onSubmit,
}: VideoComposerProps) {
  const [inputMode, setInputMode] = useState<'url' | 'upload'>('url');
  const [url, setUrl] = useState(initialUrl);
  const [uploadedInfo, setUploadedInfo] = useState<{
    local_url: string;
    filename: string;
    size_bytes: number;
  } | null>(null);
  const [uploading, setUploading] = useState(false);

  const [clipCount, setClipCount] = useState(3);
  const [clipDuration, setClipDuration] = useState(30);
  const [resolution, setResolution] = useState<ResolutionPreset>('4k');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [verticalLayout, setVerticalLayout] = useState<VerticalLayout>('crop');
  const [burnCaptions, setBurnCaptions] = useState(false);
  const [smartSnap, setSmartSnap] = useState(true);
  const [workflowMode, setWorkflowMode] = useState<WorkflowMode>('auto');
  const [focusPrompt, setFocusPrompt] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const detected = detectUrlSource(url);

  const handleFilePick = async (file: File) => {
    setFormError(null);
    setUploading(true);
    try {
      const res = await api.uploadLocalVideo(file);
      setUploadedInfo(res);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const activeUrl = inputMode === 'upload' ? uploadedInfo?.local_url || '' : url.trim();
    if (!activeUrl) {
      setFormError(
        inputMode === 'upload'
          ? 'Upload a long-form video file first.'
          : 'Paste a YouTube video URL to get started.'
      );
      return;
    }
    if (
      inputMode === 'url' &&
      !activeUrl.startsWith('http://') &&
      !activeUrl.startsWith('https://')
    ) {
      setFormError('Enter a full URL beginning with https:// (e.g. https://www.youtube.com/watch?v=...)');
      return;
    }

    try {
      await onSubmit({
        url: activeUrl,
        clip_count: clipCount,
        clip_duration: Math.min(60, Math.max(5, clipDuration)),
        resolution,
        aspect_ratio: aspectRatio,
        vertical_layout: verticalLayout,
        burn_captions: burnCaptions,
        smart_sentence_snap: smartSnap,
        focus_prompt: focusPrompt.trim(),
        workflow_mode: workflowMode,
      });
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to create job');
    }
  };

  const resShortLabel =
    resolution === '4k'
      ? '4K UHD'
      : resolution === '4k_native'
      ? 'Native ≤4K'
      : resolution.toUpperCase();

  return (
    <section className="mx-auto max-w-4xl pt-8 pb-12 sm:pt-12">
      {/* Studio Heading */}
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-[42px] sm:leading-[1.12]">
          Turn long YouTube videos into{' '}
          <span className="bg-gradient-to-r from-[#FF5A36] to-[#FF9457] bg-clip-text text-transparent">
            viral 4K clips
          </span>
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-zinc-400 sm:text-[15px]">
          Paste any long-form video link. AI pinpoints peak hooks and high-retention moments,
          then extracts standalone short clips up to 60 seconds in 4K UHD with{' '}
          <code className="rounded bg-white/[0.06] px-1.5 py-0.5 text-xs text-zinc-200">yt-dlp</code>.
        </p>
      </div>

      {/* Main Studio Composer Card */}
      <form
        onSubmit={handleSubmit}
        className="rounded-2xl border border-white/[0.08] bg-[#11131A] p-5 shadow-2xl shadow-black/50 sm:p-7"
      >
        {/* Source Mode Switch */}
        <div className="mb-3.5 flex items-center justify-between gap-3">
          <div className="inline-flex rounded-lg border border-white/[0.07] bg-[#0B0D13] p-0.5">
            <button
              type="button"
              onClick={() => {
                setInputMode('url');
                setFormError(null);
              }}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition ${
                inputMode === 'url'
                  ? 'bg-[#191D29] text-white shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Link2 className="h-3.5 w-3.5" />
              YouTube / Video URL
            </button>
            <button
              type="button"
              onClick={() => {
                setInputMode('upload');
                setFormError(null);
              }}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition ${
                inputMode === 'upload'
                  ? 'bg-[#191D29] text-white shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Upload className="h-3.5 w-3.5" />
              Upload Video File
            </button>
          </div>

          {inputMode === 'url' && detected && (
            <span
              className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-medium ${
                detected.isYouTube
                  ? 'bg-red-500/15 text-red-300 ring-1 ring-red-500/30'
                  : 'bg-emerald-500/12 text-emerald-300 ring-1 ring-emerald-500/25'
              }`}
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  detected.isYouTube ? 'bg-red-400' : 'bg-emerald-400'
                }`}
              />
              {detected.label} detected
            </span>
          )}
        </div>

        {/* URL Input or File Dropzone */}
        {inputMode === 'url' ? (
          <div>
            <div className="relative flex items-center">
              <div className="pointer-events-none absolute left-4 flex items-center text-zinc-500">
                <svg className="h-5 w-5 text-[#FF5A36]" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                </svg>
              </div>
              <input
                type="url"
                value={url}
                onChange={(e) => {
                  setUrl(e.target.value);
                  if (formError) setFormError(null);
                }}
                placeholder="Paste a YouTube video link — https://www.youtube.com/watch?v=..."
                className="w-full rounded-xl border border-white/[0.1] bg-[#0B0D13] py-3.5 pl-12 pr-20 text-sm text-white placeholder-zinc-500 transition focus:border-[#FF5A36]/70 focus:ring-2 focus:ring-[#FF5A36]/20 focus:outline-none sm:text-[15px]"
                aria-label="YouTube video URL"
              />
              {url && (
                <button
                  type="button"
                  onClick={() => setUrl('')}
                  className="absolute right-3 rounded-md px-2 py-1 text-xs text-zinc-400 hover:bg-white/[0.06] hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Quick live-pipeline sample buttons */}
            <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-zinc-500">Quick test:</span>
              {SAMPLE_VIDEOS.map((sample) => (
                <button
                  key={sample.url}
                  type="button"
                  onClick={() => {
                    setUrl(sample.url);
                    setClipDuration(sample.defaultDuration);
                    setClipCount(sample.defaultCount);
                    setFormError(null);
                  }}
                  className="rounded-md border border-white/[0.07] bg-white/[0.03] px-2.5 py-1 text-[11px] text-zinc-300 transition hover:border-[#FF5A36]/40 hover:bg-[#FF5A36]/10 hover:text-white"
                >
                  {sample.label}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div
            onClick={() => fileInputRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              const f = e.dataTransfer.files?.[0];
              if (f) void handleFilePick(f);
            }}
            className="flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-white/[0.14] bg-[#0B0D13] px-6 py-7 text-center transition hover:border-[#FF5A36]/50 hover:bg-[#0E1119]"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="video/mp4,video/quicktime,video/webm,video/x-matroska,.mp4,.mov,.mkv,.webm"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void handleFilePick(f);
              }}
            />
            {uploading ? (
              <div className="flex items-center gap-2.5 text-sm text-zinc-300">
                <Loader2 className="h-4 w-4 animate-spin text-[#FF5A36]" />
                Uploading source video…
              </div>
            ) : uploadedInfo ? (
              <div>
                <p className="text-sm font-semibold text-emerald-300">{uploadedInfo.filename}</p>
                <p className="mt-1 font-mono text-xs text-zinc-400">
                  {formatBytes(uploadedInfo.size_bytes)} · Ready to analyze & clip in 4K (click to replace)
                </p>
              </div>
            ) : (
              <div>
                <Upload className="mx-auto mb-2 h-5 w-5 text-zinc-400" />
                <p className="text-sm font-medium text-zinc-200">
                  Drop a long-form video here or click to browse
                </p>
                <p className="mt-1 text-xs text-zinc-500">MP4, MOV, MKV, or WebM up to 2 GB</p>
              </div>
            )}
          </div>
        )}

        {/* Divider */}
        <div className="my-6 border-t border-white/[0.06]" />

        {/* Core Parameters Grid: Clip Count & Clip Duration */}
        <div className="grid gap-5 sm:grid-cols-2">
          {/* 1. Number of Clips */}
          <div className="rounded-xl border border-white/[0.06] bg-[#0D0F16] p-4">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-1.5 text-xs font-semibold tracking-wide text-zinc-300 uppercase">
                <Film className="h-3.5 w-3.5 text-[#FF5A36]" />
                Clips to Extract
              </label>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setClipCount((c) => Math.max(1, c - 1))}
                  className="flex h-6 w-6 items-center justify-center rounded-md border border-white/10 bg-[#171B26] text-zinc-300 hover:border-white/25 hover:text-white"
                  aria-label="Decrease clip count"
                >
                  <Minus className="h-3 w-3" />
                </button>
                <span className="min-w-[56px] text-center font-mono text-sm font-semibold text-white">
                  {clipCount} {clipCount === 1 ? 'clip' : 'clips'}
                </span>
                <button
                  type="button"
                  onClick={() => setClipCount((c) => Math.min(12, c + 1))}
                  className="flex h-6 w-6 items-center justify-center rounded-md border border-white/10 bg-[#171B26] text-zinc-300 hover:border-white/25 hover:text-white"
                  aria-label="Increase clip count"
                >
                  <Plus className="h-3 w-3" />
                </button>
              </div>
            </div>
            <input
              type="range"
              min={1}
              max={12}
              step={1}
              value={clipCount}
              onChange={(e) => setClipCount(Number(e.target.value))}
              className="studio-slider mt-4 w-full"
              aria-label="Number of clips"
            />
            <div className="mt-2 flex justify-between font-mono text-[11px] text-zinc-500">
              <span>1 clip</span>
              <span>6 clips</span>
              <span>12 clips</span>
            </div>
          </div>

          {/* 2. Custom Clip Duration (up to 60s) */}
          <div className="rounded-xl border border-white/[0.06] bg-[#0D0F16] p-4">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-1.5 text-xs font-semibold tracking-wide text-zinc-300 uppercase">
                <Clock className="h-3.5 w-3.5 text-[#FF5A36]" />
                Clip Duration
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min={5}
                  max={60}
                  value={clipDuration}
                  onChange={(e) => {
                    const v = parseInt(e.target.value || '5', 10);
                    setClipDuration(Math.min(60, Math.max(5, Number.isNaN(v) ? 30 : v)));
                  }}
                  className="w-14 rounded-md border border-white/10 bg-[#171B26] px-2 py-0.5 text-center font-mono text-sm font-semibold text-white focus:border-[#FF5A36] focus:outline-none"
                  aria-label="Clip duration in seconds"
                />
                <span className="font-mono text-xs text-zinc-400">sec (max 60s)</span>
              </div>
            </div>
            <input
              type="range"
              min={5}
              max={60}
              step={1}
              value={clipDuration}
              onChange={(e) => setClipDuration(Number(e.target.value))}
              className="studio-slider mt-4 w-full"
              aria-label="Clip duration slider"
            />
            <div className="mt-2.5 grid grid-cols-4 gap-1.5">
              {DURATION_PRESETS.map((sec) => (
                <button
                  key={sec}
                  type="button"
                  onClick={() => setClipDuration(sec)}
                  className={`rounded-md py-1 font-mono text-[11px] font-medium transition ${
                    clipDuration === sec
                      ? 'bg-[#FF5A36]/20 text-[#FF8566] ring-1 ring-[#FF5A36]/45'
                      : 'bg-white/[0.04] text-zinc-400 hover:bg-white/[0.08] hover:text-zinc-200'
                  }`}
                >
                  {sec}s
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Quality & Aspect Ratio Row */}
        <div className="mt-4 grid gap-5 sm:grid-cols-2">
          {/* 3. Export Resolution (4K Default) */}
          <div className="rounded-xl border border-white/[0.06] bg-[#0D0F16] p-4">
            <div className="mb-2.5 flex items-center justify-between">
              <span className="text-xs font-semibold tracking-wide text-zinc-300 uppercase">
                Export Resolution
              </span>
              <span className="font-mono text-[11px] text-[#FF8566]">
                {resolution === '4k'
                  ? '2160p UHD Master'
                  : resolution === '4k_native'
                  ? 'Lossless ≤ 2160p'
                  : resolution === '1440p'
                  ? '2560×1440 QHD'
                  : '1920×1080 FHD'}
              </span>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {(
                [
                  { id: '4k', label: '4K UHD', sub: '2160p' },
                  { id: '4k_native', label: 'Auto 4K', sub: 'Native' },
                  { id: '1440p', label: '1440p', sub: 'QHD' },
                  { id: '1080p', label: '1080p', sub: 'FHD' },
                ] as const
              ).map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setResolution(opt.id)}
                  className={`flex flex-col items-center rounded-lg px-2 py-2 text-center transition ${
                    resolution === opt.id
                      ? 'bg-[#FF5A36]/18 text-white ring-1 ring-[#FF5A36]/55'
                      : 'bg-white/[0.03] text-zinc-400 hover:bg-white/[0.07] hover:text-zinc-200'
                  }`}
                >
                  <span className="text-xs font-semibold">{opt.label}</span>
                  <span className="font-mono text-[10px] text-zinc-400">{opt.sub}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 4. Frame Format / Aspect Ratio */}
          <div className="rounded-xl border border-white/[0.06] bg-[#0D0F16] p-4">
            <div className="mb-2.5 flex items-center justify-between">
              <span className="text-xs font-semibold tracking-wide text-zinc-300 uppercase">
                Frame Format
              </span>
              <span className="font-mono text-[11px] text-zinc-400">
                {aspectRatio === '16:9'
                  ? '3840×2160'
                  : aspectRatio === '9:16'
                  ? '2160×3840 Shorts'
                  : '2160×2160 Square'}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {(
                [
                  { id: '16:9', label: '16:9 Original', Icon: Monitor },
                  { id: '9:16', label: '9:16 Vertical', Icon: RectangleVertical },
                  { id: '1:1', label: '1:1 Square', Icon: Square },
                ] as const
              ).map(({ id, label, Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setAspectRatio(id)}
                  className={`flex flex-col items-center gap-1 rounded-lg px-2 py-2 text-center transition ${
                    aspectRatio === id
                      ? 'bg-[#FF5A36]/18 text-white ring-1 ring-[#FF5A36]/55'
                      : 'bg-white/[0.03] text-zinc-400 hover:bg-white/[0.07] hover:text-zinc-200'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  <span className="text-[11px] font-medium">{label}</span>
                </button>
              ))}
            </div>
            {aspectRatio === '9:16' && (
              <div className="mt-2.5 flex items-center justify-between border-t border-white/[0.06] pt-2 text-[11px]">
                <span className="text-zinc-400">Vertical framing:</span>
                <div className="flex gap-1.5">
                  {(
                    [
                      { id: 'crop', label: 'Center Crop' },
                      { id: 'blur', label: 'Cinema Blur' },
                    ] as const
                  ).map((vl) => (
                    <button
                      key={vl.id}
                      type="button"
                      onClick={() => setVerticalLayout(vl.id)}
                      className={`rounded px-2 py-0.5 font-medium transition ${
                        verticalLayout === vl.id
                          ? 'bg-white/15 text-white'
                          : 'text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      {vl.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Collapsible AI Director & Subtitle Options */}
        <div className="mt-4">
          <button
            type="button"
            onClick={() => setShowAdvanced((s) => !s)}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-400 transition hover:text-zinc-200"
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
            <span>AI Director & Caption Options</span>
            <ChevronDown
              className={`h-3.5 w-3.5 transition-transform ${showAdvanced ? 'rotate-180' : ''}`}
            />
          </button>

          {showAdvanced && (
            <div className="mt-3 space-y-3.5 rounded-xl border border-white/[0.06] bg-[#0D0F16] p-4">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-zinc-300">
                  AI Topic / Moment Guidance (optional)
                </label>
                <input
                  type="text"
                  value={focusPrompt}
                  onChange={(e) => setFocusPrompt(e.target.value)}
                  placeholder="e.g. funniest moments, bold predictions, actionable advice, emotional stories"
                  className="w-full rounded-lg border border-white/[0.09] bg-[#141722] px-3 py-2 text-xs text-white placeholder-zinc-500 focus:border-[#FF5A36]/60 focus:outline-none"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                <label className="inline-flex cursor-pointer items-center gap-2 text-xs text-zinc-300">
                  <input
                    type="checkbox"
                    checked={burnCaptions}
                    onChange={(e) => setBurnCaptions(e.target.checked)}
                    className="h-3.5 w-3.5 rounded border-white/20 bg-[#141722] accent-[#FF5A36]"
                  />
                  <Subtitles className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Burn-in viral captions (when transcript exists)</span>
                </label>

                <label className="inline-flex cursor-pointer items-center gap-2 text-xs text-zinc-300">
                  <input
                    type="checkbox"
                    checked={smartSnap}
                    onChange={(e) => setSmartSnap(e.target.checked)}
                    className="h-3.5 w-3.5 rounded border-white/20 bg-[#141722] accent-[#FF5A36]"
                  />
                  <span>Snap cuts to clean sentence endings</span>
                </label>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.06] pt-3">
                <span className="text-xs text-zinc-400">Workflow mode:</span>
                <div className="inline-flex rounded-lg border border-white/[0.08] bg-[#141722] p-0.5 text-xs">
                  <button
                    type="button"
                    onClick={() => setWorkflowMode('auto')}
                    className={`rounded-md px-2.5 py-1 font-medium transition ${
                      workflowMode === 'auto'
                        ? 'bg-[#FF5A36] text-white'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Auto-Extract All Clips
                  </button>
                  <button
                    type="button"
                    onClick={() => setWorkflowMode('review')}
                    className={`rounded-md px-2.5 py-1 font-medium transition ${
                      workflowMode === 'review'
                        ? 'bg-[#FF5A36] text-white'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Review AI Moments First
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Validation Error */}
        {formError && (
          <div className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-3.5 py-2.5 text-xs text-red-200">
            {formError}
          </div>
        )}

        {/* Primary Action CTA */}
        <div className="mt-6">
          <button
            type="submit"
            disabled={submitting || uploading}
            className="flex w-full items-center justify-center gap-2.5 rounded-xl bg-gradient-to-r from-[#FF5A36] to-[#FF7B3A] px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-[#FF5A36]/25 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-60 sm:text-[15px]"
          >
            {submitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Starting AI Clip Pipeline…</span>
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                <span>
                  {workflowMode === 'review'
                    ? `Find ${clipCount} Viral ${clipCount === 1 ? 'Moment' : 'Moments'} (≤ ${clipDuration}s)`
                    : `Generate ${clipCount} Viral ${clipCount === 1 ? 'Clip' : 'Clips'} in ${resShortLabel} (≤ ${clipDuration}s)`}
                </span>
              </>
            )}
          </button>
        </div>
      </form>
    </section>
  );
}
