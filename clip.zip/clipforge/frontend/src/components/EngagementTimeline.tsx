import { useState } from 'react';
import { FileText, Flame, Plus } from 'lucide-react';
import type { ClipItem } from '../types';
import { formatTimecode } from '../utils/format';

interface EngagementTimelineProps {
  duration: number;
  curve: number[];
  clips: ClipItem[];
  hasHeatmap: boolean;
  hasTranscript: boolean;
  activeClipId?: string | null;
  onSelectClip: (clip: ClipItem) => void;
  onAddCustomClip: () => void;
  onOpenTranscript: () => void;
}

export function EngagementTimeline({
  duration,
  curve,
  clips,
  hasHeatmap,
  hasTranscript,
  activeClipId,
  onSelectClip,
  onAddCustomClip,
  onOpenTranscript,
}: EngagementTimelineProps) {
  const [hoveredClip, setHoveredClip] = useState<ClipItem | null>(null);

  if (!duration || curve.length === 0) return null;

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-[#11131A] p-4 sm:p-5">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Flame className="h-4 w-4 text-[#FF5A36]" />
          <h3 className="text-xs font-semibold tracking-wide text-zinc-200 uppercase">
            {hasHeatmap ? 'Audience Replay & AI Virality Timeline' : 'AI Virality & Engagement Timeline'}
          </h3>
        </div>

        <div className="flex items-center gap-2">
          {hasTranscript && (
            <button
              type="button"
              onClick={onOpenTranscript}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.08] bg-[#171A24] px-2.5 py-1 text-xs font-medium text-zinc-300 transition hover:border-white/20 hover:text-white"
            >
              <FileText className="h-3.5 w-3.5 text-zinc-400" />
              Transcript
            </button>
          )}
          <button
            type="button"
            onClick={onAddCustomClip}
            className="inline-flex items-center gap-1 rounded-lg border border-white/[0.08] bg-[#171A24] px-2.5 py-1 text-xs font-medium text-zinc-300 transition hover:border-[#FF5A36]/50 hover:text-white"
          >
            <Plus className="h-3.5 w-3.5 text-[#FF5A36]" />
            Custom Clip
          </button>
        </div>
      </div>

      {/* Interactive Curve + Clip Highlight Windows */}
      <div className="relative h-20 w-full overflow-hidden rounded-xl border border-white/[0.06] bg-[#0A0C12] px-1 pt-3 pb-1">
        {/* Heatmap bars */}
        <div className="flex h-full w-full items-end gap-[2px]">
          {curve.map((val, idx) => {
            const binTime = ((idx + 0.5) / curve.length) * duration;
            const insideClip = clips.some(
              (c) => binTime >= c.start_time && binTime <= c.end_time && c.status !== 'skipped'
            );
            const heightPct = Math.max(10, Math.round(val * 100));
            return (
              <div
                key={idx}
                style={{ height: `${heightPct}%` }}
                className={`flex-1 rounded-t-[2px] transition-colors ${
                  insideClip
                    ? 'bg-gradient-to-t from-[#FF5A36] to-[#FFA067]'
                    : val > 0.72
                    ? 'bg-white/28'
                    : 'bg-white/[0.11]'
                }`}
              />
            );
          })}
        </div>

        {/* Highlighted Clip Region Overlays */}
        {clips.map((clip) => {
          const leftPct = Math.max(0, Math.min(99, (clip.start_time / duration) * 100));
          const rawWidth = ((clip.end_time - clip.start_time) / duration) * 100;
          const widthPct = Math.max(1.8, Math.min(100 - leftPct, rawWidth));
          const isActive = activeClipId === clip.id || hoveredClip?.id === clip.id;
          return (
            <button
              key={clip.id}
              type="button"
              onClick={() => onSelectClip(clip)}
              onMouseEnter={() => setHoveredClip(clip)}
              onMouseLeave={() => setHoveredClip(null)}
              style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
              className={`absolute inset-y-0 flex items-start justify-center border-x transition ${
                clip.status === 'skipped'
                  ? 'border-zinc-600/40 bg-zinc-500/10 opacity-50'
                  : isActive
                  ? 'z-10 border-[#FF8566] bg-[#FF5A36]/28 ring-1 ring-[#FF5A36]/60'
                  : 'border-[#FF5A36]/60 bg-[#FF5A36]/14 hover:bg-[#FF5A36]/25'
              }`}
              title={`#${clip.index} ${clip.title} (${formatTimecode(clip.start_time)} – ${formatTimecode(clip.end_time)})`}
            >
              <span className="mt-1 rounded bg-[#FF5A36] px-1 py-0.2 font-mono text-[9px] font-bold leading-tight text-white shadow">
                #{clip.index}
              </span>
            </button>
          );
        })}
      </div>

      {/* Axis labels + live hover detail */}
      <div className="mt-2 flex items-center justify-between font-mono text-[11px] text-zinc-500">
        <span>00:00</span>
        {hoveredClip ? (
          <span className="truncate px-2 font-sans text-xs text-zinc-200">
            <strong className="text-[#FF8566]">#{hoveredClip.index}</strong>{' '}
            {hoveredClip.title}{' '}
            <span className="font-mono text-[11px] text-zinc-400">
              ({formatTimecode(hoveredClip.start_time)}–{formatTimecode(hoveredClip.end_time)} · Score{' '}
              {hoveredClip.virality_score})
            </span>
          </span>
        ) : (
          <span>{formatTimecode(duration / 2)}</span>
        )}
        <span>{formatTimecode(duration)}</span>
      </div>
    </div>
  );
}
