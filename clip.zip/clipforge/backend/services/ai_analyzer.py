from __future__ import annotations

import json
import math
import re
import uuid
from typing import Any, Optional

import httpx

from models import ClipItem, SubScores, TranscriptSegment, VideoMetadata
from services.config_store import load_settings

# High-signal lexical patterns for short-form viral hooks, storytelling, and emotional peaks
HOOK_OPENERS = [
    r"\bhere'?s (?:the|why|how|what)\b",
    r"\bthe (?:truth|secret|problem|reason|crazy thing|weird thing|funny thing)\b",
    r"\bnobody (?:talks|tells|knows)\b",
    r"\bwhat if\b",
    r"\bimagine\b",
    r"\blet me (?:tell|show|explain)\b",
    r"\bwhy (?:do|does|did|are|is|would)\b",
    r"\bhow (?:do|does|did|can|to)\b",
    r"\bnumber one\b",
    r"\bbiggest (?:mistake|lesson|secret|lie|myth)\b",
    r"\bstop\b",
    r"\bnever\b",
    r"\bwait\b",
    r"\blisten\b",
    r"\bturns out\b",
    r"\bactually\b",
]

EMOTION_WORDS = {
    "insane", "crazy", "unbelievable", "shocking", "hilarious", "terrifying", "panic",
    "secret", "truth", "mistake", "million", "billion", "genius", "disaster", "magic",
    "mind", "brain", "love", "hate", "fear", "obsessed", "realized", "suddenly",
    "moment", "changed", "forever", "impossible", "incredible", "brilliant", "worst",
    "best", "amazing", "weird", "bizarre", "funny", "scary", "monster", "monkey",
    "dark", "crisis", "breakthrough", "power", "danger", "deadly", "epic", "legendary",
    "instant", "gratification", "procrastinator", "deadline", "life", "death", "dream",
    "regret", "freedom", "money", "future", "ai", "human", "world", "history",
}

REACTION_MARKERS = re.compile(
    r"[\(\[](laughter|laughs|applause|cheering|cheers|gasps|music|crowd)[\)\]]",
    re.IGNORECASE,
)

FLUFF_PATTERNS = re.compile(
    r"\b(smash that like|hit subscribe|sponsored by|today'?s sponsor|link in the description|"
    r"bell icon|patreon|merch|use code|thanks for watching|see you in the next|"
    r"welcome back to (?:my|the) channel|without further ado)\b",
    re.IGNORECASE,
)

STOPWORDS = {
    "the", "and", "for", "that", "this", "with", "you", "your", "are", "was", "were",
    "have", "has", "had", "not", "but", "what", "all", "can", "her", "his", "they",
    "from", "she", "which", "their", "will", "would", "there", "about", "out", "who",
    "get", "just", "like", "know", "into", "year", "good", "some", "could", "them",
    "see", "other", "than", "then", "now", "look", "only", "come", "its", "over",
    "think", "also", "back", "after", "use", "two", "how", "our", "work", "first",
    "well", "way", "even", "new", "want", "because", "any", "these", "give", "day",
    "most", "very", "when", "where", "why", "been", "being", "going", "really",
    "thing", "things", "said", "says", "one", "more", "much", "make", "made", "here",
    "laughter", "applause", "music", "gonna", "wanna", "kind", "sort", "actually",
}


def _fmt_mmss(sec: float) -> str:
    sec = max(0, int(round(sec)))
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def build_engagement_curve(
    duration: float,
    transcript: list[TranscriptSegment],
    heatmap: list[dict[str, float]],
    chapters: list[dict[str, Any]],
    focus_prompt: str = "",
    bins: int = 100,
) -> list[float]:
    """Compute a normalized 100-bin engagement curve across the entire video timeline."""
    if duration <= 0:
        return [0.3] * bins
    bin_w = duration / bins
    scores = [0.12] * bins

    focus_terms = {
        w.lower()
        for w in re.findall(r"[a-zA-Z0-9]{3,}", focus_prompt or "")
        if w.lower() not in STOPWORDS
    }

    # 1. Heatmap signal (YouTube Most-Replayed OR sampled audio energy)
    if heatmap:
        max_h = max((h.get("value", 0.0) for h in heatmap), default=1.0) or 1.0
        for h in heatmap:
            hs, he = h["start_time"], h["end_time"]
            val = max(0.0, min(1.0, h["value"] / max_h))
            b0 = max(0, min(bins - 1, int(hs / bin_w)))
            b1 = max(b0, min(bins - 1, int(he / bin_w)))
            for b in range(b0, b1 + 1):
                scores[b] += val * 0.65

    # 2. Transcript linguistic & reaction intensity
    if transcript:
        for seg in transcript:
            mid = (seg.start + seg.end) * 0.5
            b = max(0, min(bins - 1, int(mid / bin_w)))
            txt = seg.text
            low = txt.lower()
            boost = 0.08
            if REACTION_MARKERS.search(txt):
                boost += 0.55
            if "?" in txt:
                boost += 0.16
            if "!" in txt:
                boost += 0.12
            if re.search(r"\b\d+(?:%|x|k|m|\s+years|\s+months|\s+days|\s+seconds|\s+million)?\b", low):
                boost += 0.1
            words = re.findall(r"[a-z']+", low)
            emo_hits = sum(1 for w in words if w in EMOTION_WORDS)
            boost += min(0.35, emo_hits * 0.09)
            if any(re.search(pat, low) for pat in HOOK_OPENERS):
                boost += 0.18
            if focus_terms:
                f_hits = sum(1 for w in words if w in focus_terms)
                boost += min(0.5, f_hits * 0.2)
            if FLUFF_PATTERNS.search(low):
                boost -= 0.35
            scores[b] = max(0.05, scores[b] + boost)
    elif not heatmap:
        # Smooth narrative arc curve when neither transcript nor heatmap is present
        for b in range(bins):
            pos = b / max(1, bins - 1)
            arc = (
                0.35
                + 0.28 * math.exp(-((pos - 0.22) ** 2) / 0.012)
                + 0.36 * math.exp(-((pos - 0.52) ** 2) / 0.016)
                + 0.42 * math.exp(-((pos - 0.78) ** 2) / 0.014)
            )
            scores[b] = arc

    # 3. Chapter transition hooks
    for ch in chapters:
        cs = float(ch.get("start_time", 0))
        if cs > 5:
            b = max(0, min(bins - 1, int(cs / bin_w)))
            scores[b] += 0.18

    # Smooth with a 3-tap Gaussian kernel so the timeline looks organic and highlights sustained moments
    smoothed: list[float] = []
    for i in range(bins):
        left = scores[max(0, i - 1)]
        cur = scores[i]
        right = scores[min(bins - 1, i + 1)]
        smoothed.append(0.22 * left + 0.56 * cur + 0.22 * right)

    lo, hi = min(smoothed), max(smoothed)
    span = (hi - lo) if hi > lo else 1.0
    return [round(max(0.08, min(1.0, (v - lo) / span * 0.92 + 0.08)), 3) for v in smoothed]


def transcript_slice(segments: list[TranscriptSegment], start: float, end: float) -> str:
    parts = [
        s.text.strip()
        for s in segments
        if s.end > start + 0.2 and s.start < end - 0.2 and s.text.strip()
    ]
    joined = " ".join(parts)
    return re.sub(r"\s+", " ", joined).strip()


def snap_window_to_sentences(
    segments: list[TranscriptSegment],
    raw_start: float,
    target_duration: float,
    video_duration: float,
) -> tuple[float, float]:
    """
    Snap start and end times to clean subtitle/sentence boundaries while strictly
    keeping duration <= min(60.0, target_duration) (and close to target_duration).
    """
    max_dur = min(60.0, float(target_duration))
    min_dur = max(4.0, max_dur * 0.72)

    if not segments:
        s = max(0.0, min(raw_start, max(0.0, video_duration - max_dur)))
        e = min(video_duration, s + max_dur)
        return round(s, 2), round(e, 2)

    # Snap start to nearest clean sentence start within ±3.5s
    best_start = raw_start
    best_start_score = -999.0
    for idx, seg in enumerate(segments):
        dist = abs(seg.start - raw_start)
        if dist > 4.0:
            continue
        txt = seg.text.strip()
        if REACTION_MARKERS.fullmatch(txt):
            continue
        sc = -dist * 0.6
        if idx == 0 or segments[idx - 1].text.rstrip().endswith((".", "!", "?", "]", ")")):
            sc += 2.2
        if idx > 0 and (seg.start - segments[idx - 1].end) >= 0.35:
            sc += 1.2
        if txt and txt[0].isupper():
            sc += 0.8
        if sc > best_start_score:
            best_start_score = sc
            best_start = seg.start

    best_start = max(0.0, min(best_start, max(0.0, video_duration - min(min_dur, video_duration))))
    hard_end = min(video_duration, best_start + max_dur)
    min_end = min(hard_end, best_start + min_dur)

    # Snap end to a clean terminal punctuation or audience reaction inside [min_end, hard_end]
    best_end = hard_end
    best_end_score = -999.0
    for seg in segments:
        if seg.end < min_end - 0.5 or seg.end > hard_end + 0.15:
            continue
        cand_end = min(hard_end, seg.end)
        closeness = 1.0 - abs(hard_end - cand_end) / max(1.0, hard_end - min_end + 0.5)
        txt = seg.text.rstrip()
        sc = closeness * 1.5
        if REACTION_MARKERS.search(txt):
            sc += 2.6
        elif txt.endswith(("!", "?")):
            sc += 2.2
        elif txt.endswith("."):
            sc += 1.9
        if sc > best_end_score:
            best_end_score = sc
            best_end = cand_end

    # Strictly enforce <= max_dur and <= 60.0s
    if best_end - best_start > max_dur:
        best_end = best_start + max_dur
    if best_end - best_start < 3.0:
        best_end = min(video_duration, best_start + max_dur)

    return round(best_start, 2), round(best_end, 2)


def _craft_clip_title(
    clip_text: str,
    video_title: str,
    chapters: list[dict[str, Any]],
    start: float,
    rank: int,
) -> str:
    # Check chapter title first if clip aligns closely
    for ch in chapters:
        if ch["start_time"] - 5 <= start <= ch["end_time"] and ch.get("title"):
            ct = ch["title"].strip()
            if 4 <= len(ct) <= 64:
                return ct

    cleaned = REACTION_MARKERS.sub("", clip_text).strip()
    if cleaned:
        # Look for a punchy question or opening hook sentence
        sentences = re.split(r"(?<=[.!?])\s+", cleaned)
        for sent in sentences[:3]:
            s = sent.strip(" \"'—-,:")
            words = s.split()
            if "?" in s and 4 <= len(words) <= 11:
                return s[0].upper() + s[1:]
        # Extract memorable concept phrase or crisp opening hook
        first = sentences[0].strip(" \"'—-,:") if sentences else cleaned
        first = re.sub(r"^(so|and|but|now|well|okay|um|uh|i mean)\s+", "", first, flags=re.I)
        words = first.split()
        if len(words) >= 4:
            if len(words) <= 10:
                snippet = first.rstrip(",;:-")
            else:
                snippet = " ".join(words[:9]).rstrip(",;:-")
                # Avoid dangling articles/prepositions before ellipsis
                snippet = re.sub(
                    r"\s+(a|an|the|to|of|in|on|for|with|and|or|but|if|that|is|was|not)$",
                    "",
                    snippet,
                    flags=re.I,
                )
                if not snippet.endswith((".", "!", "?")):
                    snippet += "…"
            return snippet[0].upper() + snippet[1:]

    short_base = video_title.split("—")[0].split("|")[0].split("-")[0].strip()[:40]
    labels = [
        "Peak Action Highlight",
        "High-Energy Climax Moment",
        "Breakout Cinematic Sequence",
        "Standout Viral Scene",
        "Key Turning Point",
        "Fan-Favorite Highlight",
    ]
    return f"{short_base}: {labels[(rank - 1) % len(labels)]}"


def _extract_hook_quote(clip_text: str) -> str:
    cleaned = REACTION_MARKERS.sub("", clip_text).strip()
    if not cleaned:
        return ""
    sentences = re.split(r"(?<=[.!?])\s+", cleaned)
    hook = sentences[0].strip()
    if len(hook) < 28 and len(sentences) > 1:
        hook = f"{hook} {sentences[1].strip()}"
    if len(hook) > 135:
        hook = hook[:132].rsplit(" ", 1)[0] + "…"
    return f"“{hook}”"


def _generate_hashtags(clip_text: str, video_title: str) -> list[str]:
    corpus = f"{video_title} {clip_text}".lower()
    words = re.findall(r"[a-z]{4,}", corpus)
    freq: dict[str, int] = {}
    for w in words:
        if w in STOPWORDS:
            continue
        freq[w] = freq.get(w, 0) + (2 if w in EMOTION_WORDS else 1)
    top = sorted(freq.items(), key=lambda kv: kv[1], reverse=True)[:3]
    tags = [f"#{w}" for w, _ in top]
    for base in ("#shorts", "#viral"):
        if base not in tags:
            tags.append(base)
    return tags[:5]


def _builtin_analyze(
    meta: VideoMetadata,
    transcript: list[TranscriptSegment],
    heatmap: list[dict[str, float]],
    engagement_curve: list[float],
    clip_count: int,
    clip_duration: int,
    smart_snap: bool,
    focus_prompt: str,
) -> list[ClipItem]:
    """Multi-signal heuristic + NLP + audience-heatmap + acoustic-energy viral moment selector."""
    vid_dur = meta.duration
    eff_dur = min(60.0, float(clip_duration), vid_dur)
    # If user requests many clips from a shorter video, adapt duration so all clips stay distinct
    if clip_count * eff_dur > vid_dur * 0.92 and clip_count > 1:
        eff_dur = max(5.0, min(eff_dur, math.floor((vid_dur * 0.9) / clip_count)))

    focus_terms = {
        w.lower()
        for w in re.findall(r"[a-zA-Z0-9]{3,}", focus_prompt or "")
        if w.lower() not in STOPWORDS
    }

    # Skip dead intro (first 2%) and end-screen credits (last 5%) on long videos
    start_floor = min(12.0, vid_dur * 0.025) if vid_dur > 90 else 0.0
    end_ceil = max(eff_dur, vid_dur * 0.95) if vid_dur > 120 else vid_dur
    max_start = max(0.0, end_ceil - eff_dur)
    if start_floor >= max_start:
        start_floor = 0.0
        max_start = max(0.0, vid_dur - eff_dur)

    step = max(2.5, min(10.0, (max_start - start_floor) / 140.0)) if max_start > start_floor else 1.0
    bins = len(engagement_curve)

    candidates: list[dict[str, Any]] = []
    t = start_floor
    while t <= max_start + 0.01:
        if smart_snap and transcript:
            s, e = snap_window_to_sentences(transcript, t, eff_dur, vid_dur)
        else:
            s = round(t, 2)
            e = round(min(vid_dur, s + eff_dur), 2)
        dur = max(1.0, e - s)

        # Average curve intensity across window
        b0 = max(0, min(bins - 1, int((s / vid_dur) * bins)))
        b1 = max(b0, min(bins - 1, int((e / vid_dur) * bins)))
        curve_slice = engagement_curve[b0 : b1 + 1]
        curve_avg = sum(curve_slice) / len(curve_slice)
        curve_peak = max(curve_slice)

        txt = transcript_slice(transcript, s, e) if transcript else ""
        low = txt.lower()
        signals: list[str] = []

        # Sub-score calculations
        hook_raw = 0.55
        retention_raw = curve_avg * 0.65 + curve_peak * 0.35
        emotion_raw = curve_peak * 0.6
        pacing_raw = 0.68

        if meta.has_heatmap and curve_peak >= 0.72:
            signals.append("Most-Replayed Peak")
            retention_raw = min(1.0, retention_raw + 0.2)
        elif not transcript and heatmap and curve_peak >= 0.68:
            signals.append("High Audio Energy")

        if txt:
            # Opening 6 seconds hook analysis
            opener = transcript_slice(transcript, s, min(e, s + 7.0)).lower()
            if "?" in opener:
                hook_raw += 0.22
                signals.append("Curiosity Question")
            if any(re.search(p, opener) for p in HOOK_OPENERS):
                hook_raw += 0.24
                if "Strong Verbal Hook" not in signals:
                    signals.append("Strong Verbal Hook")
            if re.search(r"\b\d+", opener):
                hook_raw += 0.1

            # Audience reactions (laughter / applause)
            reactions = REACTION_MARKERS.findall(txt)
            if reactions:
                emotion_raw += min(0.45, len(reactions) * 0.2)
                r_types = {r.lower() for r in reactions}
                if "laughter" in r_types or "laughs" in r_types:
                    signals.append("Audience Laughter")
                elif "applause" in r_types or "cheering" in r_types:
                    signals.append("Audience Applause")

            words = re.findall(r"[a-z']+", low)
            wpm = (len(words) / dur) * 60.0
            if 135 <= wpm <= 195:
                pacing_raw = 0.92
                if len(signals) < 3:
                    signals.append(f"{int(round(wpm))} WPM Flow")
            elif 105 <= wpm < 135 or 195 < wpm <= 225:
                pacing_raw = 0.78
            elif wpm < 60:
                pacing_raw = 0.42
            else:
                pacing_raw = 0.65

            emo_hits = sum(1 for w in words if w in EMOTION_WORDS)
            emotion_raw = min(1.0, emotion_raw * 0.45 + min(0.55, emo_hits * 0.085) + 0.15)
            if emo_hits >= 4 and "High Emotional Punch" not in signals and len(signals) < 3:
                signals.append("Emotional Storytelling")

            if focus_terms:
                f_hits = sum(1 for w in words if w in focus_terms)
                if f_hits > 0:
                    hook_raw += min(0.3, f_hits * 0.12)
                    retention_raw += min(0.3, f_hits * 0.12)
                    signals.insert(0, "Matches Focus Topic")

            if FLUFF_PATTERNS.search(low):
                hook_raw -= 0.35
                retention_raw -= 0.35
        else:
            hook_raw = 0.5 + curve_peak * 0.42
            pacing_raw = 0.62 + curve_avg * 0.32
            if not signals:
                signals.append("Dynamic Peak Scene")

        # Check chapter opener bonus
        for ch in meta.chapters:
            if abs(ch["start_time"] - s) <= 6.0:
                hook_raw += 0.12
                if "Chapter Highlight" not in signals and len(signals) < 3:
                    signals.append("Chapter Highlight")
                break

        hook_s = int(round(max(58, min(99, 55 + hook_raw * 42))))
        ret_s = int(round(max(58, min(99, 54 + retention_raw * 44))))
        emo_s = int(round(max(55, min(99, 52 + emotion_raw * 45))))
        pac_s = int(round(max(58, min(99, 52 + pacing_raw * 44))))

        composite = hook_s * 0.30 + ret_s * 0.32 + emo_s * 0.22 + pac_s * 0.16
        candidates.append(
            {
                "start": s,
                "end": e,
                "duration": round(dur, 2),
                "composite": composite,
                "sub_scores": SubScores(hook=hook_s, retention=ret_s, emotion=emo_s, pacing=pac_s),
                "text": txt,
                "signals": signals[:3],
            }
        )
        if max_start <= start_floor:
            break
        t += step

    # Non-Maximum Suppression so extracted clips never overlap
    candidates.sort(key=lambda c: c["composite"], reverse=True)
    chosen: list[dict[str, Any]] = []
    min_gap = max(2.0, min(12.0, (vid_dur - clip_count * eff_dur) / max(1, clip_count * 2)))

    for cand in candidates:
        if len(chosen) >= clip_count:
            break
        overlaps = any(
            not (cand["end"] + min_gap <= prev["start"] or cand["start"] >= prev["end"] + min_gap)
            for prev in chosen
        )
        if not overlaps:
            chosen.append(cand)

    # Relax gap to strict non-overlap if video was tight
    if len(chosen) < clip_count:
        for cand in candidates:
            if len(chosen) >= clip_count:
                break
            if cand in chosen:
                continue
            overlaps = any(
                not (cand["end"] <= prev["start"] + 0.5 or cand["start"] >= prev["end"] - 0.5)
                for prev in chosen
            )
            if not overlaps:
                chosen.append(cand)

    # Fallback evenly spaced segments if still fewer than requested on ultra-short videos
    if len(chosen) < clip_count and vid_dur >= 6.0:
        slot = vid_dur / clip_count
        for idx in range(clip_count):
            if len(chosen) >= clip_count:
                break
            cs = round(idx * slot, 2)
            ce = round(min(vid_dur, cs + min(eff_dur, slot)), 2)
            if ce - cs < 3.0:
                continue
            if any(abs(cs - p["start"]) < 2.0 for p in chosen):
                continue
            txt = transcript_slice(transcript, cs, ce) if transcript else ""
            chosen.append(
                {
                    "start": cs,
                    "end": ce,
                    "duration": round(ce - cs, 2),
                    "composite": 76.0,
                    "sub_scores": SubScores(hook=78, retention=76, emotion=74, pacing=77),
                    "text": txt,
                    "signals": ["Timeline Highlight"],
                }
            )

    chosen.sort(key=lambda c: c["composite"], reverse=True)

    clips: list[ClipItem] = []
    for rank, c in enumerate(chosen[:clip_count], start=1):
        score = int(round(max(65, min(99, c["composite"]))))
        sigs = c["signals"] or ["High Engagement"]
        reason = _compose_reason(sigs, c["text"], meta, c["start"], c["end"])
        clips.append(
            ClipItem(
                id=f"clip-{uuid.uuid4().hex[:8]}",
                index=rank,
                title=_craft_clip_title(c["text"], meta.title, meta.chapters, c["start"], rank),
                start_time=c["start"],
                end_time=c["end"],
                duration=round(min(60.0, c["end"] - c["start"]), 2),
                virality_score=score,
                sub_scores=c["sub_scores"],
                reason=reason,
                hook_quote=_extract_hook_quote(c["text"]),
                transcript=c["text"],
                hashtags=_generate_hashtags(c["text"], meta.title),
                signals=sigs,
            )
        )
    return clips


def _compose_reason(
    signals: list[str], text: str, meta: VideoMetadata, start: float, end: float
) -> str:
    parts: list[str] = []
    if "Matches Focus Topic" in signals:
        parts.append("Directly hits your requested focus topic")
    if "Most-Replayed Peak" in signals:
        parts.append("aligns with a spike on YouTube's Most-Replayed audience heatmap")
    if "Audience Laughter" in signals:
        parts.append("triggers live audience laughter with a strong comedic payoff")
    elif "Audience Applause" in signals:
        parts.append("lands on an audience applause moment with strong shareability")
    if "Curiosity Question" in signals:
        parts.append("opens with a curiosity-gap question in the first 5 seconds")
    elif "Strong Verbal Hook" in signals:
        parts.append("leads with an immediate attention-grabbing hook")
    if "Emotional Storytelling" in signals and len(parts) < 2:
        parts.append("packs vivid emotional storytelling and high retention density")
    if "High Audio Energy" in signals:
        parts.append("peaks in acoustic intensity and dynamic action pacing")

    if not parts:
        if text:
            parts.append("Self-contained high-retention segment with clean sentence boundaries")
        else:
            parts.append(
                f"High-energy visual & audio peak at {_fmt_mmss(start)}–{_fmt_mmss(end)} sized for maximum short-form impact"
            )

    sentence = ", and ".join(parts[:2]) if len(parts) >= 2 else parts[0]
    sentence = sentence[0].upper() + sentence[1:]
    if not sentence.endswith("."):
        sentence += "."
    return sentence


def _build_llm_prompt(
    meta: VideoMetadata,
    transcript: list[TranscriptSegment],
    heatmap: list[dict[str, float]],
    clip_count: int,
    clip_duration: int,
    focus_prompt: str,
) -> str:
    # Compact timestamped transcript (cap ~55k chars to stay crisp and fast for every model)
    lines: list[str] = []
    bucket_start = None
    bucket_text: list[str] = []
    for seg in transcript:
        if bucket_start is None:
            bucket_start = seg.start
        bucket_text.append(seg.text)
        if seg.end - bucket_start >= 5.0:
            lines.append(f"[{bucket_start:.1f}s-{seg.end:.1f}s] {' '.join(bucket_text)}")
            bucket_start = None
            bucket_text = []
    if bucket_start is not None and bucket_text:
        lines.append(f"[{bucket_start:.1f}s-{transcript[-1].end:.1f}s] {' '.join(bucket_text)}")

    transcript_block = "\n".join(lines)
    if len(transcript_block) > 52000:
        # Sample evenly across very long multi-hour videos
        stride = max(1, math.ceil(len(lines) / 700))
        transcript_block = "\n".join(lines[::stride])[:52000]

    top_peaks = ""
    if heatmap:
        ranked = sorted(heatmap, key=lambda h: h["value"], reverse=True)[:8]
        top_peaks = "Top audience replay/energy spikes: " + ", ".join(
            f"{h['start_time']:.0f}s-{h['end_time']:.0f}s (intensity {h['value']:.2f})"
            for h in ranked
        )

    chapters_str = ""
    if meta.chapters:
        chapters_str = "Chapters: " + "; ".join(
            f"{c['start_time']:.0f}s {c['title']}" for c in meta.chapters[:20]
        )

    focus_line = f"User's custom focus instruction: {focus_prompt}\n" if focus_prompt else ""

    return f"""You are an elite viral short-form video editor (YouTube Shorts, TikTok, Instagram Reels).
Analyze this long-form video and pick EXACTLY {clip_count} non-overlapping, standalone viral moments.

Video Title: {meta.title}
Creator: {meta.channel}
Total Duration: {meta.duration:.1f} seconds
Target Clip Duration: {clip_duration} seconds (HARD CAP: every clip MUST be <= {min(60, clip_duration)} seconds and at least {max(5, int(clip_duration * 0.72))} seconds).
{focus_line}{top_peaks}
{chapters_str}

Rules:
1. Pick moments with an irresistible 3-second opening hook, emotional payoff/humor/insight, and clean sentence start & end.
2. Avoid sponsor reads, generic intros, and subscribe/outro fluff.
3. Clips MUST NOT overlap and all timestamps must be within [0, {meta.duration:.1f}].
4. Sort clips from highest virality_score (0-100) to lowest.
5. Return ONLY valid JSON with this exact structure:
{{
  "clips": [
    {{
      "title": "Catchy 4-9 word viral title",
      "start_time": 124.5,
      "end_time": {124.5 + min(60, clip_duration):.1f},
      "virality_score": 94,
      "sub_scores": {{"hook": 96, "retention": 93, "emotion": 91, "pacing": 95}},
      "reason": "One concise sentence explaining why this clip will go viral.",
      "signals": ["Strong Hook", "High Payoff"],
      "hashtags": ["#shorts", "#viral", "#topic"]
    }}
  ]
}}

Timestamped Transcript:
{transcript_block if transcript_block else "(No spoken transcript available — select peak structural moments based on video metadata, chapters, and energy spikes above.)"}
"""


async def _call_llm(prompt: str, settings: dict[str, Any]) -> tuple[Optional[dict[str, Any]], str]:
    provider = settings.get("ai_provider", "auto")
    if provider == "builtin":
        return None, ""

    order: list[str] = []
    if provider == "auto":
        if settings.get("openai_api_key"):
            order.append("openai")
        if settings.get("gemini_api_key"):
            order.append("gemini")
        if settings.get("anthropic_api_key"):
            order.append("anthropic")
    else:
        order.append(provider)

    async with httpx.AsyncClient(timeout=60) as client:
        for p in order:
            try:
                if p == "openai" and settings.get("openai_api_key"):
                    model = settings.get("openai_model") or "gpt-4o-mini"
                    r = await client.post(
                        "https://api.openai.com/v1/chat/completions",
                        headers={"Authorization": f"Bearer {settings['openai_api_key']}"},
                        json={
                            "model": model,
                            "temperature": 0.3,
                            "response_format": {"type": "json_object"},
                            "messages": [{"role": "user", "content": prompt}],
                        },
                    )
                    r.raise_for_status()
                    content = r.json()["choices"][0]["message"]["content"]
                    return json.loads(content), f"OpenAI ({model})"

                if p == "gemini" and settings.get("gemini_api_key"):
                    model = settings.get("gemini_model") or "gemini-2.5-flash"
                    r = await client.post(
                        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                        params={"key": settings["gemini_api_key"]},
                        json={
                            "contents": [{"parts": [{"text": prompt}]}],
                            "generationConfig": {
                                "temperature": 0.3,
                                "responseMimeType": "application/json",
                            },
                        },
                    )
                    r.raise_for_status()
                    content = r.json()["candidates"][0]["content"]["parts"][0]["text"]
                    return json.loads(content), f"Google Gemini ({model})"

                if p == "anthropic" and settings.get("anthropic_api_key"):
                    model = settings.get("anthropic_model") or "claude-sonnet-4-20250514"
                    r = await client.post(
                        "https://api.anthropic.com/v1/messages",
                        headers={
                            "x-api-key": settings["anthropic_api_key"],
                            "anthropic-version": "2023-06-01",
                            "content-type": "application/json",
                        },
                        json={
                            "model": model,
                            "max_tokens": 2500,
                            "temperature": 0.3,
                            "messages": [{"role": "user", "content": prompt}],
                        },
                    )
                    r.raise_for_status()
                    content = r.json()["content"][0]["text"]
                    m = re.search(r"\{[\s\S]*\}", content)
                    if m:
                        return json.loads(m.group(0)), f"Anthropic ({model})"

                if p == "custom" and settings.get("custom_base_url") and settings.get("custom_model"):
                    base = settings["custom_base_url"].rstrip("/")
                    model = settings["custom_model"]
                    headers = {"Content-Type": "application/json"}
                    if settings.get("custom_api_key"):
                        headers["Authorization"] = f"Bearer {settings['custom_api_key']}"
                    r = await client.post(
                        f"{base}/chat/completions",
                        headers=headers,
                        json={
                            "model": model,
                            "temperature": 0.3,
                            "messages": [{"role": "user", "content": prompt}],
                        },
                    )
                    r.raise_for_status()
                    content = r.json()["choices"][0]["message"]["content"]
                    m = re.search(r"\{[\s\S]*\}", content)
                    if m:
                        return json.loads(m.group(0)), f"Custom LLM ({model})"
            except Exception:
                continue
    return None, ""


async def analyze_viral_moments(
    *,
    meta: VideoMetadata,
    transcript: list[TranscriptSegment],
    heatmap: list[dict[str, float]],
    clip_count: int,
    clip_duration: int,
    smart_snap: bool = True,
    focus_prompt: str = "",
) -> tuple[list[ClipItem], list[float], str]:
    """
    Identify the top `clip_count` viral moments (each <= `clip_duration` <= 60s),
    returning (clips, 100-bin engagement_curve, ai_engine_label).
    """
    clip_duration = max(5, min(60, int(clip_duration)))
    clip_count = max(1, min(12, int(clip_count)))

    curve = build_engagement_curve(
        meta.duration, transcript, heatmap, meta.chapters, focus_prompt, bins=100
    )

    settings = load_settings()
    prompt = _build_llm_prompt(meta, transcript, heatmap, clip_count, clip_duration, focus_prompt)
    llm_json, llm_label = await _call_llm(prompt, settings)

    if llm_json and isinstance(llm_json.get("clips"), list) and llm_json["clips"]:
        parsed: list[ClipItem] = []
        max_allowed = min(60.0, float(clip_duration), meta.duration)
        for idx, raw in enumerate(llm_json["clips"][:clip_count], start=1):
            try:
                s = max(0.0, min(float(raw.get("start_time", 0)), max(0.0, meta.duration - 4.0)))
                e = min(meta.duration, float(raw.get("end_time", s + max_allowed)))
                if e - s > max_allowed or e - s < 3.0:
                    e = min(meta.duration, s + max_allowed)
                if smart_snap and transcript:
                    s, e = snap_window_to_sentences(transcript, s, max_allowed, meta.duration)
                txt = transcript_slice(transcript, s, e) if transcript else ""
                ss = raw.get("sub_scores") or {}
                score = int(max(60, min(99, int(raw.get("virality_score", 88)))))
                parsed.append(
                    ClipItem(
                        id=f"clip-{uuid.uuid4().hex[:8]}",
                        index=idx,
                        title=str(raw.get("title") or f"Viral Clip #{idx}")[:110],
                        start_time=round(s, 2),
                        end_time=round(e, 2),
                        duration=round(min(60.0, e - s), 2),
                        virality_score=score,
                        sub_scores=SubScores(
                            hook=max(50, min(99, int(ss.get("hook", score)))),
                            retention=max(50, min(99, int(ss.get("retention", score)))),
                            emotion=max(50, min(99, int(ss.get("emotion", score - 2)))),
                            pacing=max(50, min(99, int(ss.get("pacing", score)))),
                        ),
                        reason=str(raw.get("reason") or "High-engagement viral moment identified by AI."),
                        hook_quote=_extract_hook_quote(txt),
                        transcript=txt,
                        hashtags=[str(h) for h in (raw.get("hashtags") or [])[:5]]
                        or _generate_hashtags(txt, meta.title),
                        signals=[str(sig) for sig in (raw.get("signals") or ["LLM Selected"])[:3]],
                    )
                )
            except Exception:
                continue
        if parsed:
            # Top up with built-in AI if LLM returned fewer clips than requested
            if len(parsed) < clip_count:
                extras = _builtin_analyze(
                    meta, transcript, heatmap, curve, clip_count + 3, clip_duration, smart_snap, focus_prompt
                )
                for ex in extras:
                    if len(parsed) >= clip_count:
                        break
                    if all(ex.end_time <= p.start_time or ex.start_time >= p.end_time for p in parsed):
                        ex.index = len(parsed) + 1
                        parsed.append(ex)
            return parsed, curve, llm_label

    # Built-in multi-signal viral analyzer
    clips = _builtin_analyze(
        meta, transcript, heatmap, curve, clip_count, clip_duration, smart_snap, focus_prompt
    )
    parts = []
    if meta.has_heatmap:
        parts.append("Heatmap")
    if meta.has_transcript:
        parts.append("Transcript NLP")
    if not meta.has_transcript and heatmap:
        parts.append("Acoustic Peak AI")
    mode_suffix = " + ".join(parts) if parts else "Structural AI"
    return clips, curve, f"ClipForge Viral AI ({mode_suffix})"
