from __future__ import annotations

import hmac
import os
import re
import uuid
from pathlib import Path
from typing import Iterator

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from models import (
    AddCustomClipRequest,
    CreateJobRequest,
    ExtractSelectedRequest,
    SettingsUpdateRequest,
    UpdateClipRequest,
)
from services.config_store import (
    COOKIES_PATH,
    UPLOADS_DIR,
    get_public_settings,
    update_settings,
)
from services.job_manager import job_manager
from services.ytdlp_service import get_engine_versions

app = FastAPI(
    title="ClipForge 4K — AI YouTube Viral Clip Studio",
    version="1.0.0",
    description="Convert long-form YouTube videos into viral 4K short clips up to 60 seconds using yt-dlp + AI.",
)

_raw_origins = os.getenv("ALLOWED_ORIGINS", "*").strip()
ALLOWED_ORIGINS = (
    ["*"]
    if not _raw_origins or _raw_origins == "*"
    else [o.strip().rstrip("/") for o in _raw_origins.split(",") if o.strip()]
)
API_SECRET = (os.getenv("API_SECRET") or os.getenv("VPS_API_SECRET") or "").strip()

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*", "X-ClipForge-Token", "Range", "Content-Type"],
    expose_headers=["Content-Range", "Accept-Ranges", "Content-Length", "Content-Disposition"],
)


@app.middleware("http")
async def verify_optional_api_token(request: Request, call_next):
    """When API_SECRET is configured on Render, protect /api routes against unauthorized use."""
    if (
        API_SECRET
        and request.method != "OPTIONS"
        and request.url.path.startswith("/api/")
        and request.url.path != "/api/health"
    ):
        supplied = (
            request.headers.get("x-clipforge-token")
            or request.query_params.get("token")
            or ""
        ).strip()
        if not supplied or not hmac.compare_digest(supplied, API_SECRET):
            req_origin = (request.headers.get("origin") or "").rstrip("/")
            cors_origin = (
                req_origin
                if req_origin in ALLOWED_ORIGINS
                else (ALLOWED_ORIGINS[0] if len(ALLOWED_ORIGINS) == 1 else "*")
            )
            return JSONResponse(
                status_code=401,
                content={
                    "detail": "Invalid or missing API Secret Token. Enter your API_SECRET in Settings → Render API."
                },
                headers={"Access-Control-Allow-Origin": cors_origin},
            )
    return await call_next(request)


ENGINE_VERSIONS = get_engine_versions()
FRONTEND_DIST = Path(__file__).resolve().parent / "static"


@app.get("/api/health")
async def health() -> dict:
    pub = get_public_settings()
    return {
        "status": "ok",
        "yt_dlp_version": ENGINE_VERSIONS["yt_dlp"],
        "ffmpeg_version": ENGINE_VERSIONS["ffmpeg"],
        "active_ai_label": pub["active_ai_label"],
        "has_cookies_file": pub["has_cookies_file"],
        "cookie_count": pub["cookie_count"],
        "auth_required": bool(API_SECRET),
        "max_clip_duration_seconds": 60,
        "max_export_resolution": "3840x2160 (4K UHD)",
    }


@app.get("/api/settings")
async def get_settings() -> dict:
    return get_public_settings()


@app.put("/api/settings")
async def put_settings(req: SettingsUpdateRequest) -> dict:
    patch = req.model_dump(exclude_none=True)
    return update_settings(patch)


@app.post("/api/settings/cookies-file")
async def upload_cookies_file(file: UploadFile = File(...)) -> dict:
    raw = await file.read()
    if len(raw) > 5 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Cookies file is too large (max 5 MB).")
    text = raw.decode("utf-8", errors="ignore").strip()
    if not text:
        raise HTTPException(status_code=400, detail="Uploaded cookies file is empty.")
    return update_settings({"cookies_txt": text})


@app.delete("/api/settings/cookies-file")
async def clear_cookies_file() -> dict:
    COOKIES_PATH.unlink(missing_ok=True)
    return get_public_settings()


@app.post("/api/upload-video")
async def upload_local_video(file: UploadFile = File(...)) -> dict:
    filename = file.filename or "video.mp4"
    ext = Path(filename).suffix.lower()
    if ext not in {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi"}:
        raise HTTPException(
            status_code=400,
            detail="Unsupported video format. Please upload MP4, MOV, MKV, or WebM.",
        )
    safe_stem = re.sub(r"[^a-zA-Z0-9_-]+", "_", Path(filename).stem)[:48]
    out_name = f"{uuid.uuid4().hex[:8]}_{safe_stem}{ext}"
    dest = UPLOADS_DIR / out_name

    total_written = 0
    max_bytes = 2 * 1024 * 1024 * 1024  # 2 GB
    with dest.open("wb") as out:
        while chunk := await file.read(1024 * 1024):
            total_written += len(chunk)
            if total_written > max_bytes:
                dest.unlink(missing_ok=True)
                raise HTTPException(status_code=413, detail="Video exceeds 2 GB limit.")
            out.write(chunk)

    return {
        "local_url": f"local://{out_name}",
        "filename": filename,
        "size_bytes": total_written,
    }


@app.get("/api/jobs")
async def list_jobs() -> dict:
    return {"jobs": [j.model_dump() for j in job_manager.list_jobs()]}


@app.post("/api/jobs")
async def create_job(req: CreateJobRequest) -> dict:
    job = job_manager.create_job(req)
    return job.model_dump()


@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str) -> dict:
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    return job.model_dump()


@app.get("/api/jobs/{job_id}/transcript")
async def get_job_transcript(job_id: str) -> dict:
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    segs = job_manager.load_transcript(job_id)
    return {"segments": [s.model_dump() for s in segs]}


@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str) -> dict:
    job = job_manager.cancel_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    return job.model_dump()


@app.delete("/api/jobs/{job_id}")
async def delete_job(job_id: str) -> dict:
    ok = job_manager.delete_job(job_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Job not found.")
    return {"deleted": True}


@app.post("/api/jobs/{job_id}/extract")
async def extract_selected_clips(job_id: str, req: ExtractSelectedRequest) -> dict:
    try:
        job = job_manager.trigger_extract_selected(job_id, req)
        return job.model_dump()
    except KeyError:
        raise HTTPException(status_code=404, detail="Job not found.")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/jobs/{job_id}/clips")
async def add_custom_clip(job_id: str, req: AddCustomClipRequest) -> dict:
    try:
        job = job_manager.add_custom_clip(job_id, req)
        return job.model_dump()
    except KeyError:
        raise HTTPException(status_code=404, detail="Job not found.")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.patch("/api/jobs/{job_id}/clips/{clip_id}")
async def update_clip(job_id: str, clip_id: str, req: UpdateClipRequest) -> dict:
    try:
        job = job_manager.update_clip(job_id, clip_id, req)
        return job.model_dump()
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.delete("/api/jobs/{job_id}/clips/{clip_id}")
async def remove_clip(job_id: str, clip_id: str) -> dict:
    try:
        job = job_manager.delete_clip(job_id, clip_id)
        return job.model_dump()
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


def _iter_file_range(path: Path, start: int, length: int, chunk_size: int = 256 * 1024) -> Iterator[bytes]:
    with path.open("rb") as f:
        f.seek(start)
        remaining = length
        while remaining > 0:
            data = f.read(min(chunk_size, remaining))
            if not data:
                break
            remaining -= len(data)
            yield data


@app.get("/api/jobs/{job_id}/clips/{clip_id}/stream")
async def stream_clip(job_id: str, clip_id: str, request: Request):
    """RFC 7233 HTTP Range streaming endpoint for smooth 4K video scrubbing in browser."""
    file_path, _clip = job_manager.get_clip_file(job_id, clip_id)
    if not file_path:
        raise HTTPException(status_code=404, detail="Clip video file not ready.")

    file_size = os.path.getsize(file_path)
    range_header = request.headers.get("range")

    if range_header:
        m = re.match(r"bytes=(\d+)-(\d*)", range_header)
        if m:
            start = int(m.group(1))
            end = int(m.group(2)) if m.group(2) else file_size - 1
            end = min(end, file_size - 1)
            if start >= file_size or start > end:
                raise HTTPException(status_code=416, detail="Requested range not satisfiable")
            content_length = end - start + 1
            headers = {
                "Content-Range": f"bytes {start}-{end}/{file_size}",
                "Accept-Ranges": "bytes",
                "Content-Length": str(content_length),
                "Cache-Control": "no-cache",
            }
            return StreamingResponse(
                _iter_file_range(file_path, start, content_length),
                status_code=206,
                media_type="video/mp4",
                headers=headers,
            )

    return FileResponse(
        path=str(file_path),
        media_type="video/mp4",
        headers={"Accept-Ranges": "bytes", "Cache-Control": "no-cache"},
    )


@app.get("/api/jobs/{job_id}/clips/{clip_id}/poster")
async def get_clip_poster(job_id: str, clip_id: str):
    poster = job_manager.get_poster_file(job_id, clip_id)
    if not poster:
        raise HTTPException(status_code=404, detail="Poster not available.")
    return FileResponse(path=str(poster), media_type="image/jpeg")


@app.get("/api/jobs/{job_id}/clips/{clip_id}/download")
async def download_clip(job_id: str, clip_id: str):
    job = job_manager.get_job(job_id)
    file_path, clip = job_manager.get_clip_file(job_id, clip_id)
    if not job or not file_path or not clip:
        raise HTTPException(status_code=404, detail="Clip not ready for download.")
    dl_name = job_manager.download_filename(job, clip)
    return FileResponse(
        path=str(file_path),
        media_type="video/mp4",
        filename=dl_name,
        headers={"Content-Disposition": f'attachment; filename="{dl_name}"'},
    )


@app.get("/api/jobs/{job_id}/download-all")
async def download_all_clips(job_id: str):
    try:
        zip_path, dl_name = job_manager.build_zip_archive(job_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Job not found.")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return FileResponse(
        path=str(zip_path),
        media_type="application/zip",
        filename=dl_name,
        headers={"Content-Disposition": f'attachment; filename="{dl_name}"'},
    )


# Serve built React studio SPA on the same origin for seamless live preview & single-port deployment
if FRONTEND_DIST.exists():
    assets_dir = FRONTEND_DIST / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        if full_path.startswith("api/"):
            raise HTTPException(status_code=404, detail="API route not found")
        candidate = (FRONTEND_DIST / full_path).resolve()
        if full_path and candidate.is_file() and str(candidate).startswith(str(FRONTEND_DIST)):
            return FileResponse(str(candidate))
        index_html = FRONTEND_DIST / "index.html"
        if index_html.exists():
            return FileResponse(str(index_html))
        raise HTTPException(status_code=404, detail="Frontend bundle not built yet.")
