from __future__ import annotations

import json
import os
from pathlib import Path
from threading import Lock
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent
_storage_root = os.getenv("CLIPFORGE_STORAGE_DIR", "").strip()
if _storage_root:
    _root = Path(_storage_root)
    DATA_DIR = _root / "data"
    CACHE_DIR = _root / "cache"
else:
    DATA_DIR = BASE_DIR / "data"
    CACHE_DIR = BASE_DIR / ".cache"

JOBS_MEDIA_DIR = CACHE_DIR / "jobs"
UPLOADS_DIR = CACHE_DIR / "uploads"
COOKIES_PATH = CACHE_DIR / "youtube_cookies.txt"
SETTINGS_PATH = CACHE_DIR / "settings.json"
JOBS_INDEX_PATH = DATA_DIR / "jobs.json"

for d in (DATA_DIR, CACHE_DIR, JOBS_MEDIA_DIR, UPLOADS_DIR):
    d.mkdir(parents=True, exist_ok=True)

# Auto-load YouTube cookies from Render Secret Files (/etc/secrets/cookies.txt) or YTDLP_COOKIES_TXT env var
if not COOKIES_PATH.exists():
    for _secret_candidate in (
        Path("/etc/secrets/cookies.txt"),
        Path("/etc/secrets/youtube_cookies.txt"),
    ):
        try:
            if _secret_candidate.exists() and _secret_candidate.stat().st_size > 35:
                _raw_cookie = _secret_candidate.read_text(encoding="utf-8", errors="ignore").strip()
                if _raw_cookie:
                    if not _raw_cookie.startswith("# Netscape HTTP Cookie File"):
                        _raw_cookie = "# Netscape HTTP Cookie File\n" + _raw_cookie
                    COOKIES_PATH.write_text(_raw_cookie + "\n", encoding="utf-8")
                    break
        except Exception:
            pass
    if not COOKIES_PATH.exists():
        _env_cookies = os.getenv("YTDLP_COOKIES_TXT", "").strip()
        if len(_env_cookies) > 35:
            if not _env_cookies.startswith("# Netscape HTTP Cookie File"):
                _env_cookies = "# Netscape HTTP Cookie File\n" + _env_cookies
            COOKIES_PATH.write_text(_env_cookies + "\n", encoding="utf-8")

_lock = Lock()

DEFAULT_SETTINGS: dict[str, Any] = {
    "ai_provider": "auto",
    "openai_api_key": os.getenv("OPENAI_API_KEY", ""),
    "openai_model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
    "gemini_api_key": os.getenv("GEMINI_API_KEY", ""),
    "gemini_model": os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
    "anthropic_api_key": os.getenv("ANTHROPIC_API_KEY", ""),
    "anthropic_model": os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-20250514"),
    "custom_base_url": os.getenv("CUSTOM_LLM_BASE_URL", "http://localhost:11434/v1"),
    "custom_api_key": os.getenv("CUSTOM_LLM_API_KEY", ""),
    "custom_model": os.getenv("CUSTOM_LLM_MODEL", "llama3.1"),
    "cookies_from_browser": os.getenv("YTDLP_COOKIES_FROM_BROWSER", ""),
    "proxy_url": os.getenv("YTDLP_PROXY", ""),
}


def load_settings() -> dict[str, Any]:
    with _lock:
        data = dict(DEFAULT_SETTINGS)
        if SETTINGS_PATH.exists():
            try:
                saved = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
                if isinstance(saved, dict):
                    for k, v in saved.items():
                        if v is not None and k in data:
                            data[k] = v
            except Exception:
                pass
        # Always allow non-empty env vars as fallback
        for env_key, setting_key in [
            ("OPENAI_API_KEY", "openai_api_key"),
            ("GEMINI_API_KEY", "gemini_api_key"),
            ("ANTHROPIC_API_KEY", "anthropic_api_key"),
        ]:
            if not data.get(setting_key) and os.getenv(env_key):
                data[setting_key] = os.getenv(env_key)
        return data


def update_settings(patch: dict[str, Any]) -> dict[str, Any]:
    current = load_settings()
    with _lock:
        if "cookies_txt" in patch and patch["cookies_txt"] is not None:
            raw = str(patch.pop("cookies_txt")).strip()
            if raw:
                if not raw.startswith("# Netscape HTTP Cookie File"):
                    raw = "# Netscape HTTP Cookie File\n" + raw
                COOKIES_PATH.write_text(raw + "\n", encoding="utf-8")
            else:
                COOKIES_PATH.unlink(missing_ok=True)
        else:
            patch.pop("cookies_txt", None)

        for k, v in patch.items():
            if v is not None and k in current:
                current[k] = v.strip() if isinstance(v, str) else v

        SETTINGS_PATH.write_text(json.dumps(current, indent=2), encoding="utf-8")
    return get_public_settings()


def _mask_key(key: str) -> str:
    if not key:
        return ""
    if len(key) <= 8:
        return "••••••••"
    return f"{key[:4]}••••••••{key[-4:]}"


def has_cookies_file() -> bool:
    return COOKIES_PATH.exists() and COOKIES_PATH.stat().st_size > 35


def cookie_line_count() -> int:
    if not has_cookies_file():
        return 0
    try:
        lines = [
            ln.strip()
            for ln in COOKIES_PATH.read_text(encoding="utf-8", errors="ignore").splitlines()
            if ln.strip() and not ln.strip().startswith("#")
        ]
        return len(lines)
    except Exception:
        return 0


def resolve_active_ai_label(settings: dict[str, Any] | None = None) -> str:
    s = settings or load_settings()
    provider = s.get("ai_provider", "auto")
    if provider == "openai" and s.get("openai_api_key"):
        return f"OpenAI ({s.get('openai_model', 'gpt-4o-mini')})"
    if provider == "gemini" and s.get("gemini_api_key"):
        return f"Google Gemini ({s.get('gemini_model', 'gemini-2.5-flash')})"
    if provider == "anthropic" and s.get("anthropic_api_key"):
        return f"Anthropic ({s.get('anthropic_model', 'claude-sonnet-4-20250514')})"
    if provider == "custom" and s.get("custom_base_url") and s.get("custom_model"):
        return f"Custom LLM ({s.get('custom_model')})"
    if provider == "auto":
        if s.get("openai_api_key"):
            return f"OpenAI ({s.get('openai_model', 'gpt-4o-mini')})"
        if s.get("gemini_api_key"):
            return f"Google Gemini ({s.get('gemini_model', 'gemini-2.5-flash')})"
        if s.get("anthropic_api_key"):
            return f"Anthropic ({s.get('anthropic_model', 'claude-sonnet-4-20250514')})"
    return "ClipForge Viral AI (Heatmap + NLP + Audio)"


def get_public_settings() -> dict[str, Any]:
    s = load_settings()
    return {
        "ai_provider": s["ai_provider"],
        "active_ai_label": resolve_active_ai_label(s),
        "has_openai_key": bool(s.get("openai_api_key")),
        "openai_key_masked": _mask_key(s.get("openai_api_key", "")),
        "openai_model": s.get("openai_model", "gpt-4o-mini"),
        "has_gemini_key": bool(s.get("gemini_api_key")),
        "gemini_key_masked": _mask_key(s.get("gemini_api_key", "")),
        "gemini_model": s.get("gemini_model", "gemini-2.5-flash"),
        "has_anthropic_key": bool(s.get("anthropic_api_key")),
        "anthropic_key_masked": _mask_key(s.get("anthropic_api_key", "")),
        "anthropic_model": s.get("anthropic_model", "claude-sonnet-4-20250514"),
        "custom_base_url": s.get("custom_base_url", ""),
        "has_custom_key": bool(s.get("custom_api_key")),
        "custom_model": s.get("custom_model", ""),
        "has_cookies_file": has_cookies_file(),
        "cookie_count": cookie_line_count(),
        "cookies_from_browser": s.get("cookies_from_browser", ""),
        "proxy_url": s.get("proxy_url", ""),
    }
