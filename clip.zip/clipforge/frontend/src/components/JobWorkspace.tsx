import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowUpDown,
  CheckCircle2,
  Download,
  ExternalLink,
  KeyRound,
  Loader2,
  RotateCcw,
  Sparkles,
  Square as StopSquare,
} from 'lucide-react';
import { api } from '../api';
import type { AspectRatio, ClipItem, JobRecord } from '../types';
import { formatTimecode, formatViews } from '../utils/format';
import { ClipCard } from './ClipCard';
import {
  AddClipModal,
  TheaterModal,
  TranscriptModal,
  TrimModal,
} from './ClipModals';
import { EngagementTimeline } from './EngagementTimeline';

interface JobWorkspaceProps {
  job: JobRecord;
  onJobChange: (updated: JobRecord) => void;
  onBackToComposer: () => void;
  onRetrySameUrl: (url: string) => void;
  onOpenCookieSettings: () => void;
}

const PIPELINE_STEPS = [
  { key: 'fetching_metadata', label: 'yt-dlp Stream Scan' },
  { key: 'analyzing', label: 'AI Viral Scoring' },
  { key: 'extracting', label: '4K Clip Mastering' },
  { key: 'completed', label: 'Preview & Download' },
] as const;

function stepIndexForStatus(status: JobRecord['status']): number {
  switch (status) {
    case 'queued':
    case 'fetching_metadata':
      return 0;
    case 'analyzing':
      return 1;
    case 'awaiting_selection':
      return 2;
    case 'extracting':
      return 2;
    case 'completed':
      return 3;
    default:
      return -1;
  }
}

export function JobWorkspace({
  job,
  onJobChange,
  onBackToComposer,
  onRetrySameUrl,
  onOpenCookieSettings,
}: JobWorkspaceProps) {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(
    () => new Set(job.clips.map((c) => c.id))
  );
  const [sortBy, setSortBy] = useState<'score' | 'time'>('score');
  const [highlightedClipId, setHighlightedClipId] = useState<string | null>(null);
  const [theaterClip, setTheaterClip] = useState<ClipItem | null>(null);
  const [trimClip, setTrimClip] = useState<ClipItem | null>(null);
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [addInitialStart, setAddInitialStart] = useState(0);
  const [transcriptOpen, setTranscriptOpen] = useState(false);
  const [actionErr, setActionErr] = useState<string | null>(null);

  const isRunning = ['queued', 'fetching_metadata', 'analyzing', 'extracting'].includes(
    job.status
  );
  const isReviewMode = job.status === 'awaiting_selection';
  const readyClips = useMemo(
    () => job.clips.filter((c) => c.status === 'ready' && c.filename),
    [job.clips]
  );

  // Sync newly discovered clips into selectedIds during review mode
  const effectiveSelected = useMemo(() => {
    if (selectedIds.size === 0 && job.clips.length > 0 && isReviewMode) {
      return new Set(job.clips.map((c) => c.id));
    }
    return selectedIds;
  }, [selectedIds, job.clips, isReviewMode]);

  const sortedClips = useMemo(() => {
    const arr = [...job.clips];
    if (sortBy === 'time') {
      arr.sort((a, b) => a.start_time - b.start_time);
    } else {
      arr.sort((a, b) => b.virality_score - a.virality_score || a.index - b.index);
    }
    return arr;
  }, [job.clips, sortBy]);

  const toggleSelect = (clipId: string) => {
    setSelectedIds((prev) => {
      const base = prev.size === 0 ? new Set(job.clips.map((c) => c.id)) : new Set(prev);
      if (base.has(clipId)) {
        base.delete(clipId);
      } else {
        base.add(clipId);
      }
      return base;
    });
  };

  const handleExtractBatch = async (ids?: string[]) => {
    setActionErr(null);
    try {
      const updated = await api.extractSelected(job.id, {
        clip_ids: ids && ids.length > 0 ? ids : Array.from(effectiveSelected),
      });
      onJobChange(updated);
    } catch (e) {
      setActionErr(e instanceof Error ? e.message : 'Failed to start extraction');
    }
  };

  const handleCancel = async () => {
    try {
      const updated = await api.cancelJob(job.id);
      onJobChange(updated);
    } catch {
      // ignore
    }
  };

  const handleSaveTrim = async (
    clipId: string,
    payload: {
      title: string;
      start_time: number;
      end_time: number;
      aspect_ratio: AspectRatio;
      burn_captions: boolean;
      re_extract: boolean;
    }
  ) => {
    const updated = await api.updateClip(job.id, clipId, payload);
    onJobChange(updated);
  };

  const handleAddClip = async (payload: {
    title: string;
    start_time: number;
    end_time: number;
    extract_now: boolean;
  }) => {
    const updated = await api.addCustomClip(job.id, payload);
    onJobChange(updated);
  };

  const handleDeleteClip = async (clipId: string) => {
    try {
      const updated = await api.deleteClip(job.id, clipId);
      onJobChange(updated);
    } catch (e) {
      setActionErr(e instanceof Error ? e.message : 'Could not delete clip');
    }
  };

  const handleTimelineFocus = (clip: ClipItem) => {
    setHighlightedClipId(clip.id);
    const el = document.getElementById(`clip-card-${clip.id}`);
    el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    setTimeout(() => {
      setHighlightedClipId((cur) => (cur === clip.id ? null : cur));
    }, 2200);
  };

  const activeStep = stepIndexForStatus(job.status);

  return (
    <div className="space-y-6 pt-6 pb-16">
      {/* Top Breadcrumb */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBackToComposer}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-400 transition hover:text-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Analyze another video
        </button>

        {job.ai_engine_used && (
          <span className="rounded-full border border-white/[0.07] bg-[#11131A] px-3 py-1 font-mono text-[11px] text-zinc-400">
            AI: <span className="text-zinc-200">{job.ai_engine_used}</span>
          </span>
        )}
      </div>

      {/* Source Video Metadata Banner */}
      {job.video && (
        <div className="flex flex-col gap-4 rounded-2xl border border-white/[0.08] bg-[#11131A] p-4 sm:flex-row sm:items-center sm:p-5">
          {job.video.thumbnail && (
            <div className="relative h-24 w-full shrink-0 overflow-hidden rounded-xl bg-black sm:w-44">
              <img
                src={job.video.thumbnail}
                alt={job.video.title}
                className="h-full w-full object-cover"
              />
              {job.video.duration > 0 && (
                <span className="absolute right-1.5 bottom-1.5 rounded bg-black/80 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-white">
                  {formatTimecode(job.video.duration)}
                </span>
              )}
            </div>
          )}

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded bg-white/[0.07] px-2 py-0.5 font-mono text-[10px] font-semibold uppercase text-zinc-300">
                {job.video.extractor}
              </span>
              {job.video.duration > 0 && (
                <span
                  className={`rounded px-2 py-0.5 font-mono text-[10px] font-semibold ${
                    job.video.has_native_4k
                      ? 'bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-500/30'
                      : 'bg-[#FF5A36]/15 text-[#FF8566] ring-1 ring-[#FF5A36]/30'
                  }`}
                >
                  {job.video.has_native_4k
                    ? `Native 4K Source (${job.video.max_source_height}p)`
                    : job.resolution === '4k'
                    ? `Source ${job.video.max_source_height}p → 4K 2160p Master`
                    : `Source ${job.video.max_source_height}p`}
                </span>
              )}
              {job.video.has_transcript && (
                <span className="rounded bg-white/[0.05] px-2 py-0.5 font-mono text-[10px] text-zinc-300">
                  {job.video.transcript_word_count.toLocaleString()} words analyzed
                </span>
              )}
            </div>

            <h2 className="mt-2 line-clamp-1 text-base font-bold text-white sm:text-lg">
              {job.video.title}
            </h2>

            <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-zinc-400">
              <span>{job.video.channel}</span>
              {job.video.view_count ? (
                <>
                  <span className="text-white/15">·</span>
                  <span>{formatViews(job.video.view_count)}</span>
                </>
              ) : null}
              <span className="text-white/15">·</span>
              <span className="font-mono text-[11px]">
                Target: {job.clip_count} clips × ≤{job.clip_duration}s ({job.aspect_ratio})
              </span>
              {!job.video.is_local_upload && (
                <a
                  href={job.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-[#FF8566] hover:underline"
                >
                  Source <ExternalLink className="h-3 w-3" />
                </a>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Live Pipeline Progress Card */}
      {isRunning && (
        <div className="rounded-2xl border border-[#FF5A36]/30 bg-[#131520] p-5 shadow-lg shadow-black/30">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Loader2 className="h-5 w-5 shrink-0 animate-spin text-[#FF5A36]" />
              <div>
                <p className="text-sm font-semibold text-white">{job.stage_message}</p>
                <p className="mt-0.5 text-xs text-zinc-400">
                  Finished clips become playable & downloadable immediately while others render.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="font-mono text-sm font-bold text-[#FF8566]">
                {Math.round(job.overall_progress)}%
              </span>
              <button
                type="button"
                onClick={() => void handleCancel()}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/[0.05] px-3 py-1.5 text-xs font-medium text-zinc-200 transition hover:bg-red-500/15 hover:text-red-200"
              >
                <StopSquare className="h-3 w-3 fill-current" />
                Stop
              </button>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-white/[0.08]">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#FF5A36] to-[#FF9B54] transition-all duration-500"
              style={{ width: `${Math.max(4, Math.round(job.overall_progress))}%` }}
            />
          </div>

          {/* 4-Step Tracker */}
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {PIPELINE_STEPS.map((step, idx) => {
              const done = activeStep > idx;
              const current = activeStep === idx;
              return (
                <div
                  key={step.key}
                  className={`flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs ${
                    current
                      ? 'bg-[#FF5A36]/15 font-semibold text-white ring-1 ring-[#FF5A36]/40'
                      : done
                      ? 'bg-emerald-500/10 text-emerald-300'
                      : 'bg-white/[0.03] text-zinc-500'
                  }`}
                >
                  <span
                    className={`h-2 w-2 rounded-full ${
                      current
                        ? 'animate-pulse-glow bg-[#FF5A36]'
                        : done
                        ? 'bg-emerald-400'
                        : 'bg-zinc-600'
                    }`}
                  />
                  <span className="truncate">{step.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Error / YouTube Cloud Authentication Card */}
      {job.status === 'failed' && (
        <div className="rounded-2xl border border-amber-500/30 bg-[#14141D] p-5 sm:p-6">
          <div className="flex items-start gap-3.5">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
            <div className="flex-1">
              <h3 className="text-sm font-bold text-white">
                {job.error_code === 'YOUTUBE_AUTH_REQUIRED'
                  ? 'YouTube Sign-In Cookies Needed on Cloud IP'
                  : 'Could Not Process Video'}
              </h3>
              <p className="mt-1.5 text-xs leading-relaxed text-zinc-300">
                {job.error || 'An unexpected error occurred while running yt-dlp.'}
              </p>

              <div className="mt-4 flex flex-wrap items-center gap-2.5">
                {job.error_code === 'YOUTUBE_AUTH_REQUIRED' && (
                  <button
                    type="button"
                    onClick={onOpenCookieSettings}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#FF5A36] to-[#FF7B3A] px-4 py-2 text-xs font-bold text-white shadow hover:brightness-110"
                  >
                    <KeyRound className="h-3.5 w-3.5" />
                    Connect YouTube cookies.txt
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onRetrySameUrl(job.url)}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-white/12 bg-[#1A1E2C] px-3.5 py-2 text-xs font-semibold text-zinc-200 hover:bg-[#222738]"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  Retry Video
                </button>
                <button
                  type="button"
                  onClick={onBackToComposer}
                  className="rounded-xl border border-white/[0.08] px-3.5 py-2 text-xs font-medium text-zinc-400 hover:text-white"
                >
                  Try Another URL or Upload File
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {actionErr && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-200">
          {actionErr}
        </div>
      )}

      {/* Interactive Engagement & Virality Timeline */}
      {job.video && job.video.duration > 0 && job.engagement_curve.length > 0 && (
        <EngagementTimeline
          duration={job.video.duration}
          curve={job.engagement_curve}
          clips={job.clips}
          hasHeatmap={job.video.has_heatmap}
          hasTranscript={job.video.has_transcript}
          activeClipId={highlightedClipId}
          onSelectClip={handleTimelineFocus}
          onAddCustomClip={() => {
            setAddInitialStart(Math.min(30, job.video!.duration * 0.2));
            setAddModalOpen(true);
          }}
          onOpenTranscript={() => setTranscriptOpen(true)}
        />
      )}

      {/* Review Mode Action Banner */}
      {isReviewMode && job.clips.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#FF5A36]/35 bg-[#FF5A36]/10 px-5 py-4">
          <div>
            <p className="text-sm font-bold text-white">
              {job.clips.length} Viral Moments Ready to Export
            </p>
            <p className="text-xs text-zinc-300">
              Select the moments you want, trim timestamps (up to 60s), or extract them all in 4K.
            </p>
          </div>
          <button
            type="button"
            disabled={effectiveSelected.size === 0}
            onClick={() => void handleExtractBatch()}
            className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#FF5A36] to-[#FF7B3A] px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-[#FF5A36]/25 hover:brightness-110 disabled:opacity-50"
          >
            <Sparkles className="h-4 w-4" />
            Extract {effectiveSelected.size} Selected{' '}
            {effectiveSelected.size === 1 ? 'Clip' : 'Clips'} in 4K
          </button>
        </div>
      )}

      {/* Clips Section Header + Sort + Download All ZIP */}
      {job.clips.length > 0 && (
        <section>
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <h3 className="text-base font-bold text-white">
                Generated Viral Clips ({readyClips.length}/{job.clips.length})
              </h3>
              {job.status === 'completed' && readyClips.length > 0 && (
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2.5 py-0.5 text-xs font-medium text-emerald-300">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  Complete
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSortBy((s) => (s === 'score' ? 'time' : 'score'))}
                className="inline-flex items-center gap-1.5 rounded-xl border border-white/[0.08] bg-[#11131A] px-3 py-2 text-xs font-medium text-zinc-300 transition hover:border-white/20 hover:text-white"
              >
                <ArrowUpDown className="h-3.5 w-3.5 text-zinc-400" />
                {sortBy === 'score' ? 'Sorted by Viral Score' : 'Sorted by Timeline'}
              </button>

              {readyClips.length > 1 && (
                <a
                  href={api.jobZipUrl(job.id)}
                  download
                  className="inline-flex items-center gap-1.5 rounded-xl border border-white/[0.12] bg-[#181C28] px-3.5 py-2 text-xs font-semibold text-white transition hover:border-[#FF5A36]/50 hover:bg-[#1F2433]"
                >
                  <Download className="h-3.5 w-3.5 text-[#FF7A59]" />
                  Download All ({readyClips.length}) .ZIP
                </a>
              )}
            </div>
          </div>

          {/* Responsive Clip Cards Grid */}
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {sortedClips.map((clip) => (
              <ClipCard
                key={clip.id}
                jobId={job.id}
                clip={clip}
                isReviewMode={isReviewMode}
                isSelected={effectiveSelected.has(clip.id)}
                isHighlighted={highlightedClipId === clip.id}
                onToggleSelect={toggleSelect}
                onOpenTheater={(c) => setTheaterClip(c)}
                onOpenTrim={(c) => setTrimClip(c)}
                onExtractSingle={(cid) => void handleExtractBatch([cid])}
                onDeleteClip={(cid) => void handleDeleteClip(cid)}
              />
            ))}
          </div>
        </section>
      )}

      {/* Modals */}
      <TheaterModal
        jobId={job.id}
        clip={theaterClip}
        onClose={() => setTheaterClip(null)}
        onEditTrim={(c) => setTrimClip(c)}
      />

      <TrimModal
        clip={trimClip}
        videoDuration={job.video?.duration || 3600}
        hasTranscript={Boolean(job.video?.has_transcript)}
        isReviewMode={isReviewMode}
        onClose={() => setTrimClip(null)}
        onSave={handleSaveTrim}
      />

      <AddClipModal
        open={addModalOpen}
        videoDuration={job.video?.duration || 600}
        defaultDuration={job.clip_duration}
        initialStart={addInitialStart}
        onClose={() => setAddModalOpen(false)}
        onAdd={handleAddClip}
      />

      <TranscriptModal
        open={transcriptOpen}
        jobId={job.id}
        onClose={() => setTranscriptOpen(false)}
        onClipFromTimestamp={(ts) => {
          setAddInitialStart(ts);
          setAddModalOpen(true);
        }}
      />
    </div>
  );
}
