from __future__ import annotations

import asyncio
import json
import re
import shutil
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock
from typing import Optional

from models import (
    AddCustomClipRequest,
    ClipItem,
    CreateJobRequest,
    ExtractSelectedRequest,
    JobRecord,
    SubScores,
    TranscriptSegment,
    UpdateClipRequest,
    VideoMetadata,
)
from services.ai_analyzer import analyze_viral_moments, transcript_slice
from services.config_store import JOBS_INDEX_PATH, JOBS_MEDIA_DIR
from services.ytdlp_service import (
    YouTubeAuthRequiredError,
    extract_and_master_clip,
    extract_video_info,
    sample_audio_energy_peaks,
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _slugify(text: str, max_len: int = 44) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "_", text.lower()).strip("_")
    return (s[:max_len].rstrip("_")) or "viral_clip"


class JobManager:
    def __init__(self) -> None:
        self._jobs: dict[str, JobRecord] = {}
        self._cancelled: set[str] = set()
        self._lock = Lock()
        self._encode_sem = asyncio.Semaphore(1)
        self._load_from_disk()

    def _job_dir(self, job_id: str) -> Path:
        d = JOBS_MEDIA_DIR / job_id
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _transcript_path(self, job_id: str) -> Path:
        return self._job_dir(job_id) / "transcript.json"

    def save_transcript(self, job_id: str, segments: list[TranscriptSegment]) -> None:
        p = self._transcript_path(job_id)
        p.write_text(
            json.dumps([s.model_dump() for s in segments], ensure_ascii=False),
            encoding="utf-8",
        )

    def load_transcript(self, job_id: str) -> list[TranscriptSegment]:
        p = self._transcript_path(job_id)
        if not p.exists():
            return []
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
            return [TranscriptSegment(**item) for item in raw]
        except Exception:
            return []

    def _load_from_disk(self) -> None:
        if not JOBS_INDEX_PATH.exists():
            return
        try:
            items = json.loads(JOBS_INDEX_PATH.read_text(encoding="utf-8"))
            for item in items:
                job = JobRecord(**item)
                # Mark interrupted jobs cleanly after server restarts
                if job.status in ("queued", "fetching_metadata", "analyzing", "extracting"):
                    ready_any = any(c.status == "ready" for c in job.clips)
                    job.status = "awaiting_selection" if job.clips and not ready_any else (
                        "completed" if ready_any else "failed"
                    )
                    job.stage_message = "Session resumed — ready to continue"
                    for c in job.clips:
                        if c.status == "extracting":
                            c.status = "pending"
                            c.progress = 0.0
                # Verify media files still exist in cache
                jdir = JOBS_MEDIA_DIR / job.id
                for c in job.clips:
                    if c.status == "ready" and c.filename and not (jdir / c.filename).exists():
                        c.status = "pending"
                        c.progress = 0.0
                self._jobs[job.id] = job
        except Exception:
            pass

    def _persist(self) -> None:
        max_jobs = max(5, int(__import__("os").getenv("MAX_STORED_JOBS", "20")))
        with self._lock:
            all_ordered = sorted(self._jobs.values(), key=lambda j: j.created_at, reverse=True)
            ordered = all_ordered[:max_jobs]
            # Auto-prune evicted old job directories so Render disk storage stays healthy
            for stale in all_ordered[max_jobs:]:
                self._jobs.pop(stale.id, None)
                stale_dir = JOBS_MEDIA_DIR / stale.id
                if stale_dir.exists():
                    shutil.rmtree(stale_dir, ignore_errors=True)
            payload = [j.model_dump() for j in ordered]
            JOBS_INDEX_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def _touch(self, job: JobRecord) -> None:
        job.updated_at = _utc_now()

    def list_jobs(self) -> list[JobRecord]:
        return sorted(self._jobs.values(), key=lambda j: j.created_at, reverse=True)

    def get_job(self, job_id: str) -> Optional[JobRecord]:
        return self._jobs.get(job_id)

    def get_clip_file(self, job_id: str, clip_id: str) -> tuple[Optional[Path], Optional[ClipItem]]:
        job = self._jobs.get(job_id)
        if not job:
            return None, None
        clip = next((c for c in job.clips if c.id == clip_id), None)
        if not clip or not clip.filename:
            return None, clip
        p = self._job_dir(job_id) / clip.filename
        return (p if p.exists() else None), clip

    def get_poster_file(self, job_id: str, clip_id: str) -> Optional[Path]:
        job = self._jobs.get(job_id)
        if not job:
            return None
        clip = next((c for c in job.clips if c.id == clip_id), None)
        if not clip or not clip.poster_filename:
            return None
        p = self._job_dir(job_id) / clip.poster_filename
        return p if p.exists() else None

    def download_filename(self, job: JobRecord, clip: ClipItem) -> str:
        res_tag = "4K_2160p" if clip.is_4k else (f"{clip.height}p" if clip.height else job.resolution)
        ar_tag = clip.aspect_ratio.replace(":", "x")
        slug = _slugify(clip.title, 38)
        return f"{clip.index:02d}_{slug}_{res_tag}_{ar_tag}.mp4"

    def cancel_job(self, job_id: str) -> Optional[JobRecord]:
        job = self._jobs.get(job_id)
        if not job:
            return None
        self._cancelled.add(job_id)
        if job.status in ("queued", "fetching_metadata", "analyzing", "extracting"):
            job.status = "cancelled"
            job.stage_message = "Job cancelled by user"
            for c in job.clips:
                if c.status == "extracting":
                    c.status = "pending"
                    c.progress = 0.0
            self._touch(job)
            self._persist()
        return job

    def delete_job(self, job_id: str) -> bool:
        self._cancelled.add(job_id)
        existed = self._jobs.pop(job_id, None) is not None
        jdir = JOBS_MEDIA_DIR / job_id
        if jdir.exists():
            shutil.rmtree(jdir, ignore_errors=True)
        if existed:
            self._persist()
        return existed

    def create_job(self, req: CreateJobRequest) -> JobRecord:
        job_id = uuid.uuid4().hex[:10]
        now = _utc_now()
        job = JobRecord(
            id=job_id,
            created_at=now,
            updated_at=now,
            status="queued",
            stage_message="Initializing yt-dlp extraction pipeline…",
            overall_progress=2.0,
            url=req.url,
            clip_count=req.clip_count,
            clip_duration=min(60, req.clip_duration),
            resolution=req.resolution,
            aspect_ratio=req.aspect_ratio,
            vertical_layout=req.vertical_layout,
            burn_captions=req.burn_captions,
            smart_sentence_snap=req.smart_sentence_snap,
            focus_prompt=req.focus_prompt.strip(),
            workflow_mode=req.workflow_mode,
        )
        self._jobs[job_id] = job
        self._cancelled.discard(job_id)
        self._persist()
        asyncio.create_task(self._run_full_pipeline(job_id))
        return job

    async def _run_full_pipeline(self, job_id: str) -> None:
        job = self._jobs.get(job_id)
        if not job:
            return

        try:
            job.status = "fetching_metadata"
            job.stage_message = "Inspecting video streams, 4K formats & captions with yt-dlp…"
            job.overall_progress = 8.0
            self._touch(job)

            meta, transcript, heatmap, raw_info = await asyncio.to_thread(
                extract_video_info, job.url
            )
            if job_id in self._cancelled:
                return

            job.video = meta
            if transcript:
                self.save_transcript(job_id, transcript)
            job.overall_progress = 20.0
            job.status = "analyzing"

            # If video has neither transcript nor heatmap, sample audio energy peaks
            if not transcript and not heatmap:
                sample_target = raw_info.get("local_path") or (
                    raw_info.get("url") if job.url.lower().endswith((".mp4", ".mov", ".mkv", ".webm")) else None
                )
                if sample_target:
                    job.stage_message = "Sampling audio energy dynamics across video timeline…"
                    self._touch(job)
                    heatmap = await asyncio.to_thread(
                        sample_audio_energy_peaks, sample_target, meta.duration, 14
                    )

            if job_id in self._cancelled:
                return

            job.stage_message = f"AI scoring top {job.clip_count} viral moments (≤ {job.clip_duration}s each)…"
            job.overall_progress = 28.0
            self._touch(job)

            clips, curve, ai_label = await analyze_viral_moments(
                meta=meta,
                transcript=transcript,
                heatmap=heatmap,
                clip_count=job.clip_count,
                clip_duration=job.clip_duration,
                smart_snap=job.smart_sentence_snap,
                focus_prompt=job.focus_prompt,
            )

            for c in clips:
                c.aspect_ratio = job.aspect_ratio
                c.burn_captions = job.burn_captions
                c.status = "selected" if job.workflow_mode == "review" else "pending"

            job.clips = clips
            job.engagement_curve = curve
            job.ai_engine_used = ai_label
            job.overall_progress = 35.0
            self._touch(job)
            self._persist()

            if job_id in self._cancelled:
                return

            if job.workflow_mode == "review":
                job.status = "awaiting_selection"
                job.stage_message = (
                    f"AI identified {len(clips)} viral moments — preview timestamps, tweak trims, "
                    f"or click Extract in 4K."
                )
                self._touch(job)
                self._persist()
                return

            await self._extract_clips_for_job(job_id, [c.id for c in clips])

        except YouTubeAuthRequiredError as auth_err:
            job.status = "failed"
            job.error_code = "YOUTUBE_AUTH_REQUIRED"
            job.error = str(auth_err)
            job.stage_message = "YouTube authentication required on cloud IP"
            if auth_err.partial_meta.get("title"):
                job.video = VideoMetadata(
                    id="yt",
                    url=job.url,
                    title=auth_err.partial_meta.get("title", "YouTube Video"),
                    channel=auth_err.partial_meta.get("channel") or "YouTube Creator",
                    duration=0,
                    thumbnail=auth_err.partial_meta.get("thumbnail"),
                    extractor="youtube",
                )
            self._touch(job)
            self._persist()
        except Exception as exc:
            job.status = "failed"
            job.error_code = "PIPELINE_ERROR"
            job.error = str(exc)[:600]
            job.stage_message = "Failed to process video"
            self._touch(job)
            self._persist()

    async def _extract_clips_for_job(self, job_id: str, target_clip_ids: list[str]) -> None:
        job = self._jobs.get(job_id)
        if not job:
            return

        target_set = set(target_clip_ids)
        targets = [c for c in job.clips if c.id in target_set]
        if not targets:
            return

        for c in job.clips:
            if c.id in target_set:
                c.status = "pending"
                c.progress = 0.0
                c.error = None
            elif c.status == "selected":
                c.status = "skipped"

        job.status = "extracting"
        transcript = self.load_transcript(job_id)
        jdir = self._job_dir(job_id)
        total = len(targets)

        for idx, clip in enumerate(targets, start=1):
            if job_id in self._cancelled:
                job.status = "cancelled"
                job.stage_message = "Extraction cancelled"
                self._persist()
                return

            clip.status = "extracting"
            clip.progress = 3.0
            clip.aspect_ratio = clip.aspect_ratio or job.aspect_ratio
            res_badge = "4K UHD" if job.resolution in ("4k", "4k_native") else job.resolution.upper()
            job.stage_message = f"Clip {idx}/{total}: Extracting “{clip.title[:42]}” in {res_badge}…"
            self._touch(job)

            out_name = f"{clip.id}_{uuid.uuid4().hex[:5]}.mp4"
            poster_name = f"{clip.id}_poster.jpg"
            out_path = jdir / out_name
            poster_path = jdir / poster_name

            # Remove previous file if re-extracting
            if clip.filename and (jdir / clip.filename).exists():
                (jdir / clip.filename).unlink(missing_ok=True)

            def _on_progress(pct: float, msg: str, _clip: ClipItem = clip, _i: int = idx) -> None:
                _clip.progress = pct
                base_share = 35.0 + ((_i - 1) / total) * 65.0
                job.overall_progress = round(min(99.0, base_share + (pct / 100.0) * (65.0 / total)), 1)
                job.stage_message = f"Clip {_i}/{total}: {msg}"
                self._touch(job)

            try:
                async with self._encode_sem:
                    if job_id in self._cancelled:
                        return
                    specs = await asyncio.to_thread(
                        extract_and_master_clip,
                        url=job.url,
                        start_time=clip.start_time,
                        end_time=clip.end_time,
                        output_mp4=out_path,
                        poster_jpg=poster_path,
                        resolution=job.resolution,
                        aspect_ratio=clip.aspect_ratio,
                        vertical_layout=job.vertical_layout,
                        burn_captions=clip.burn_captions,
                        transcript=transcript,
                        progress_cb=_on_progress,
                    )
                clip.filename = out_name
                clip.poster_filename = poster_name if specs.get("has_poster") else None
                clip.width = specs["width"]
                clip.height = specs["height"]
                clip.codec = specs["codec"]
                clip.fps = specs["fps"]
                clip.bitrate_kbps = specs["bitrate_kbps"]
                clip.duration = specs["duration"]
                clip.file_size_bytes = specs["file_size_bytes"]
                clip.is_4k = specs["is_4k"]
                clip.upscaled = specs["upscaled"]
                clip.status = "ready"
                clip.progress = 100.0
                clip.error = None
            except Exception as exc:
                clip.status = "failed"
                clip.progress = 0.0
                clip.error = str(exc)[:300]

            self._touch(job)
            self._persist()

        ready_count = sum(1 for c in job.clips if c.status == "ready")
        failed_count = sum(1 for c in job.clips if c.status == "failed")
        job.overall_progress = 100.0
        if ready_count > 0:
            job.status = "completed"
            suffix = f" ({failed_count} failed)" if failed_count else ""
            job.stage_message = (
                f"{ready_count} viral clip{'s' if ready_count != 1 else ''} ready to preview & download{suffix}"
            )
        else:
            job.status = "failed"
            job.error_code = "EXTRACTION_FAILED"
            job.error = targets[0].error or "All clip extractions failed."
            job.stage_message = "Clip extraction failed"
        self._touch(job)
        self._persist()

    def trigger_extract_selected(self, job_id: str, req: ExtractSelectedRequest) -> JobRecord:
        job = self._jobs.get(job_id)
        if not job:
            raise KeyError("Job not found")
        if job.status == "extracting":
            raise ValueError("Extraction is already running for this video.")

        if req.resolution:
            job.resolution = req.resolution
        if req.aspect_ratio:
            job.aspect_ratio = req.aspect_ratio
            for c in job.clips:
                if not req.clip_ids or c.id in req.clip_ids:
                    c.aspect_ratio = req.aspect_ratio
        if req.vertical_layout:
            job.vertical_layout = req.vertical_layout
        if req.burn_captions is not None:
            job.burn_captions = req.burn_captions
            for c in job.clips:
                if not req.clip_ids or c.id in req.clip_ids:
                    c.burn_captions = req.burn_captions

        ids = req.clip_ids or [c.id for c in job.clips if c.status != "ready"]
        if not ids:
            ids = [c.id for c in job.clips]

        self._cancelled.discard(job_id)
        job.status = "extracting"
        job.error = None
        job.error_code = None
        job.stage_message = f"Preparing to extract {len(ids)} clip(s)…"
        self._touch(job)
        self._persist()
        asyncio.create_task(self._extract_clips_for_job(job_id, ids))
        return job

    def update_clip(self, job_id: str, clip_id: str, req: UpdateClipRequest) -> JobRecord:
        job = self._jobs.get(job_id)
        if not job:
            raise KeyError("Job not found")
        clip = next((c for c in job.clips if c.id == clip_id), None)
        if not clip:
            raise KeyError("Clip not found")

        max_end = job.video.duration if job.video and job.video.duration > 0 else req.end_time
        start = round(max(0.0, req.start_time), 2)
        end = round(min(max_end, req.end_time), 2)
        dur = round(end - start, 2)
        if dur < 2.0:
            raise ValueError("Clip duration must be at least 2 seconds.")
        if dur > 60.0:
            raise ValueError("Clip duration cannot exceed 60 seconds.")

        if req.title is not None and req.title.strip():
            clip.title = req.title.strip()
        clip.start_time = start
        clip.end_time = end
        clip.duration = dur
        if req.aspect_ratio:
            clip.aspect_ratio = req.aspect_ratio
        if req.vertical_layout:
            job.vertical_layout = req.vertical_layout
        if req.resolution:
            job.resolution = req.resolution
        if req.burn_captions is not None:
            clip.burn_captions = req.burn_captions

        transcript = self.load_transcript(job_id)
        if transcript:
            clip.transcript = transcript_slice(transcript, start, end)

        self._cancelled.discard(job_id)
        self._touch(job)
        self._persist()

        if req.re_extract:
            clip.status = "extracting"
            clip.progress = 2.0
            job.status = "extracting"
            job.stage_message = f"Re-rendering “{clip.title[:40]}”…"
            asyncio.create_task(self._extract_clips_for_job(job_id, [clip.id]))
        return job

    def add_custom_clip(self, job_id: str, req: AddCustomClipRequest) -> JobRecord:
        job = self._jobs.get(job_id)
        if not job or not job.video:
            raise KeyError("Job not found")

        start = round(max(0.0, req.start_time), 2)
        end = round(min(job.video.duration, req.end_time), 2)
        dur = round(end - start, 2)
        if dur < 2.0:
            raise ValueError("Clip duration must be at least 2 seconds.")
        if dur > 60.0:
            raise ValueError("Clip duration cannot exceed 60 seconds (1 minute max).")

        transcript = self.load_transcript(job_id)
        txt = transcript_slice(transcript, start, end) if transcript else ""

        new_clip = ClipItem(
            id=f"clip-{uuid.uuid4().hex[:8]}",
            index=len(job.clips) + 1,
            title=req.title.strip() or f"Custom Clip #{len(job.clips) + 1}",
            start_time=start,
            end_time=end,
            duration=dur,
            virality_score=85,
            sub_scores=SubScores(hook=85, retention=86, emotion=84, pacing=85),
            reason="Custom timestamp range selected by you on the video timeline.",
            hook_quote="",
            transcript=txt,
            hashtags=["#shorts", "#viral", "#clip"],
            signals=["Custom Selection"],
            status="pending" if req.extract_now else "selected",
            aspect_ratio=job.aspect_ratio,
            burn_captions=job.burn_captions,
        )
        job.clips.append(new_clip)
        self._cancelled.discard(job_id)
        self._touch(job)
        self._persist()

        if req.extract_now:
            job.status = "extracting"
            asyncio.create_task(self._extract_clips_for_job(job_id, [new_clip.id]))
        return job

    def delete_clip(self, job_id: str, clip_id: str) -> JobRecord:
        job = self._jobs.get(job_id)
        if not job:
            raise KeyError("Job not found")
        clip = next((c for c in job.clips if c.id == clip_id), None)
        if not clip:
            raise KeyError("Clip not found")
        jdir = self._job_dir(job_id)
        if clip.filename:
            (jdir / clip.filename).unlink(missing_ok=True)
        if clip.poster_filename:
            (jdir / clip.poster_filename).unlink(missing_ok=True)
        job.clips = [c for c in job.clips if c.id != clip_id]
        for idx, c in enumerate(job.clips, start=1):
            c.index = idx
        self._touch(job)
        self._persist()
        return job

    def build_zip_archive(self, job_id: str) -> tuple[Path, str]:
        job = self._jobs.get(job_id)
        if not job:
            raise KeyError("Job not found")
        jdir = self._job_dir(job_id)
        ready = [c for c in job.clips if c.status == "ready" and c.filename and (jdir / c.filename).exists()]
        if not ready:
            raise ValueError("No finished clips available to bundle yet.")

        zip_path = jdir / f"clips_bundle_{job.id}.zip"
        # Use ZIP_STORED because MP4 (H.264/AAC) is already compressed — makes bundling instant!
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_STORED) as zf:
            for c in ready:
                assert c.filename is not None
                zf.write(jdir / c.filename, arcname=self.download_filename(job, c))

        title_slug = _slugify(job.video.title if job.video else "clips", 36)
        return zip_path, f"{title_slug}_{len(ready)}_viral_clips_4K.zip"


job_manager = JobManager()
