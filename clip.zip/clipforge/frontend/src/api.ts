import type {
  AspectRatio,
  CreateJobPayload,
  HealthInfo,
  JobRecord,
  PublicSettings,
  ResolutionPreset,
  TranscriptSegment,
  VerticalLayout,
} from './types';

const STORAGE_API_URL = 'clipforge_api_url';
const STORAGE_API_TOKEN = 'clipforge_api_token';

export function normalizeBaseUrl(raw: string): string {
  let u = raw.trim();
  if (!u) return '';
  if (!/^https?:\/\//i.test(u)) {
    u = `https://${u}`;
  }
  // Strip trailing slashes and accidental /api suffix
  u = u.replace(/\/+$/, '').replace(/\/api$/i, '');
  return u;
}

/**
 * Capture optional 1-click connection params (?api=https://your-service.onrender.com&token=...),
 * store safely in localStorage, and clean the URL bar.
 */
export function ingestUrlConnectionParams(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const params = new URLSearchParams(window.location.search);
    const apiParam = params.get('api');
    const tokenParam = params.get('token');
    let changed = false;
    if (apiParam) {
      localStorage.setItem(STORAGE_API_URL, normalizeBaseUrl(apiParam));
      params.delete('api');
      changed = true;
    }
    if (tokenParam !== null) {
      if (tokenParam) {
        localStorage.setItem(STORAGE_API_TOKEN, tokenParam.trim());
      } else {
        localStorage.removeItem(STORAGE_API_TOKEN);
      }
      params.delete('token');
      changed = true;
    }
    if (changed) {
      const qs = params.toString();
      const nextUrl = `${window.location.pathname}${qs ? `?${qs}` : ''}${window.location.hash}`;
      window.history.replaceState({}, '', nextUrl);
    }
    return changed;
  } catch {
    return false;
  }
}

export function getEnvApiBaseUrl(): string {
  const envVal = (import.meta.env.VITE_API_BASE_URL as string | undefined) || '';
  return normalizeBaseUrl(envVal);
}

export function getSavedVpsConfig(): { url: string; token: string; envUrl: string } {
  const envUrl = getEnvApiBaseUrl();
  if (typeof window === 'undefined') {
    return { url: envUrl, token: '', envUrl };
  }
  try {
    const savedUrl = localStorage.getItem(STORAGE_API_URL) || '';
    const envSecret =
      (import.meta.env.VITE_API_SECRET as string | undefined) ||
      (import.meta.env.VITE_VPS_API_SECRET as string | undefined) ||
      '';
    const savedToken = localStorage.getItem(STORAGE_API_TOKEN) || envSecret.trim();
    return {
      url: normalizeBaseUrl(savedUrl) || envUrl,
      token: savedToken,
      envUrl,
    };
  } catch {
    return { url: envUrl, token: '', envUrl };
  }
}

export function saveVpsConfig(url: string, token: string): void {
  const cleanUrl = normalizeBaseUrl(url);
  const cleanToken = token.trim();
  if (cleanUrl) {
    localStorage.setItem(STORAGE_API_URL, cleanUrl);
  } else {
    localStorage.removeItem(STORAGE_API_URL);
  }
  if (cleanToken) {
    localStorage.setItem(STORAGE_API_TOKEN, cleanToken);
  } else {
    localStorage.removeItem(STORAGE_API_TOKEN);
  }
}

export function resolveApiUrl(path: string): string {
  const { url } = getSavedVpsConfig();
  return url ? `${url}${path}` : path;
}

function appendMediaQuery(
  path: string,
  extra: Record<string, string | null | undefined> = {}
): string {
  const { url, token } = getSavedVpsConfig();
  const params = new URLSearchParams();
  if (token) params.set('token', token);
  for (const [k, v] of Object.entries(extra)) {
    if (v) params.set(k, v);
  }
  const qs = params.toString();
  const base = url ? `${url}${path}` : path;
  return qs ? `${base}?${qs}` : base;
}

async function requestJson<T>(path: string, init?: RequestInit): Promise<T> {
  const { token } = getSavedVpsConfig();
  const headers: Record<string, string> = {
    ...(init?.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
    ...(token ? { 'X-ClipForge-Token': token } : {}),
    ...((init?.headers as Record<string, string>) || {}),
  };

  let res: Response;
  try {
    res = await fetch(resolveApiUrl(path), {
      ...init,
      headers,
    });
  } catch {
    throw new Error(
      'Cannot reach Render backend. It may be waking up from sleep (~30s on Render Free) or check your URL in Settings → Render API.'
    );
  }

  const contentType = res.headers.get('content-type') || '';
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    if (contentType.includes('application/json')) {
      try {
        const body = await res.json();
        if (typeof body?.detail === 'string') {
          message = body.detail;
        } else if (Array.isArray(body?.detail) && body.detail[0]?.msg) {
          message = body.detail[0].msg;
        }
      } catch {
        // ignore
      }
    } else if (res.status === 502 || res.status === 503) {
      message =
        'Render backend is waking up or deploying. Wait ~20–30 seconds and try again.';
    } else if (res.status === 404 || res.status === 405) {
      message =
        'Render backend is not connected yet. Open Settings → Render API to paste your https://*.onrender.com URL.';
    }
    throw new Error(message);
  }

  // When hosted as a static SPA on Vercel without a backend URL, /api/* falls back to HTML
  if (!contentType.includes('application/json')) {
    throw new Error(
      'Render backend not connected yet. Paste your https://*.onrender.com URL in Settings → Render API.'
    );
  }

  return res.json() as Promise<T>;
}

export const api = {
  testVpsConnection: async (
    candidateUrl: string,
    candidateToken: string
  ): Promise<{ health: HealthInfo; latencyMs: number; normalizedUrl: string }> => {
    const normalizedUrl = normalizeBaseUrl(candidateUrl);
    const target = normalizedUrl ? `${normalizedUrl}/api/health` : '/api/health';
    if (
      typeof window !== 'undefined' &&
      window.location.protocol === 'https:' &&
      normalizedUrl.startsWith('http://')
    ) {
      throw new Error(
        'HTTPS required: use your https://<service>.onrender.com URL (Render provides HTTPS automatically).'
      );
    }
    const ctrl = new AbortController();
    const timer = window.setTimeout(() => ctrl.abort(), 65000);
    let res: Response;
    const t0 = performance.now();
    try {
      res = await fetch(target, {
        headers: candidateToken.trim() ? { 'X-ClipForge-Token': candidateToken.trim() } : {},
        signal: ctrl.signal,
      });
    } catch {
      throw new Error(
        'Could not reach Render service. Verify the https://*.onrender.com URL and ensure its Render deploy status is Live.'
      );
    } finally {
      window.clearTimeout(timer);
    }
    const latencyMs = Math.max(1, Math.round(performance.now() - t0));
    const ct = res.headers.get('content-type') || '';
    if (!res.ok || !ct.includes('application/json')) {
      throw new Error(
        res.status === 502 || res.status === 503
          ? 'Render service is still waking up or building — wait 20 seconds and click Connect again.'
          : `Render URL did not return a valid ClipForge API response (HTTP ${res.status}).`
      );
    }
    const health = (await res.json()) as HealthInfo;
    if (!health?.yt_dlp_version) {
      throw new Error('Endpoint responded, but it is not a ClipForge 4K backend.');
    }
    if (health.auth_required) {
      const authCheck = await fetch(
        normalizedUrl ? `${normalizedUrl}/api/settings` : '/api/settings',
        {
          headers: candidateToken.trim() ? { 'X-ClipForge-Token': candidateToken.trim() } : {},
        }
      );
      if (authCheck.status === 401) {
        throw new Error(
          'Render backend reached, but API_SECRET is enabled — enter your secret token in Settings → Render API.'
        );
      }
    }
    return { health, latencyMs, normalizedUrl };
  },

  getHealth: () => requestJson<HealthInfo>('/api/health'),

  getSettings: () => requestJson<PublicSettings>('/api/settings'),

  updateSettings: (patch: Record<string, unknown>) =>
    requestJson<PublicSettings>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(patch),
    }),

  uploadCookiesFile: (file: File) => {
    const fd = new FormData();
    fd.append('file', file);
    return requestJson<PublicSettings>('/api/settings/cookies-file', {
      method: 'POST',
      body: fd,
    });
  },

  clearCookiesFile: () =>
    requestJson<PublicSettings>('/api/settings/cookies-file', {
      method: 'DELETE',
    }),

  uploadLocalVideo: (file: File) => {
    const fd = new FormData();
    fd.append('file', file);
    return requestJson<{ local_url: string; filename: string; size_bytes: number }>(
      '/api/upload-video',
      {
        method: 'POST',
        body: fd,
      }
    );
  },

  listJobs: () => requestJson<{ jobs: JobRecord[] }>('/api/jobs'),

  createJob: (payload: CreateJobPayload) =>
    requestJson<JobRecord>('/api/jobs', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getJob: (jobId: string) => requestJson<JobRecord>(`/api/jobs/${jobId}`),

  getTranscript: (jobId: string) =>
    requestJson<{ segments: TranscriptSegment[] }>(`/api/jobs/${jobId}/transcript`),

  cancelJob: (jobId: string) =>
    requestJson<JobRecord>(`/api/jobs/${jobId}/cancel`, { method: 'POST' }),

  deleteJob: (jobId: string) =>
    requestJson<{ deleted: boolean }>(`/api/jobs/${jobId}`, { method: 'DELETE' }),

  extractSelected: (
    jobId: string,
    payload: {
      clip_ids?: string[];
      resolution?: ResolutionPreset;
      aspect_ratio?: AspectRatio;
      vertical_layout?: VerticalLayout;
      burn_captions?: boolean;
    }
  ) =>
    requestJson<JobRecord>(`/api/jobs/${jobId}/extract`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateClip: (
    jobId: string,
    clipId: string,
    payload: {
      title?: string;
      start_time: number;
      end_time: number;
      aspect_ratio?: AspectRatio;
      vertical_layout?: VerticalLayout;
      resolution?: ResolutionPreset;
      burn_captions?: boolean;
      re_extract?: boolean;
    }
  ) =>
    requestJson<JobRecord>(`/api/jobs/${jobId}/clips/${clipId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  addCustomClip: (
    jobId: string,
    payload: { title: string; start_time: number; end_time: number; extract_now: boolean }
  ) =>
    requestJson<JobRecord>(`/api/jobs/${jobId}/clips`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  deleteClip: (jobId: string, clipId: string) =>
    requestJson<JobRecord>(`/api/jobs/${jobId}/clips/${clipId}`, { method: 'DELETE' }),

  clipStreamUrl: (jobId: string, clipId: string, cacheBust?: string | null) =>
    appendMediaQuery(`/api/jobs/${jobId}/clips/${clipId}/stream`, { v: cacheBust }),

  clipPosterUrl: (jobId: string, clipId: string, cacheBust?: string | null) =>
    appendMediaQuery(`/api/jobs/${jobId}/clips/${clipId}/poster`, { v: cacheBust }),

  clipDownloadUrl: (jobId: string, clipId: string) =>
    appendMediaQuery(`/api/jobs/${jobId}/clips/${clipId}/download`),

  jobZipUrl: (jobId: string) => appendMediaQuery(`/api/jobs/${jobId}/download-all`),
};
