#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "Error: ffmpeg is required. Install it via brew install ffmpeg / sudo apt install ffmpeg." >&2
  exit 1
fi

echo "==> Installing Python backend dependencies..."
pip3 install -q -r "$ROOT_DIR/backend/requirements.txt"

if [ ! -d "$ROOT_DIR/backend/static" ]; then
  echo "==> Building React frontend..."
  (cd "$ROOT_DIR/frontend" && npm install && npm run build)
fi

echo "==> Starting ClipForge 4K Studio at http://0.0.0.0:8000"
cd "$ROOT_DIR/backend"
exec python3 -m uvicorn main:app --host 0.0.0.0 --port "${PORT:-8000}"
