import { useEffect, useState } from 'react';
import {
  Check,
  Copy,
  Download,
  Loader2,
  Plus,
  Scissors,
  Search,
  Subtitles,
  X,
} from 'lucide-react';
import { api } from '../api';
import type { AspectRatio, ClipItem, TranscriptSegment } from '../types';
import {
  formatBytes,
  formatTimecode,
  parseTimecode,
  scoreBadgeClasses,
} from '../utils/format';

/* ────────────────────── 1. Theater Preview Modal ────────────────────── */

interface TheaterModalProps {
  jobId: string;
  clip: ClipItem | null;
  onClose: () => void;
  onEditTrim: (clip: ClipItem) => void;
}

export function TheaterModal({ jobId, clip, onClose, onEditTrim }: TheaterModalProps) {
  const [copied, setCopied] = useState(false);
  if (!clip) return null;

  const streamUrl = api.clipStreamUrl(jobId, clip.id, clip.filename);
  const downloadUrl = api.clipDownloadUrl(jobId, clip.id);

  const copyAll = async () => {
    const text = `${clip.title}\n\n${clip.transcript || clip.reason}\n\n${clip.hashtags.join(' ')}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // ignore
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        className="grid max-h-[92vh] w-full max-w-5xl overflow-hidden rounded-2xl border border-white/[0.1] bg-[#11131A] shadow-2xl lg:grid-cols-[1.5fr_1fr]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Left: Video Player */}
        <div className="flex items-center justify-center bg-black p-2 sm:p-4">
          <video
            src={streamUrl}
            controls
            autoPlay
            playsInline
            className="max-h-[75vh] w-full rounded-lg bg-black object-contain"
          />
        </div>

        {/* Right: AI Analysis + Download Panel */}
        <div className="flex flex-col overflow-y-auto border-t border-white/[0.07] p-5 lg:border-t-0 lg:border-l">
          <div className="flex items-start justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded bg-white/10 px-2 py-0.5 font-mono text-xs font-bold text-white">
                Clip #{clip.index}
              </span>
              <span
                className={`rounded-full border px-2.5 py-0.5 font-mono text-xs font-semibold ${scoreBadgeClasses(
                  clip.virality_score
                )}`}
              >
                {clip.virality_score}/100 Viral
              </span>
              {clip.is_4k && (
                <span className="rounded bg-[#FF5A36] px-2 py-0.5 font-mono text-[10px] font-bold text-white">
                  4K UHD
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg p-1 text-zinc-400 hover:bg-white/10 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <h2 className="mt-3 text-lg font-bold leading-snug text-white">{clip.title}</h2>
          <p className="mt-1 font-mono text-xs text-zinc-400">
            Source {formatTimecode(clip.start_time, true)} → {formatTimecode(clip.end_time, true)} ·{' '}
            {clip.duration.toFixed(1)}s
            {clip.width && clip.height ? ` · ${clip.width}×${clip.height}` : ''}
            {clip.file_size_bytes ? ` · ${formatBytes(clip.file_size_bytes)}` : ''}
          </p>

          <p className="mt-3 text-xs leading-relaxed text-zinc-300">{clip.reason}</p>

          {/* 4-Axis Virality Sub-scores */}
          <div className="mt-4 grid grid-cols-2 gap-2.5 rounded-xl border border-white/[0.06] bg-[#0B0D13] p-3">
            {(
              [
                ['Hook Strength', clip.sub_scores.hook],
                ['Retention', clip.sub_scores.retention],
                ['Emotion', clip.sub_scores.emotion],
                ['Pacing', clip.sub_scores.pacing],
              ] as const
            ).map(([label, val]) => (
              <div key={label}>
                <div className="flex justify-between text-[11px]">
                  <span className="text-zinc-400">{label}</span>
                  <span className="font-mono font-semibold text-white">{val}</span>
                </div>
                <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/[0.08]">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-[#FF5A36] to-[#FF9457]"
                    style={{ width: `${val}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Transcript */}
          {clip.transcript && (
            <div className="mt-4">
              <h4 className="text-[11px] font-semibold tracking-wider text-zinc-400 uppercase">
                Spoken Transcript
              </h4>
              <p className="mt-1.5 max-h-36 overflow-y-auto rounded-xl border border-white/[0.06] bg-[#0B0D13] p-3 text-xs leading-relaxed text-zinc-300">
                {clip.transcript}
              </p>
            </div>
          )}

          {/* Hashtags */}
          {clip.hashtags.length > 0 && (
            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              {clip.hashtags.map((tag) => (
                <span
                  key={tag}
                  className="rounded-md bg-white/[0.05] px-2 py-0.5 font-mono text-[11px] text-zinc-300"
                >
                  {tag}
                </span>
              ))}
              <button
                type="button"
                onClick={copyAll}
                className="ml-auto inline-flex items-center gap-1 text-xs text-zinc-400 hover:text-white"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                {copied ? 'Copied' : 'Copy Post'}
              </button>
            </div>
          )}

          <div className="mt-auto flex items-center gap-2 pt-5">
            <button
              type="button"
              onClick={() => {
                onClose();
                onEditTrim(clip);
              }}
              className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-[#171B26] px-3.5 py-2.5 text-xs font-semibold text-zinc-200 hover:bg-[#1F2433]"
            >
              <Scissors className="h-3.5 w-3.5" />
              Edit Trim
            </button>
            <a
              href={downloadUrl}
              download
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#FF5A36] to-[#FF7B3A] px-4 py-2.5 text-xs font-bold text-white shadow-lg shadow-[#FF5A36]/25 hover:brightness-110"
            >
              <Download className="h-4 w-4" />
              Download {clip.is_4k ? '4K UHD MP4' : 'MP4'}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ────────────────────── 2. Trim & Re-Export Modal ────────────────────── */

interface TrimModalProps {
  clip: ClipItem | null;
  videoDuration: number;
  hasTranscript: boolean;
  isReviewMode: boolean;
  onClose: () => void;
  onSave: (
    clipId: string,
    payload: {
      title: string;
      start_time: number;
      end_time: number;
      aspect_ratio: AspectRatio;
      burn_captions: boolean;
      re_extract: boolean;
    }
  ) => Promise<void>;
}

export function TrimModal({
  clip,
  videoDuration,
  hasTranscript,
  isReviewMode,
  onClose,
  onSave,
}: TrimModalProps) {
  const [title, setTitle] = useState('');
  const [startStr, setStartStr] = useState('00:00');
  const [endStr, setEndStr] = useState('00:30');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [burnCaptions, setBurnCaptions] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (clip) {
      setTitle(clip.title);
      setStartStr(formatTimecode(clip.start_time, true));
      setEndStr(formatTimecode(clip.end_time, true));
      setAspectRatio(clip.aspect_ratio || '16:9');
      setBurnCaptions(clip.burn_captions);
      setErr(null);
    }
  }, [clip]);

  if (!clip) return null;

  const sVal = parseTimecode(startStr);
  const eVal = parseTimecode(endStr);
  const liveDur = sVal !== null && eVal !== null ? Math.round((eVal - sVal) * 10) / 10 : 0;
  const overMax = liveDur > 60;

  const handleSubmit = async (reExtract: boolean) => {
    setErr(null);
    if (sVal === null || eVal === null) {
      setErr('Enter valid timestamps (e.g. 02:15.0 or 135).');
      return;
    }
    if (sVal < 0 || eVal > videoDuration + 0.5) {
      setErr(`Timestamps must be between 00:00 and ${formatTimecode(videoDuration)}.`);
      return;
    }
    if (eVal - sVal < 2) {
      setErr('Clip duration must be at least 2 seconds.');
      return;
    }
    if (eVal - sVal > 60) {
      setErr('Maximum clip duration is 60 seconds (1 minute).');
      return;
    }
    setSaving(true);
    try {
      await onSave(clip.id, {
        title: title.trim() || clip.title,
        start_time: sVal,
        end_time: Math.min(videoDuration, eVal),
        aspect_ratio: aspectRatio,
        burn_captions: burnCaptions,
        re_extract: reExtract,
      });
      onClose();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Failed to update clip');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-white/[0.1] bg-[#11131A] p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white">Trim & Format Clip #{clip.index}</h3>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-zinc-400 hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-4 space-y-4">
          <div>
            <label className="mb-1 block text-xs font-medium text-zinc-400">Clip Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-3 py-2 text-sm text-white focus:border-[#FF5A36] focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-zinc-400">Start Time</label>
              <input
                type="text"
                value={startStr}
                onChange={(e) => setStartStr(e.target.value)}
                className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-3 py-2 font-mono text-sm text-white focus:border-[#FF5A36] focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-zinc-400">End Time</label>
              <input
                type="text"
                value={endStr}
                onChange={(e) => setEndStr(e.target.value)}
                className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-3 py-2 font-mono text-sm text-white focus:border-[#FF5A36] focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-between rounded-lg bg-[#0B0D13] px-3 py-2 text-xs">
            <span className="text-zinc-400">Clip Length (max 60s):</span>
            <span
              className={`font-mono font-semibold ${
                overMax || liveDur < 2 ? 'text-red-400' : 'text-emerald-300'
              }`}
            >
              {liveDur.toFixed(1)}s {overMax ? '(exceeds 60s limit!)' : ''}
            </span>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-medium text-zinc-400">Aspect Ratio</label>
            <div className="grid grid-cols-3 gap-2">
              {(['16:9', '9:16', '1:1'] as const).map((ar) => (
                <button
                  key={ar}
                  type="button"
                  onClick={() => setAspectRatio(ar)}
                  className={`rounded-lg py-2 font-mono text-xs font-semibold transition ${
                    aspectRatio === ar
                      ? 'bg-[#FF5A36]/20 text-white ring-1 ring-[#FF5A36]/60'
                      : 'bg-[#0B0D13] text-zinc-400 hover:text-white'
                  }`}
                >
                  {ar}
                </button>
              ))}
            </div>
          </div>

          {hasTranscript && (
            <label className="flex cursor-pointer items-center gap-2 text-xs text-zinc-300">
              <input
                type="checkbox"
                checked={burnCaptions}
                onChange={(e) => setBurnCaptions(e.target.checked)}
                className="h-3.5 w-3.5 accent-[#FF5A36]"
              />
              <Subtitles className="h-3.5 w-3.5 text-zinc-400" />
              Burn-in styled captions on this clip
            </label>
          )}

          {err && (
            <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-200">
              {err}
            </p>
          )}

          <div className="flex items-center justify-end gap-2 pt-2">
            {isReviewMode && (
              <button
                type="button"
                disabled={saving}
                onClick={() => void handleSubmit(false)}
                className="rounded-xl border border-white/10 bg-[#171A24] px-3.5 py-2 text-xs font-semibold text-zinc-200 hover:bg-[#1E2230]"
              >
                Save Trim Only
              </button>
            )}
            <button
              type="button"
              disabled={saving || overMax || liveDur < 2}
              onClick={() => void handleSubmit(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#FF5A36] to-[#FF7B3A] px-4 py-2 text-xs font-bold text-white shadow hover:brightness-110 disabled:opacity-50"
            >
              {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              {clip.status === 'ready' ? 'Re-Render in 4K' : 'Save & Render 4K'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ────────────────────── 3. Add Custom Clip Modal ────────────────────── */

interface AddClipModalProps {
  open: boolean;
  videoDuration: number;
  defaultDuration: number;
  initialStart?: number;
  onClose: () => void;
  onAdd: (payload: {
    title: string;
    start_time: number;
    end_time: number;
    extract_now: boolean;
  }) => Promise<void>;
}

export function AddClipModal({
  open,
  videoDuration,
  defaultDuration,
  initialStart = 0,
  onClose,
  onAdd,
}: AddClipModalProps) {
  const [title, setTitle] = useState('Custom Viral Moment');
  const [startStr, setStartStr] = useState('00:00');
  const [endStr, setEndStr] = useState('00:30');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      const s = Math.max(0, Math.min(initialStart, Math.max(0, videoDuration - 10)));
      const e = Math.min(videoDuration, s + Math.min(60, defaultDuration));
      setStartStr(formatTimecode(s));
      setEndStr(formatTimecode(e));
      setTitle('Custom Viral Moment');
      setErr(null);
    }
  }, [open, initialStart, videoDuration, defaultDuration]);

  if (!open) return null;

  const sVal = parseTimecode(startStr);
  const eVal = parseTimecode(endStr);
  const dur = sVal !== null && eVal !== null ? Math.round((eVal - sVal) * 10) / 10 : 0;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    if (sVal === null || eVal === null) {
      setErr('Enter valid MM:SS timestamps.');
      return;
    }
    if (eVal - sVal < 2 || eVal - sVal > 60) {
      setErr('Clip duration must be between 2 and 60 seconds.');
      return;
    }
    setSaving(true);
    try {
      await onAdd({
        title: title.trim() || 'Custom Viral Moment',
        start_time: Math.max(0, sVal),
        end_time: Math.min(videoDuration, eVal),
        extract_now: true,
      });
      onClose();
    } catch (ex) {
      setErr(ex instanceof Error ? ex.message : 'Could not add clip');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <form
        onSubmit={submit}
        className="w-full max-w-md rounded-2xl border border-white/[0.1] bg-[#11131A] p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white">Extract Custom Clip</h3>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-zinc-400 hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <p className="mt-1 text-xs text-zinc-400">
          Pick any timestamp range up to 60 seconds from this video ({formatTimecode(videoDuration)} total).
        </p>

        <div className="mt-4 space-y-3.5">
          <div>
            <label className="mb-1 block text-xs font-medium text-zinc-400">Clip Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-3 py-2 text-sm text-white focus:border-[#FF5A36] focus:outline-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-zinc-400">Start (MM:SS)</label>
              <input
                type="text"
                value={startStr}
                onChange={(e) => setStartStr(e.target.value)}
                className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-3 py-2 font-mono text-sm text-white focus:border-[#FF5A36] focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-zinc-400">End (MM:SS)</label>
              <input
                type="text"
                value={endStr}
                onChange={(e) => setEndStr(e.target.value)}
                className="w-full rounded-lg border border-white/10 bg-[#0B0D13] px-3 py-2 font-mono text-sm text-white focus:border-[#FF5A36] focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-between rounded-lg bg-[#0B0D13] px-3 py-2 text-xs">
            <span className="text-zinc-400">Selected duration:</span>
            <span
              className={`font-mono font-semibold ${
                dur > 60 || dur < 2 ? 'text-red-400' : 'text-emerald-300'
              }`}
            >
              {dur.toFixed(1)}s / 60.0s max
            </span>
          </div>

          {err && (
            <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-200">
              {err}
            </p>
          )}

          <button
            type="submit"
            disabled={saving || dur > 60 || dur < 2}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#FF5A36] to-[#FF7B3A] px-4 py-2.5 text-xs font-bold text-white shadow hover:brightness-110 disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
            Extract Custom Clip in 4K
          </button>
        </div>
      </form>
    </div>
  );
}

/* ────────────────────── 4. Transcript Browser Modal ────────────────────── */

interface TranscriptModalProps {
  open: boolean;
  jobId: string;
  onClose: () => void;
  onClipFromTimestamp: (startTime: number) => void;
}

export function TranscriptModal({
  open,
  jobId,
  onClose,
  onClipFromTimestamp,
}: TranscriptModalProps) {
  const [segments, setSegments] = useState<TranscriptSegment[]>([]);
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState('');

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    api
      .getTranscript(jobId)
      .then((r) => setSegments(r.segments))
      .catch(() => setSegments([]))
      .finally(() => setLoading(false));
  }, [open, jobId]);

  if (!open) return null;

  const filtered = query.trim()
    ? segments.filter((s) => s.text.toLowerCase().includes(query.toLowerCase()))
    : segments;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[82vh] w-full max-w-2xl flex-col rounded-2xl border border-white/[0.1] bg-[#11131A] p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white">Source Transcript</h3>
            <p className="text-xs text-zinc-400">
              Click any line to extract a custom 4K short starting at that exact moment.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-zinc-400 hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="relative mt-3">
          <Search className="pointer-events-none absolute top-2.5 left-3 h-3.5 w-3.5 text-zinc-500" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search spoken words or moments…"
            className="w-full rounded-lg border border-white/10 bg-[#0B0D13] py-2 pr-3 pl-8 text-xs text-white placeholder-zinc-500 focus:border-[#FF5A36] focus:outline-none"
          />
        </div>

        <div className="mt-3 flex-1 space-y-1 overflow-y-auto pr-1">
          {loading ? (
            <div className="flex items-center justify-center py-12 text-xs text-zinc-400">
              <Loader2 className="mr-2 h-4 w-4 animate-spin text-[#FF5A36]" />
              Loading transcript…
            </div>
          ) : filtered.length === 0 ? (
            <p className="py-10 text-center text-xs text-zinc-500">No matching transcript lines.</p>
          ) : (
            filtered.map((seg, i) => (
              <button
                key={`${seg.start}-${i}`}
                type="button"
                onClick={() => {
                  onClose();
                  onClipFromTimestamp(seg.start);
                }}
                className="group flex w-full items-start gap-3 rounded-lg px-2.5 py-2 text-left transition hover:bg-white/[0.05]"
              >
                <span className="shrink-0 rounded bg-white/[0.06] px-1.5 py-0.5 font-mono text-[11px] text-[#FF8566]">
                  {formatTimecode(seg.start)}
                </span>
                <span className="flex-1 text-xs leading-relaxed text-zinc-300 group-hover:text-white">
                  {seg.text}
                </span>
                <span className="shrink-0 text-[10px] font-semibold text-[#FF7A59] opacity-0 transition group-hover:opacity-100">
                  + Clip here
                </span>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
